/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: mysql-sourougnon.alwaysdata.net    Database: sourougnon_db
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
SET net_read_timeout=600;

--
-- Table structure for table `mouvements_caisse`
--

DROP TABLE IF EXISTS `mouvements_caisse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_caisse` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `caisse_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `recouvrement_id` bigint(20) unsigned DEFAULT NULL,
  `remise_id` bigint(20) unsigned DEFAULT NULL,
  `sync_uuid` varchar(36) DEFAULT NULL,
  `type` enum('encaissement','decaissement','depot','retrait','transfert','salaire','epargne','penalite','remise','versement') DEFAULT NULL,
  `statut_validation` enum('en_attente','valide','ecart','rejete') NOT NULL DEFAULT 'en_attente',
  `montant` decimal(12,2) NOT NULL,
  `montant_declare` decimal(12,2) DEFAULT NULL,
  `montant_recu` decimal(12,2) DEFAULT NULL,
  `ecart_remise` decimal(12,2) DEFAULT NULL,
  `mode_paiement` varchar(255) NOT NULL DEFAULT 'especes',
  `reference` varchar(255) DEFAULT NULL,
  `motif` text DEFAULT NULL,
  `motif_rejet` text DEFAULT NULL,
  `date_mouvement` datetime NOT NULL,
  `heure_mouvement` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `beneficiaire` varchar(255) DEFAULT NULL,
  `valide_par` bigint(20) unsigned DEFAULT NULL,
  `valide_le` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mouvements_caisse_uuid_unique` (`uuid`),
  UNIQUE KEY `mouvements_caisse_sync_uuid_unique` (`sync_uuid`),
  KEY `mouvements_caisse_caisse_id_foreign` (`caisse_id`),
  KEY `mouvements_caisse_user_id_foreign` (`user_id`),
  KEY `mouvements_caisse_recouvrement_id_foreign` (`recouvrement_id`),
  KEY `mouvements_caisse_valide_par_foreign` (`valide_par`),
  KEY `idx_remise_validation` (`type`,`statut_validation`),
  KEY `mouvements_caisse_remise_id_foreign` (`remise_id`),
  CONSTRAINT `mouvements_caisse_caisse_id_foreign` FOREIGN KEY (`caisse_id`) REFERENCES `caisses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mouvements_caisse_recouvrement_id_foreign` FOREIGN KEY (`recouvrement_id`) REFERENCES `recouvrements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mouvements_caisse_remise_id_foreign` FOREIGN KEY (`remise_id`) REFERENCES `remises` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mouvements_caisse_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mouvements_caisse_valide_par_foreign` FOREIGN KEY (`valide_par`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_caisse`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mouvements_caisse` WRITE;
/*!40000 ALTER TABLE `mouvements_caisse` DISABLE KEYS */;
INSERT INTO `mouvements_caisse` VALUES
(1,'3f0ee3b3-e8be-450b-be44-b37600c67051',5,1,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-17 23:14:29',NULL,'2026-08-17 21:14:29','2026-08-25 14:23:54',NULL,NULL,NULL),
(2,'424a8b50-c2f8-4b8d-b880-0104431da0df',5,1,1,NULL,NULL,'encaissement','valide',3700.00,NULL,NULL,NULL,'especes','REC-965813f4','Paiement Maxim',NULL,'2026-08-17 23:14:29',NULL,'2026-08-17 21:14:29','2026-08-25 14:23:54',NULL,NULL,NULL),
(3,'0adf6e56-5a5e-420f-afe2-d443c5193db2',7,3,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-18 22:30:51',NULL,'2026-08-18 20:30:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(4,'c16f60e2-ef56-4650-9b6f-81fab67f4585',7,3,NULL,NULL,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-e417a46d','Paiement AKOUTE',NULL,'2026-08-18 22:30:51',NULL,'2026-08-18 20:30:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(5,'69af7140-b3c1-43ed-8248-dca7b65f3a49',9,3,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-19 08:18:55',NULL,'2026-08-19 06:18:55','2026-08-25 14:23:54',NULL,NULL,NULL),
(6,'34bc664b-83d4-4bdc-bf7c-ab25cefb0a6d',9,3,3,NULL,NULL,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REC-b3db80b2','Paiement Maxim',NULL,'2026-08-19 08:18:55',NULL,'2026-08-19 06:18:55','2026-08-25 14:23:54',NULL,NULL,NULL),
(7,'5a69890a-dc6f-4142-b6e8-2f28f697adef',10,3,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 00:36:02',NULL,'2026-08-19 22:36:02','2026-08-25 14:23:54',NULL,NULL,NULL),
(9,'85ee00be-0fda-4eb7-838a-8aeb6fedace9',10,3,NULL,NULL,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-f9f87a67','Paiement AKOUTE',NULL,'2026-08-20 00:36:02',NULL,'2026-08-19 22:36:02','2026-08-25 14:23:54',NULL,NULL,NULL),
(11,'84b313b2-e307-4d97-9ac3-2b6d96cdd840',10,3,5,NULL,NULL,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REC-64155dd6','Paiement Maxim',NULL,'2026-08-20 00:37:22',NULL,'2026-08-19 22:37:22','2026-08-25 14:23:54',NULL,NULL,NULL),
(14,'c2aca7c4-1336-494b-994f-a0a193593292',10,3,NULL,NULL,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-f8f5b333','Paiement AKOUTE',NULL,'2026-08-20 12:49:51',NULL,'2026-08-20 10:49:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(16,'87a32cba-d2e0-4635-8534-666bbdd79dde',10,3,NULL,NULL,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-0a802adc','Paiement AKOUTE',NULL,'2026-08-20 13:19:54',NULL,'2026-08-20 11:19:54','2026-08-25 14:23:54',NULL,NULL,NULL),
(22,'9450472e-be6d-48a1-8a66-68091d04f95f',10,3,8,NULL,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-037aee07','Paiement AKOUTE',NULL,'2026-08-20 22:14:58',NULL,'2026-08-20 20:14:58','2026-08-25 14:23:54',NULL,NULL,NULL),
(29,'2fc826ef-cc38-4ab6-8ff0-244eb00ed773',11,3,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(30,'45a93290-1fc3-4359-9389-0a4970f3bae0',11,3,11,NULL,NULL,'encaissement','valide',12300.00,NULL,NULL,NULL,'especes','REC-0aa1acd2','Paiement AKOUTE',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(32,'62625e78-d7d1-45f6-b7d6-a6bfc71c071a',11,3,12,NULL,NULL,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REC-90f95ce0','Paiement Maxim',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(33,'5e8b4e04-5f09-468b-8c6a-87f32da9a6c1',14,3,NULL,NULL,NULL,'remise','valide',5000.00,NULL,NULL,NULL,'especes','REMISE-NJG6HRCL','Remise à l agence',NULL,'2026-08-24 23:22:07',NULL,'2026-08-24 21:22:07','2026-08-25 14:23:54',NULL,NULL,NULL),
(34,'b5f66a3c-1102-4ef0-96a2-909a2c6a53da',15,3,NULL,NULL,NULL,'versement','valide',5000.00,NULL,NULL,NULL,'especes','REMISE-NJG6HRCL','Versement de Mensah',NULL,'2026-08-24 23:22:07',NULL,'2026-08-24 21:22:07','2026-08-25 14:23:54',NULL,NULL,NULL),
(40,'68eebda3-8842-49b2-9a08-e159e766e204',18,3,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-26 22:10:47',NULL,'2026-08-26 20:10:47','2026-08-26 20:10:47',NULL,NULL,NULL),
(41,'5689dafa-27f2-457e-827f-389b0d214a66',18,3,13,NULL,NULL,'encaissement','valide',18750.00,NULL,NULL,NULL,'especes','REC-f7c4a386','Paiement Maxim',NULL,'2026-08-26 22:10:47',NULL,'2026-08-26 20:10:47','2026-08-26 20:10:47',NULL,NULL,NULL),
(42,'aa96155e-76c0-4063-8cb1-018758576a98',18,3,NULL,NULL,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-26 22:14:43',NULL,'2026-08-26 20:14:43','2026-08-26 20:14:43',NULL,NULL,NULL),
(43,'ad418a4f-cb62-4e57-b1ac-3a4e5cb0fc66',18,3,14,NULL,NULL,'encaissement','valide',18450.00,NULL,NULL,NULL,'especes','REC-cf699354','Paiement AKOUTE',NULL,'2026-08-26 22:14:43',NULL,'2026-08-26 20:14:43','2026-08-26 20:14:43',NULL,NULL,NULL),
(44,'cb062fe0-24dc-42bd-a844-129f5e9ca894',20,3,NULL,NULL,NULL,'epargne','en_attente',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-27 00:07:48',NULL,'2026-08-26 22:07:48','2026-08-26 22:07:48',NULL,NULL,NULL),
(45,'7c97455a-db4a-42a0-8891-ffab7bf37bac',20,3,15,1,NULL,'encaissement','valide',24600.00,NULL,NULL,NULL,'especes','REMISE-GEXXX0LG','Paiement AKOUTE',NULL,'2026-08-27 00:07:48',NULL,'2026-08-26 22:07:48','2026-08-27 20:43:35',NULL,1,'2026-08-27 20:43:35'),
(46,'6f240e7f-867a-4443-8d55-3d64a5bd1ad0',20,3,NULL,1,NULL,'remise','valide',24600.00,24600.00,NULL,NULL,'especes','REMISE-GEXXX0LG','Remise à l agence',NULL,'2026-08-27 22:41:33',NULL,'2026-08-27 20:41:33','2026-08-27 20:43:35',NULL,1,'2026-08-27 20:43:35'),
(47,'2681c8b9-6774-43fa-9a44-9a6216403267',22,3,NULL,1,NULL,'versement','valide',24600.00,24600.00,NULL,NULL,'especes','REMISE-GEXXX0LG','Versement de Mensah',NULL,'2026-08-27 22:41:33',NULL,'2026-08-27 20:41:33','2026-08-27 20:43:35',NULL,1,'2026-08-27 20:43:35'),
(48,'19aa40d6-b515-419c-8f77-8236fc7e7fec',20,3,NULL,NULL,NULL,'epargne','en_attente',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-27 22:44:58',NULL,'2026-08-27 20:44:58','2026-08-27 20:44:58',NULL,NULL,NULL),
(49,'209f612f-cae5-4adc-8057-1ffea407410a',20,3,16,2,NULL,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REMISE-GSOUYLQ9','Paiement Maxim',NULL,'2026-08-27 22:44:58',NULL,'2026-08-27 20:44:58','2026-08-27 20:47:36',NULL,1,'2026-08-27 20:47:36'),
(50,'e52ccfbc-7841-4128-967a-a1f5c7c8a85b',20,3,NULL,2,NULL,'remise','valide',3750.00,3750.00,NULL,NULL,'especes','REMISE-GSOUYLQ9','Remise à l agence',NULL,'2026-08-27 22:46:34',NULL,'2026-08-27 20:46:34','2026-08-27 20:47:36',NULL,1,'2026-08-27 20:47:36'),
(51,'bbf9c5cb-abfd-4926-a2bc-74deecebf330',22,3,NULL,2,NULL,'versement','valide',3750.00,3750.00,NULL,NULL,'especes','REMISE-GSOUYLQ9','Versement de Mensah',NULL,'2026-08-27 22:46:34',NULL,'2026-08-27 20:46:34','2026-08-27 20:47:36',NULL,1,'2026-08-27 20:47:36'),
(52,'6db231db-c555-432a-b6a5-e906e5f30cfa',20,3,NULL,NULL,NULL,'epargne','en_attente',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-27 22:48:52',NULL,'2026-08-27 20:48:52','2026-08-27 20:48:52',NULL,NULL,NULL),
(53,'cd73ad89-5b22-4101-ab67-29da23b92821',20,3,17,3,NULL,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REMISE-K1G3TOVS','Paiement Maxim',NULL,'2026-08-27 22:48:52',NULL,'2026-08-27 20:48:52','2026-08-27 21:22:48',NULL,1,'2026-08-27 21:22:48'),
(54,'cde6ad94-54bc-471e-a670-9b469757fb20',20,3,NULL,NULL,NULL,'epargne','en_attente',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-27 22:51:44',NULL,'2026-08-27 20:51:44','2026-08-27 20:51:44',NULL,NULL,NULL),
(55,'3d6d1abe-3205-4aa6-a71c-97360b4bd91e',20,3,18,3,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REMISE-K1G3TOVS','Paiement AKOUTE',NULL,'2026-08-27 22:51:44',NULL,'2026-08-27 20:51:44','2026-08-27 21:22:48',NULL,1,'2026-08-27 21:22:48'),
(56,'4c854449-503e-4b53-be16-fd92ff8769f4',20,3,NULL,3,NULL,'remise','valide',9900.00,9900.00,NULL,NULL,'especes','REMISE-K1G3TOVS','Remise à l agence',NULL,'2026-08-27 22:53:40',NULL,'2026-08-27 20:53:40','2026-08-27 21:22:48',NULL,1,'2026-08-27 21:22:48'),
(57,'113f6913-6ef5-44e9-a64a-5da6b9147a30',22,3,NULL,3,NULL,'versement','valide',9900.00,9900.00,NULL,NULL,'especes','REMISE-K1G3TOVS','Versement de Mensah',NULL,'2026-08-27 22:53:40',NULL,'2026-08-27 20:53:40','2026-08-27 21:22:48',NULL,1,'2026-08-27 21:22:48'),
(58,'e3d7391b-d223-4a9f-b6c5-dbae7cedd686',20,3,NULL,NULL,NULL,'penalite','rejete',2000.00,NULL,NULL,NULL,'especes','PENAL-96dfda14','Pénalité retard 2j - Maxim','Pénalité annulée - bug rattachement','2026-08-27 23:05:07',NULL,'2026-08-27 21:05:07','2026-08-27 21:05:07',NULL,NULL,NULL),
(59,'70e880b5-7b3c-46da-9ee3-fdcfe53b8cf0',20,3,NULL,NULL,NULL,'penalite','rejete',8000.00,NULL,NULL,NULL,'especes','PENAL-96dfd2d5','Pénalité retard 8j - Maxim','Pénalité annulée - bug rattachement','2026-08-27 23:06:10',NULL,'2026-08-27 21:06:10','2026-08-27 21:06:10',NULL,NULL,NULL),
(60,'a10e1ce2-a9c2-4217-8401-9cd071f11cb9',20,3,NULL,NULL,NULL,'penalite','rejete',8000.00,NULL,NULL,NULL,'especes','PENAL-96dfd5e4','Pénalité retard 8j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:06:10',NULL,'2026-08-27 21:06:10','2026-08-27 21:06:10',NULL,NULL,NULL),
(61,'2bb0720f-fa5a-49eb-9e81-1a5e877b7941',20,3,NULL,NULL,NULL,'penalite','rejete',1000.00,NULL,NULL,NULL,'especes','PENAL-6b79098b','Pénalité retard 1j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:06:10',NULL,'2026-08-27 21:06:10','2026-08-27 21:06:10',NULL,NULL,NULL),
(62,'c31a3b0d-496b-4846-a6ce-e1c746ee7775',20,3,NULL,NULL,NULL,'penalite','rejete',7000.00,NULL,NULL,NULL,'especes','PENAL-96dfd6ac','Pénalité retard 7j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:06:11',NULL,'2026-08-27 21:06:11','2026-08-27 21:06:11',NULL,NULL,NULL),
(63,'694c2c0c-2df2-414c-9fa0-8326427a1aa3',20,3,NULL,NULL,NULL,'penalite','rejete',7000.00,NULL,NULL,NULL,'especes','PENAL-96dfd6ac','Pénalité retard 7j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:06:48',NULL,'2026-08-27 21:06:48','2026-08-27 21:06:48',NULL,NULL,NULL),
(64,'c508d2cb-cb4f-43ce-985d-50056cb5ad1f',20,3,NULL,NULL,NULL,'penalite','rejete',5000.00,NULL,NULL,NULL,'especes','PENAL-96dfd741','Pénalité retard 5j - Maxim','Pénalité annulée - bug rattachement','2026-08-27 23:06:53',NULL,'2026-08-27 21:06:53','2026-08-27 21:06:53',NULL,NULL,NULL),
(65,'1e9e5b0a-a5fd-41cc-bed1-b32db34099e8',20,3,NULL,NULL,NULL,'penalite','rejete',1000.00,NULL,NULL,NULL,'especes','PENAL-580cfa56','Pénalité retard 1j - Maxim','Pénalité annulée - bug rattachement','2026-08-27 23:07:00',NULL,'2026-08-27 21:07:00','2026-08-27 21:07:00',NULL,NULL,NULL),
(66,'d5e6cd27-9071-4fe6-9565-26ba622f3b36',20,3,NULL,NULL,NULL,'penalite','rejete',5000.00,NULL,NULL,NULL,'especes','PENAL-96dfd7c9','Pénalité retard 5j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:07:07',NULL,'2026-08-27 21:07:07','2026-08-27 21:07:07',NULL,NULL,NULL),
(67,'42d1f8ec-e4e8-4293-8848-0d0d742d5c72',20,3,NULL,NULL,NULL,'penalite','rejete',3000.00,NULL,NULL,NULL,'especes','PENAL-96dfd84f','Pénalité retard 3j - Maxim','Pénalité annulée - bug rattachement','2026-08-27 23:07:57',NULL,'2026-08-27 21:07:57','2026-08-27 21:07:57',NULL,NULL,NULL),
(68,'c0763a7a-a341-48c3-a883-cd97edc81cee',20,3,NULL,NULL,NULL,'penalite','rejete',2000.00,NULL,NULL,NULL,'especes','PENAL-96dfdba6','Pénalité retard 2j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:07:57',NULL,'2026-08-27 21:07:57','2026-08-27 21:07:57',NULL,NULL,NULL),
(69,'85eb973b-d862-4b70-b0f7-f895a6c3b2b1',20,3,NULL,NULL,NULL,'penalite','rejete',1000.00,NULL,NULL,NULL,'especes','PENAL-96dfdb26','Pénalité retard 1j - Maxim','Pénalité annulée - bug rattachement','2026-08-27 23:07:58',NULL,'2026-08-27 21:07:58','2026-08-27 21:07:58',NULL,NULL,NULL),
(70,'96b70864-2455-497e-92d5-023a3caf656b',20,3,NULL,NULL,NULL,'penalite','rejete',4000.00,NULL,NULL,NULL,'especes','PENAL-96dfd921','Pénalité retard 4j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:07:58',NULL,'2026-08-27 21:07:58','2026-08-27 21:07:58',NULL,NULL,NULL),
(71,'4e89742a-7bf2-47a7-867a-1a13dc39891f',20,3,NULL,NULL,NULL,'penalite','rejete',3000.00,NULL,NULL,NULL,'especes','PENAL-96dfdaa7','Pénalité retard 3j - AKOUTE','Pénalité annulée - bug rattachement','2026-08-27 23:09:11',NULL,'2026-08-27 21:09:11','2026-08-27 21:09:11',NULL,NULL,NULL);
/*!40000 ALTER TABLE `mouvements_caisse` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `penalites`
--

DROP TABLE IF EXISTS `penalites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `penalites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `echeance_id` bigint(20) unsigned DEFAULT NULL,
  `recouvrement_id` bigint(20) unsigned DEFAULT NULL,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `statut` varchar(255) NOT NULL DEFAULT 'en_attente',
  `date_paiement` datetime DEFAULT NULL,
  `mode_paiement` varchar(255) DEFAULT NULL,
  `refus_defalque_epargne` tinyint(1) NOT NULL DEFAULT 0,
  `jours_retard` int(11) NOT NULL DEFAULT 0,
  `date_appliquee` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `penalites_uuid_unique` (`uuid`),
  UNIQUE KEY `penalites_echeance_id_unique` (`echeance_id`),
  KEY `penalites_vente_id_foreign` (`vente_id`),
  KEY `penalites_recouvrement_id_foreign` (`recouvrement_id`),
  KEY `penalites_debiteur_id_foreign` (`debiteur_id`),
  CONSTRAINT `penalites_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `penalites_echeance_id_foreign` FOREIGN KEY (`echeance_id`) REFERENCES `echeances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `penalites_recouvrement_id_foreign` FOREIGN KEY (`recouvrement_id`) REFERENCES `recouvrements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `penalites_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penalites`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `penalites` WRITE;
/*!40000 ALTER TABLE `penalites` DISABLE KEYS */;
INSERT INTO `penalites` VALUES
(32,'96dfd2d5-a16d-11f1-b4b2-525400978d46',1,1,NULL,5,8000.00,'annulee','2026-08-27 23:06:10','especes',0,8,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(33,'96dfd5e4-a16d-11f1-b4b2-525400978d46',2,21,NULL,6,8000.00,'annulee','2026-08-27 23:06:10','especes',0,8,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(34,'96dfd6ac-a16d-11f1-b4b2-525400978d46',2,22,NULL,6,7000.00,'annulee','2026-08-27 23:06:48','especes',0,7,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(35,'96dfd741-a16d-11f1-b4b2-525400978d46',1,4,NULL,5,5000.00,'annulee','2026-08-27 23:06:53','especes',0,5,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(36,'96dfd7c9-a16d-11f1-b4b2-525400978d46',2,24,NULL,6,5000.00,'annulee','2026-08-27 23:07:07','especes',0,5,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(37,'96dfd84f-a16d-11f1-b4b2-525400978d46',1,6,NULL,5,3000.00,'annulee','2026-08-27 23:07:57','especes',0,3,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(38,'96dfd921-a16d-11f1-b4b2-525400978d46',2,26,14,6,4000.00,'annulee','2026-08-27 23:07:58','especes',0,4,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(39,'96dfda14-a16d-11f1-b4b2-525400978d46',1,7,NULL,5,2000.00,'annulee','2026-08-27 23:05:07','especes',0,2,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(40,'96dfdaa7-a16d-11f1-b4b2-525400978d46',2,27,14,6,3000.00,'annulee','2026-08-27 23:09:11','especes',0,3,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(41,'96dfdb26-a16d-11f1-b4b2-525400978d46',1,8,NULL,5,1000.00,'annulee','2026-08-27 23:07:58','especes',0,1,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(42,'96dfdba6-a16d-11f1-b4b2-525400978d46',2,28,14,6,2000.00,'annulee','2026-08-27 23:07:57','especes',0,2,'2026-08-27','2026-08-26 16:45:47','2026-08-27 21:23:59'),
(47,'580cfa56-de5b-48d4-92e6-0202134ceea6',1,9,NULL,5,1000.00,'annulee','2026-08-27 23:07:00','especes',0,1,'2026-08-27','2026-08-26 22:06:29','2026-08-27 21:23:59'),
(48,'6b79098b-5412-4289-b376-2fe66a24ab3d',2,29,NULL,6,1000.00,'annulee','2026-08-27 23:06:10','especes',0,1,'2026-08-27','2026-08-26 22:06:29','2026-08-27 21:23:59');
/*!40000 ALTER TABLE `penalites` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-28 11:20:52
