/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: mysql-sourougnon.alwaysdata.net    Database: sourougnon_db
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
SET net_read_timeout=600;

--
-- Table structure for table `debiteurs`
--

DROP TABLE IF EXISTS `debiteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `debiteurs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `code_client` varchar(20) DEFAULT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `quartier` varchar(255) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `personne_reference_nom` varchar(255) DEFAULT NULL,
  `personne_reference_tel` varchar(255) DEFAULT NULL,
  `activite` varchar(255) DEFAULT NULL,
  `score_solvabilite` decimal(5,2) NOT NULL DEFAULT 1.00,
  `limite_credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `credits_autorises` int(10) unsigned NOT NULL DEFAULT 1,
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ancien_agent_id` bigint(20) unsigned DEFAULT NULL,
  `date_transfert` timestamp NULL DEFAULT NULL,
  `taux_recouvrement_au_transfert` decimal(5,2) DEFAULT NULL,
  `reste_a_payer_au_transfert` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `debiteurs_uuid_unique` (`uuid`),
  UNIQUE KEY `debiteurs_code_client_unique` (`code_client`),
  KEY `debiteurs_agent_id_foreign` (`agent_id`),
  KEY `debiteurs_ancien_agent_id_foreign` (`ancien_agent_id`),
  CONSTRAINT `debiteurs_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `debiteurs_ancien_agent_id_foreign` FOREIGN KEY (`ancien_agent_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debiteurs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `debiteurs` WRITE;
/*!40000 ALTER TABLE `debiteurs` DISABLE KEYS */;
INSERT INTO `debiteurs` VALUES
(1,'f3b914f4-67db-4f1e-9412-006112304171','CLI-AHOS0OBC',4,'HOMESSI','Clémence','0164913211','Atlantique > Abomey-Calavi > Togba > Maria-Gléta','Maison Jean',NULL,NULL,'Commerçante',50.00,0.00,1,0,'2026-08-15 19:17:48','2026-08-17 20:39:56',NULL,NULL,NULL,NULL),
(2,'c1cbb813-1b06-4b97-97e9-beca2ed42561','CLI-QUOVFD1G',2,'AKPO','Kenneth','0143276784','Littoral > Cotonou > 7eme > Vossa','Maison sous l\'eau',NULL,NULL,'Commerçant',50.00,0.00,1,0,'2026-08-15 19:28:14','2026-08-17 20:40:20',NULL,NULL,NULL,NULL),
(3,'878b6055-e4fe-4c09-960f-218ced74fdb0','CLI-FU89NJOO',3,'DOSSOU','WILSON','0143278322','Littoral > Cotonou > 7eme > Missite','Maison Smith',NULL,NULL,'Commerçant',50.00,0.00,1,0,'2026-08-17 13:42:46','2026-08-17 20:40:09',NULL,NULL,NULL,NULL),
(4,'d7f2d799-dbd3-43e0-b076-05aca682fb67','CLI-Y3QMWTV6',3,'KOUESSI','Anna','0165345609','Littoral > Cotonou > 4eme > Hounsa','Maison Dona',NULL,NULL,'Commerçante',50.00,0.00,1,0,'2026-08-17 20:08:41','2026-08-17 20:39:41',NULL,NULL,NULL,NULL),
(5,'53a59943-52d0-492e-b9ab-d148f17bf04b','CLI-YE7IDOYM',3,'Maxim','AKPO','0164913211','Littoral > Cotonou > 5eme > Datcha','Maison Jean','Wilfried Lawson','0165437854','Boutiquier',25.48,0.00,1,1,'2026-08-17 20:42:03','2026-08-26 14:26:52',NULL,NULL,NULL,NULL),
(6,'048e1567-9d55-4650-ada3-bcee9ed69207','CLI-VMCTI5GX',3,'AKOUTE','Desmond','0143278322','Littoral > Cotonou > 6eme > Vossa','Maison Smith','BOTCHI Paulin','0143275409','Commerçant',20.54,0.00,1,1,'2026-08-17 20:52:34','2026-08-26 14:26:27',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `debiteurs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `scores_solvabilite`
--

DROP TABLE IF EXISTS `scores_solvabilite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scores_solvabilite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `score` int(11) NOT NULL DEFAULT 100,
  `nb_credits_total` int(11) NOT NULL DEFAULT 0,
  `nb_credits_termines` int(11) NOT NULL DEFAULT 0,
  `nb_retards` int(11) NOT NULL DEFAULT 0,
  `montant_total_rembourse` decimal(12,2) NOT NULL DEFAULT 0.00,
  `montant_total_du` decimal(12,2) NOT NULL DEFAULT 0.00,
  `date_calcul` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scores_solvabilite_debiteur_id_foreign` (`debiteur_id`),
  CONSTRAINT `scores_solvabilite_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores_solvabilite`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `scores_solvabilite` WRITE;
/*!40000 ALTER TABLE `scores_solvabilite` DISABLE KEYS */;
INSERT INTO `scores_solvabilite` VALUES
(1,2,50,0,0,0,0.00,0.00,'2026-08-17 20:40:13','2026-08-17 19:51:52','2026-08-17 20:40:13'),
(2,4,50,0,0,0,0.00,0.00,'2026-08-17 20:39:34','2026-08-17 20:08:55','2026-08-17 20:39:34'),
(3,1,50,0,0,0,0.00,0.00,'2026-08-17 20:39:49','2026-08-17 20:34:21','2026-08-17 20:39:49'),
(4,3,50,0,0,0,0.00,0.00,'2026-08-17 20:40:03','2026-08-17 20:40:03','2026-08-17 20:40:03'),
(5,5,25,1,0,6,14950.00,75000.00,'2026-08-26 17:18:37','2026-08-17 20:42:08','2026-08-26 17:18:37'),
(6,6,21,1,0,7,18450.00,123000.00,'2026-08-26 17:22:59','2026-08-17 21:02:33','2026-08-26 17:22:59');
/*!40000 ALTER TABLE `scores_solvabilite` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-26 21:27:59
