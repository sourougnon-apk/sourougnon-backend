/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: mysql-sourougnon.alwaysdata.net    Database: sourougnon_db
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
SET net_read_timeout=600;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `journals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `numero_ecriture` varchar(255) NOT NULL,
  `type_compta` enum('principale','secondaire') NOT NULL DEFAULT 'principale',
  `date_ecriture` date NOT NULL,
  `compte_debit` varchar(255) NOT NULL,
  `compte_credit` varchar(255) NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `montant_ht` decimal(12,2) DEFAULT NULL,
  `montant_tva` decimal(12,2) DEFAULT NULL,
  `montant_ttc` decimal(12,2) DEFAULT NULL,
  `taux_tva` decimal(5,2) DEFAULT 18.00,
  `libelle` varchar(255) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `recouvrement_id` bigint(20) unsigned DEFAULT NULL,
  `vente_id` bigint(20) unsigned DEFAULT NULL,
  `mouvement_caisse_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `journals_uuid_unique` (`uuid`),
  KEY `journals_recouvrement_id_foreign` (`recouvrement_id`),
  KEY `journals_vente_id_foreign` (`vente_id`),
  KEY `journals_mouvement_caisse_id_foreign` (`mouvement_caisse_id`),
  KEY `journals_user_id_foreign` (`user_id`),
  KEY `journals_date_ecriture_index` (`date_ecriture`),
  KEY `journals_compte_debit_index` (`compte_debit`),
  KEY `journals_compte_credit_index` (`compte_credit`),
  KEY `idx_type_compta` (`type_compta`),
  CONSTRAINT `journals_mouvement_caisse_id_foreign` FOREIGN KEY (`mouvement_caisse_id`) REFERENCES `mouvements_caisse` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journals_recouvrement_id_foreign` FOREIGN KEY (`recouvrement_id`) REFERENCES `recouvrements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `journals_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES
(1,'009a745f-8a98-428d-964f-bc12f2039126','ECR-20260817-EAKX','principale','2026-08-17','411000','701000',75000.00,NULL,NULL,NULL,18.00,'Vente crédit Maxim','VTE-7ea546c4',NULL,1,NULL,1,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(2,'6a4f3e80-1900-4743-ba42-88f36cc4fb25','ECR-20260817-W5NO','principale','2026-08-17','411000','701000',123000.00,NULL,NULL,NULL,18.00,'Vente crédit AKOUTE','VTE-bf517af3',NULL,2,NULL,1,'2026-08-17 21:03:11','2026-08-17 21:03:11'),
(3,'739170ac-f9a2-433f-8460-b5b690352402','ECR-20260817-3LAF','principale','2026-08-17','521000','411000',3700.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-965813f4',1,1,NULL,1,'2026-08-17 21:14:29','2026-08-17 21:14:29'),
(5,'65b275c5-755f-4746-8547-6e2c4a21e9ff','ECR-20260819-IIU2','principale','2026-08-19','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-b3db80b2',3,1,NULL,3,'2026-08-19 06:18:55','2026-08-19 06:18:55'),
(6,'5e975705-19b4-444e-846f-28b732a59999','ECR-20260820-8UQY','secondaire','2026-08-20','521000','758000',1025.02,NULL,NULL,NULL,18.00,'Pénalité retard 1.0250235993056j - AKOUTE','PENAL-92cf6415',NULL,NULL,NULL,3,'2026-08-19 22:36:02','2026-08-19 22:36:02'),
(8,'f28362df-ace7-4733-a282-aee7bfd51f8a','ECR-20260820-CJ3O','principale','2026-08-20','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-64155dd6',5,1,NULL,3,'2026-08-19 22:37:22','2026-08-19 22:37:22'),
(9,'68524661-5ca4-4977-8535-9c25751e53bf','ECR-20260820-TDQQ','secondaire','2026-08-17','521000','758000',1651.35,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKPO','PENAL-5889f828',NULL,NULL,NULL,3,'2026-08-20 02:50:00','2026-08-20 02:50:00'),
(12,'fa4c0a26-6f5d-431e-a5fe-dd1925303c80','ECR-20260820-OVVX','secondaire','2026-08-20','521000','758000',2593.40,NULL,NULL,NULL,18.00,'Pénalité retard 2.5934045772454j - AKOUTE','PENAL-5879a184',NULL,NULL,NULL,3,'2026-08-20 12:14:30','2026-08-20 12:14:30'),
(13,'a4581e6c-ea83-4aa5-b0e4-d5d4e7d993b6','ECR-20260820-MD1H','principale','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-037aee07',8,2,NULL,3,'2026-08-20 20:14:58','2026-08-20 20:14:58'),
(14,'d9fa8616-78be-4bed-a552-8ee8e3dae8fb','ECR-20260820-0EVW','secondaire','2026-08-20','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - Maxim','PENAL-cd50085b',NULL,NULL,NULL,3,'2026-08-20 20:24:45','2026-08-20 20:24:45'),
(15,'a1387a34-45df-4641-8ca2-3066037dbe9e','ECR-20260820-ULVK','secondaire','2026-08-20','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKOUTE','PENAL-d71e9194',NULL,NULL,NULL,3,'2026-08-20 20:25:09','2026-08-20 20:25:09'),
(18,'d8e767f2-f0f7-46f9-a899-3b40e4aa5663','ECR-20260822-YJ8I','principale','2026-08-22','521000','411000',12300.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-0aa1acd2',11,2,NULL,3,'2026-08-22 15:07:33','2026-08-22 15:07:33'),
(19,'3a413b8c-63e4-4610-83b5-49007f09afb6','ECR-20260822-Z6ZN','principale','2026-08-22','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-90f95ce0',12,1,NULL,3,'2026-08-22 15:07:33','2026-08-22 15:07:33'),
(20,'b45e74e4-6b6f-4383-89b4-0f96c8b34998','ECR-20260825-AXBQ','secondaire','2026-08-25','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - Maxim','PENAL-c04c79bc',NULL,NULL,NULL,3,'2026-08-25 15:47:16','2026-08-25 15:47:16'),
(21,'dcaa1767-4c5b-40fe-8475-ebd4127006bf','ECR-20260825-GLGN','secondaire','2026-08-25','521000','758000',3000.00,NULL,NULL,NULL,18.00,'Pénalité retard 3j - Maxim','PENAL-fd30e325',NULL,NULL,NULL,3,'2026-08-25 15:47:24','2026-08-25 15:47:24'),
(22,'69f6d4f8-70d1-4c38-b60f-5e1a793c50db','ECR-20260825-MHML','secondaire','2026-08-25','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - Maxim','PENAL-45fd29f6',NULL,NULL,NULL,3,'2026-08-25 15:47:37','2026-08-25 15:47:37'),
(23,'6a913fa8-d997-456e-a177-05d11d8da00d','ECR-20260825-HQBP','secondaire','2026-08-25','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - AKOUTE','PENAL-c3569e4e',NULL,NULL,NULL,3,'2026-08-25 15:47:46','2026-08-25 15:47:46'),
(24,'699f5459-5709-4417-a468-5e35bb7fb9ed','ECR-20260825-BCHR','secondaire','2026-08-25','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKOUTE','PENAL-e997b479',NULL,NULL,NULL,3,'2026-08-25 15:47:57','2026-08-25 15:47:57'),
(25,'340290a3-1f72-4bfc-be16-ad163f4e969c','ECR-20260826-EHSK','principale','2026-08-26','521000','411000',18750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-f7c4a386',13,1,NULL,3,'2026-08-26 20:10:47','2026-08-26 20:10:47'),
(26,'00e41c20-3627-46c9-b3ad-36f2938e7a18','ECR-20260826-ZWMU','principale','2026-08-26','521000','411000',18450.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-cf699354',14,2,NULL,3,'2026-08-26 20:14:43','2026-08-26 20:14:43'),
(27,'fda29b59-f6f1-4c65-a52e-5bc48f5bdd49','ECR-20260827-NWRJ','principale','2026-08-27','521000','411000',24600.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-962abccc',15,2,NULL,3,'2026-08-26 22:07:48','2026-08-26 22:07:48'),
(28,'c7dba666-2df1-4665-b2c8-dfebd4dee52d','ECR-20260827-ESHK','principale','2026-08-27','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-6db1ef14',16,1,NULL,3,'2026-08-27 20:44:58','2026-08-27 20:44:58'),
(30,'7f2d57fc-309e-4866-b830-3695758db2f5','ECR-20260827-6DSP','principale','2026-08-27','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-d5076f3c',18,2,NULL,3,'2026-08-27 20:51:44','2026-08-27 20:51:44'),
(31,'24417e82-6c75-4406-9ab7-d40ae4cedfac','ECR-20260827-BJG2','secondaire','2026-08-27','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - Maxim','PENAL-96dfda14',NULL,NULL,NULL,3,'2026-08-27 21:05:07','2026-08-27 21:05:07'),
(32,'84628afb-c6ff-4fee-8c9b-2b69211beded','ECR-20260827-I0TR','secondaire','2026-08-27','521000','758000',8000.00,NULL,NULL,NULL,18.00,'Pénalité retard 8j - Maxim','PENAL-96dfd2d5',NULL,NULL,NULL,3,'2026-08-27 21:06:10','2026-08-27 21:06:10'),
(33,'d669f7d3-6671-4487-92a6-204015fe1a21','ECR-20260827-B495','secondaire','2026-08-27','521000','758000',8000.00,NULL,NULL,NULL,18.00,'Pénalité retard 8j - AKOUTE','PENAL-96dfd5e4',NULL,NULL,NULL,3,'2026-08-27 21:06:10','2026-08-27 21:06:10'),
(34,'bdd6d605-3958-4427-a372-3af8109b20ed','ECR-20260827-OA1C','secondaire','2026-08-27','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - AKOUTE','PENAL-6b79098b',NULL,NULL,NULL,3,'2026-08-27 21:06:10','2026-08-27 21:06:10'),
(35,'222d35b4-dda7-4c54-b403-7d997f65ab58','ECR-20260827-BOSL','secondaire','2026-08-27','521000','758000',7000.00,NULL,NULL,NULL,18.00,'Pénalité retard 7j - AKOUTE','PENAL-96dfd6ac',NULL,NULL,NULL,3,'2026-08-27 21:06:11','2026-08-27 21:06:11'),
(37,'6b5ed7a4-b717-4b48-909b-e5f98f8a66b3','ECR-20260827-QRGL','secondaire','2026-08-27','521000','758000',5000.00,NULL,NULL,NULL,18.00,'Pénalité retard 5j - Maxim','PENAL-96dfd741',NULL,NULL,NULL,3,'2026-08-27 21:06:53','2026-08-27 21:06:53'),
(38,'dd7ecc0b-0cb0-44d1-adf9-11ca4ed6155d','ECR-20260827-GNCB','secondaire','2026-08-27','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - Maxim','PENAL-580cfa56',NULL,NULL,NULL,3,'2026-08-27 21:07:00','2026-08-27 21:07:00'),
(39,'8e12de05-b02e-46bd-bfcb-4d225da08e52','ECR-20260827-HKDB','secondaire','2026-08-27','521000','758000',5000.00,NULL,NULL,NULL,18.00,'Pénalité retard 5j - AKOUTE','PENAL-96dfd7c9',NULL,NULL,NULL,3,'2026-08-27 21:07:07','2026-08-27 21:07:07'),
(40,'f1868b18-f583-44c7-b0c4-d2ced9492ed7','ECR-20260827-GVTF','secondaire','2026-08-27','521000','758000',3000.00,NULL,NULL,NULL,18.00,'Pénalité retard 3j - Maxim','PENAL-96dfd84f',NULL,NULL,NULL,3,'2026-08-27 21:07:57','2026-08-27 21:07:57'),
(41,'b17ee094-a92d-403f-9e2e-0a23fc7c7c18','ECR-20260827-XFFD','secondaire','2026-08-27','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKOUTE','PENAL-96dfdba6',NULL,NULL,NULL,3,'2026-08-27 21:07:57','2026-08-27 21:07:57'),
(43,'5bf3d3a0-ec4b-4939-81f8-451be7d35875','ECR-20260827-KEVU','secondaire','2026-08-27','521000','758000',4000.00,NULL,NULL,NULL,18.00,'Pénalité retard 4j - AKOUTE','PENAL-96dfd921',NULL,NULL,NULL,3,'2026-08-27 21:07:58','2026-08-27 21:07:58'),
(44,'0a9c98a7-ad1a-48db-9cb4-64a6aa8ab019','ECR-20260827-OBZM','secondaire','2026-08-27','521000','758000',3000.00,NULL,NULL,NULL,18.00,'Pénalité retard 3j - AKOUTE','PENAL-96dfdaa7',NULL,NULL,NULL,3,'2026-08-27 21:09:11','2026-08-27 21:09:11');
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-28 14:36:42
