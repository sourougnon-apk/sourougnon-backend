/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: mysql-sourougnon.alwaysdata.net    Database: sourougnon_db
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
SET net_read_timeout=600;

--
-- Table structure for table `recouvrements`
--

DROP TABLE IF EXISTS `recouvrements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recouvrements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `date_recouvrement` date NOT NULL,
  `heure_recouvrement` time DEFAULT NULL,
  `mode_paiement` enum('especes','mobile','autre') NOT NULL DEFAULT 'especes',
  `statut` enum('paye','partiel','refus','absent','promesse') NOT NULL DEFAULT 'paye',
  `commentaire` text DEFAULT NULL,
  `synced` tinyint(1) NOT NULL DEFAULT 0,
  `sync_uuid` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recouvrements_uuid_unique` (`uuid`),
  KEY `recouvrements_vente_id_foreign` (`vente_id`),
  KEY `recouvrements_agent_id_foreign` (`agent_id`),
  CONSTRAINT `recouvrements_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `recouvrements_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recouvrements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `recouvrements` WRITE;
/*!40000 ALTER TABLE `recouvrements` DISABLE KEYS */;
INSERT INTO `recouvrements` VALUES
(1,'965813f4-c57e-4ae8-8cd9-d4e4432ea040',1,1,3700.00,'2026-08-17','23:14:29','especes','paye',NULL,1,NULL,'2026-08-17 21:14:29','2026-08-17 21:14:29'),
(3,'b3db80b2-5e1f-416f-b536-dc62f36d611d',1,3,3750.00,'2026-08-19','08:18:55','especes','paye',NULL,1,NULL,'2026-08-19 06:18:55','2026-08-19 06:18:55'),
(5,'64155dd6-e31a-413e-8733-b15d61274e9b',1,3,3750.00,'2026-08-20','00:37:22','especes','paye',NULL,1,NULL,'2026-08-19 22:37:22','2026-08-19 22:37:22'),
(8,'037aee07-e908-40a1-adb4-76138be2628c',2,3,6150.00,'2026-08-20','22:14:58','especes','paye',NULL,1,NULL,'2026-08-20 20:14:58','2026-08-20 20:14:58'),
(11,'0aa1acd2-c318-4f47-a97f-4632ff9b6db9',2,3,12300.00,'2026-08-22','17:07:33','especes','paye',NULL,1,'48de30b7-8480-4f0c-a9d8-f07df45eeece','2026-08-22 15:07:33','2026-08-22 15:07:33'),
(12,'90f95ce0-0f71-4d6b-b3c8-eea61960b967',1,3,3750.00,'2026-08-22','17:07:33','especes','paye',NULL,1,'382397b1-3397-4d43-b187-966f235b7eed','2026-08-22 15:07:33','2026-08-22 15:07:33');
/*!40000 ALTER TABLE `recouvrements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tournee_demarrages`
--

DROP TABLE IF EXISTS `tournee_demarrages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournee_demarrages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `date_tournee` date NOT NULL,
  `heure_demarrage` datetime NOT NULL,
  `heure_fin` datetime DEFAULT NULL,
  `statut` varchar(255) NOT NULL DEFAULT 'en_cours',
  `gps_depart` varchar(255) DEFAULT NULL,
  `gps_arrivee` varchar(255) DEFAULT NULL,
  `synced` tinyint(1) NOT NULL DEFAULT 1,
  `sync_uuid` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tournee_demarrages_uuid_unique` (`uuid`),
  KEY `tournee_demarrages_agent_id_foreign` (`agent_id`),
  CONSTRAINT `tournee_demarrages_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournee_demarrages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tournee_demarrages` WRITE;
/*!40000 ALTER TABLE `tournee_demarrages` DISABLE KEYS */;
INSERT INTO `tournee_demarrages` VALUES
(1,'f9205f28-0094-40b8-ab35-502861627412',3,'2026-08-20','2026-08-20 02:17:45','2026-08-20 02:18:20','terminee',NULL,NULL,1,NULL,'2026-08-20 00:17:45','2026-08-20 00:18:20'),
(2,'b6b17556-cfd4-4871-893f-be14d8f7f4aa',3,'2026-08-20','2026-08-20 02:28:03','2026-08-20 02:28:19','terminee',NULL,NULL,1,NULL,'2026-08-20 00:28:03','2026-08-20 00:28:19'),
(3,'4c81ec40-7897-4231-ba58-8c8af31bf725',3,'2026-08-20','2026-08-20 02:31:34','2026-08-20 02:31:40','terminee',NULL,NULL,1,NULL,'2026-08-20 00:31:34','2026-08-20 00:31:40'),
(4,'1d1d6828-9a4d-41e7-b596-44cd24f98638',3,'2026-08-20','2026-08-20 12:27:20',NULL,'en_cours',NULL,NULL,1,NULL,'2026-08-20 10:27:20','2026-08-20 10:27:20'),
(5,'cf2da1d1-3034-49ec-aec8-caa006f81c06',3,'2026-08-22','2026-08-22 16:34:16',NULL,'en_cours',NULL,NULL,1,NULL,'2026-08-22 14:34:16','2026-08-22 14:34:16'),
(6,'256f1952-7bb4-4aef-8c72-0bc99ee4d3ac',3,'2026-08-25','2026-08-25 17:53:50',NULL,'en_cours',NULL,NULL,1,NULL,'2026-08-25 15:53:50','2026-08-25 15:53:50');
/*!40000 ALTER TABLE `tournee_demarrages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-26 22:53:13
