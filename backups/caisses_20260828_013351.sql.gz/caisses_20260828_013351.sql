/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: mysql-sourougnon.alwaysdata.net    Database: sourougnon_db
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
SET net_read_timeout=600;

--
-- Table structure for table `caisses`
--

DROP TABLE IF EXISTS `caisses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caisses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `date_ouverture` date NOT NULL,
  `date_fermeture` date DEFAULT NULL,
  `solde_initial` decimal(12,2) NOT NULL DEFAULT 0.00,
  `solde_theorique` decimal(12,2) NOT NULL DEFAULT 0.00,
  `solde_reel` decimal(12,2) DEFAULT NULL,
  `ecart` decimal(12,2) DEFAULT NULL,
  `statut` enum('ouverte','fermee') NOT NULL DEFAULT 'ouverte',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `periode` varchar(20) NOT NULL DEFAULT 'jour',
  `total_encaissements` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_decaissements` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_salaires` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_epargnes` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_penalites` decimal(12,2) NOT NULL DEFAULT 0.00,
  `agence_id` int(10) unsigned DEFAULT NULL,
  `type_caisse` varchar(20) DEFAULT 'agent',
  `caisse_parente_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `caisses_uuid_unique` (`uuid`),
  KEY `caisses_user_id_foreign` (`user_id`),
  CONSTRAINT `caisses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caisses`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `caisses` WRITE;
/*!40000 ALTER TABLE `caisses` DISABLE KEYS */;
INSERT INTO `caisses` VALUES
(1,'730012c0-31b8-4e32-aa36-4f1b8f0350ab',1,'2026-08-11',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-10 23:27:37','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(2,'2d150c45-9000-4161-9d1c-e5c2927cae92',1,'2026-08-12',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-12 14:46:25','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(3,'f261eea1-978a-4cea-bbff-43e5376fab34',1,'2026-08-14',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-14 04:42:31','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(4,'91dc74f3-a327-4480-80ba-9bf7b675198d',1,'2026-08-15','2026-08-23',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-15 11:15:13','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(5,'432877a3-0b4b-472d-97c2-7d42d2914ff7',1,'2026-08-17','2026-08-18',0.00,4000.00,NULL,NULL,'fermee',NULL,'2026-08-17 13:37:56','2026-08-24 19:18:30','jour',3700.00,0.00,0.00,300.00,0.00,1,'generale',NULL),
(6,'cc53218b-7a17-49c8-8516-9911197c7f2c',5,'2026-08-18','2026-08-19',4000.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-18 08:25:35','2026-08-24 19:01:47','jour',0.00,0.00,0.00,0.00,0.00,1,'agence',NULL),
(7,'c51e941f-cb11-4082-b19b-5a509bae67e7',3,'2026-08-18',NULL,0.00,6450.00,NULL,NULL,'ouverte',NULL,'2026-08-18 20:30:51','2026-08-24 19:01:47','jour',6150.00,0.00,0.00,300.00,0.00,1,'agent',NULL),
(8,'eb79bf14-30b1-458c-8e0a-928d6d236af7',5,'2026-08-19',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-18 22:34:57','2026-08-24 19:01:47','jour',0.00,0.00,0.00,0.00,0.00,1,'agence',NULL),
(9,'83c7a8a6-300e-4e81-bbe0-19a5bb2da7ce',3,'2026-08-19',NULL,0.00,4050.00,NULL,NULL,'ouverte',NULL,'2026-08-19 06:18:55','2026-08-24 19:01:47','jour',3750.00,0.00,0.00,300.00,0.00,1,'agent',NULL),
(10,'972d6249-c540-47f2-8121-9bd897fb0cf2',3,'2026-08-20',NULL,0.00,51919.77,NULL,NULL,'ouverte',NULL,'2026-08-19 22:36:02','2026-08-24 19:01:47','jour',40650.00,0.00,0.00,3000.00,8269.77,1,'agent',NULL),
(11,'bd546425-5a7a-4df8-a757-31205da7800a',3,'2026-08-22',NULL,0.00,16650.00,NULL,NULL,'ouverte',NULL,'2026-08-22 15:07:33','2026-08-24 19:01:47','jour',16050.00,0.00,0.00,600.00,0.00,1,'agent',NULL),
(12,'4147aa82-ea04-4c83-abba-7511ece7190d',1,'2026-08-23','2026-08-24',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-23 21:54:15','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(13,'5ca021ad-7672-49c8-aa2a-02490cac34ea',1,'2026-08-24','2026-08-25',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-24 06:20:52','2026-08-25 13:18:49','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(14,'48762878-fa0a-4aaa-9062-5eef1f510c79',3,'2026-08-24',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-24 21:22:07','2026-08-24 21:22:07','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(15,'1289829e-465a-4604-ab2a-5d4b5e127656',5,'2026-08-24',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-24 21:22:07','2026-08-24 21:22:07','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(16,'fa2cb284-67bd-47c2-beb2-e4dd0c505415',1,'2026-08-25','2026-08-26',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-25 13:18:49','2026-08-26 20:18:36','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(17,'ed1ad87b-37e7-4b66-8b03-a53c910e96d1',3,'2026-08-25',NULL,0.00,9000.00,NULL,NULL,'ouverte',NULL,'2026-08-25 15:47:16','2026-08-25 15:47:57','jour',0.00,0.00,0.00,0.00,9000.00,NULL,'agent',NULL),
(18,'05e11fe1-caf3-4539-af2a-42a26fe32076',3,'2026-08-26',NULL,0.00,37800.00,NULL,NULL,'ouverte',NULL,'2026-08-26 20:10:47','2026-08-26 20:14:43','jour',37200.00,0.00,0.00,600.00,0.00,NULL,'agent',NULL),
(19,'0d2d7823-a211-41b4-ab4d-5f1c51ea5179',1,'2026-08-26','2026-08-27',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-26 20:18:36','2026-08-26 22:37:57','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(20,'3d4ff168-32d0-4135-98f9-a35525376859',3,'2026-08-27',NULL,0.00,28350.00,NULL,NULL,'ouverte',NULL,'2026-08-26 22:07:48','2026-08-27 21:09:11','jour',28350.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(21,'2adb9afc-6926-4745-b00e-c6dd1aa4badf',1,'2026-08-27',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-26 22:37:57','2026-08-26 22:37:57','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(22,'9b07bf1f-f1cc-4cbb-ae2f-b44fc81da02a',5,'2026-08-27',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-27 20:41:33','2026-08-27 20:53:40','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL);
/*!40000 ALTER TABLE `caisses` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-28  1:33:51
