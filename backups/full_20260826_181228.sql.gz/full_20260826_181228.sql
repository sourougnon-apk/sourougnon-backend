/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.8-MariaDB, for Linux (x86_64)
--
-- Host: mysql-sourougnon.alwaysdata.net    Database: sourougnon_db
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
SET net_read_timeout=600;

--
-- Table structure for table `agences`
--

DROP TABLE IF EXISTS `agences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) DEFAULT NULL,
  `nom` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agences`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agences` WRITE;
/*!40000 ALTER TABLE `agences` DISABLE KEYS */;
INSERT INTO `agences` VALUES
(1,'b2e37099-f152-46d6-9ff7-e7d16b9f4e9d','Agence Principale','Cotonou','',1,'2026-08-24 19:01:47','2026-08-24 19:01:47');
/*!40000 ALTER TABLE `agences` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `alertes`
--

DROP TABLE IF EXISTS `alertes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `alertes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned DEFAULT NULL,
  `debiteur_id` bigint(20) unsigned DEFAULT NULL,
  `produit_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `message` text DEFAULT NULL,
  `niveau` enum('info','avertissement','critique') NOT NULL DEFAULT 'info',
  `lue` tinyint(1) NOT NULL DEFAULT 0,
  `date_alerte` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alertes_uuid_unique` (`uuid`),
  KEY `alertes_vente_id_foreign` (`vente_id`),
  KEY `alertes_debiteur_id_foreign` (`debiteur_id`),
  KEY `alertes_produit_id_foreign` (`produit_id`),
  KEY `alertes_lue_date_alerte_index` (`lue`,`date_alerte`),
  CONSTRAINT `alertes_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `alertes_produit_id_foreign` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE SET NULL,
  CONSTRAINT `alertes_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=390 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alertes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `alertes` WRITE;
/*!40000 ALTER TABLE `alertes` DISABLE KEYS */;
INSERT INTO `alertes` VALUES
(1,'e15a8287-a6d2-4a11-963f-64e02a00b770',NULL,NULL,1,'stock_faible','Stock faible','SUCRE KAKI 50KG : -5 unité(s) (seuil : 5)','avertissement',0,'2026-08-17 18:44:04','2026-08-17 16:44:04','2026-08-18 19:20:54'),
(2,'df608634-5b0f-448b-b453-d797f4da1a0d',NULL,NULL,3,'stock_faible','Stock faible','TULIP JAUNE 50KG : -2 unité(s) (seuil : 5)','avertissement',0,'2026-08-17 18:44:04','2026-08-17 16:44:04','2026-08-18 19:20:54'),
(3,'57d7d32e-dfe5-4791-ae4f-8e30c5c23692',NULL,NULL,4,'stock_faible','Stock faible','FARM HOUSSE 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-17 18:44:04','2026-08-17 16:44:04','2026-08-18 19:20:54'),
(4,'e9bb9173-626e-47f2-a8c4-80e6b938c303',NULL,NULL,5,'stock_faible','Stock faible','COOKZEN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-17 18:44:04','2026-08-17 16:44:04','2026-08-18 19:20:54'),
(191,'b09ed834-a7da-4975-868c-4604c5c029fe',1,5,NULL,'echeance_jour','Échéance du jour','Maxim doit payer 3 750 FCFA aujourd\'hui.','info',0,'2026-08-17 22:00:00','2026-08-17 22:07:20','2026-08-18 11:33:22'),
(192,'c5814e37-2586-4a76-9890-128e4d8c386b',2,6,NULL,'echeance_jour','Échéance du jour','AKOUTE doit payer 6 150 FCFA aujourd\'hui.','info',0,'2026-08-17 22:00:00','2026-08-17 22:07:20','2026-08-18 10:25:01'),
(193,'2ab78d4f-8d05-4f59-9be3-976a4a48ac63',NULL,NULL,2,'stock_faible','Stock faible','HUILE 25 LITRES : -2 unité(s) (seuil : 5)','avertissement',0,'2026-08-18 17:01:40','2026-08-18 15:01:40','2026-08-18 19:20:54'),
(195,'db0d9901-ffa2-4c6c-8f0b-99687c6a671f',NULL,NULL,6,'stock_faible','Stock faible','HARICOT ROUGE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(196,'d1a555ed-2a4c-455d-aed1-9141ce4c25f8',NULL,NULL,7,'stock_faible','Stock faible','MAIS BLANC : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(197,'230d0a24-2fda-4d27-879d-7bfbc554e9ea',NULL,NULL,8,'stock_faible','Stock faible','FARINE GMB : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(198,'62331ec1-f94b-42db-a228-c1402df01c1f',NULL,NULL,9,'stock_faible','Stock faible','LAIT EN POUDRE ZELANDE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(199,'abdac410-6b6d-4390-b098-7b4b34c6b430',NULL,NULL,10,'stock_faible','Stock faible','COQUIL SACHET BONJOURNE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(200,'ca18bd72-bb1d-4c33-b2b2-1994d64be9be',NULL,NULL,11,'stock_faible','Stock faible','CUBE MAGGI POULET : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(201,'7451747e-efc5-4da4-bd63-da4c80b10f4d',NULL,NULL,12,'stock_faible','Stock faible','SOJA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(202,'f4843480-ddd1-48d7-a85c-8c3a9d1c897c',NULL,NULL,13,'stock_faible','Stock faible','SARDINE ATLANTA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(203,'dddb2f8a-0331-42c1-8604-36f83a665e84',NULL,NULL,14,'stock_faible','Stock faible','MAYONNAISE MEVIA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(204,'72207fc2-2da8-4c57-8ff2-faf0da46d79b',NULL,NULL,15,'stock_faible','Stock faible','LAIT PEAK : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(205,'28ee26c2-46c5-4b27-9345-15b49d50951a',NULL,NULL,16,'stock_faible','Stock faible','Cube VEDAN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(206,'cccbe025-ada4-4ef7-8c3b-ceb403410a9e',NULL,NULL,17,'stock_faible','Stock faible','SPAGHETTI DOGA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(207,'33eae4e2-0b4f-47dc-951a-33433280c999',NULL,NULL,18,'stock_faible','Stock faible','SPRITE PLASTIQUE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(208,'8c9eb9b3-a721-4e0f-856d-f8e6a910c2b7',NULL,NULL,19,'stock_faible','Stock faible','LA CASERA PLASTIQUE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(209,'4980bab0-57e7-4567-a32e-e134651f030a',NULL,NULL,20,'stock_faible','Stock faible','LEVURE JADU : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(210,'d9e043be-fba3-4604-a6d8-11cfcc6e7dd4',NULL,NULL,21,'stock_faible','Stock faible','SEL SAC BLANC : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(211,'0877bd61-0f39-4b1c-9e01-e28b79c596d4',NULL,NULL,22,'stock_faible','Stock faible','GARI SOHUI : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(212,'563f8747-4261-4ad5-9094-903df2b39ab1',NULL,NULL,23,'stock_faible','Stock faible','COCA COLA PLASTIQUE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(213,'fac24a39-7afc-4376-9e14-7abfd5e02191',NULL,NULL,24,'stock_faible','Stock faible','BICARBONATE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(214,'1e1c493e-ca4f-4bff-81db-885036fe6dbf',NULL,NULL,25,'stock_faible','Stock faible','BOISSON ENERGIE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(215,'ab2662bd-1aab-488a-ba98-93da1bbd88b1',NULL,NULL,26,'stock_faible','Stock faible','HARICOT TAWA MOYEN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(216,'93edbdb7-52ab-4335-84bc-54969f1062b1',NULL,NULL,27,'stock_faible','Stock faible','TOMATE SHALOM : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(217,'83ab50e7-49b2-4600-9931-9853a53315c0',NULL,NULL,28,'stock_faible','Stock faible','TOMATE SURE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(218,'8af39f2d-e2ea-4bdb-89f7-167b0a2001b5',NULL,NULL,29,'stock_faible','Stock faible','BIG JOE 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(219,'b2e71658-71cf-4f8f-9355-a3fb4704a963',NULL,NULL,30,'stock_faible','Stock faible','RIZ CLARK 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(220,'41407a66-023f-4f2b-bb57-bf22d0da1140',NULL,NULL,31,'stock_faible','Stock faible','BLIGOE PETIT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(221,'7dc7f0cb-09d8-4198-8545-3b8b55329bff',NULL,NULL,32,'stock_faible','Stock faible','VOANZOU PETIT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(222,'31874023-cd9d-47d0-ba35-3a82000c9a95',NULL,NULL,33,'stock_faible','Stock faible','TOMATE AMAZONE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(223,'759cf370-1df9-458d-8bc1-9d6b8211dd3c',NULL,NULL,34,'stock_faible','Stock faible','MIL KAKI : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(224,'44a669d6-dd6f-40eb-afe6-3c1c29e251b0',NULL,NULL,35,'stock_faible','Stock faible','FANTA CANETTE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(225,'73ae68eb-5a85-441d-a436-7bb15cfc3401',NULL,NULL,36,'stock_faible','Stock faible','COCA CANETTE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(226,'fde9ce4c-5ff1-4f1e-9b94-9d377591d7b2',NULL,NULL,37,'stock_faible','Stock faible','SPRITE CANETTE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(227,'43349d83-d485-45ce-aa6f-510e3749a5a5',NULL,NULL,38,'stock_faible','Stock faible','MALTA GUINESS : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(228,'e546459a-62a2-41c5-9e28-3cd60bf05615',NULL,NULL,39,'stock_faible','Stock faible','DESPERADO GRAND : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(229,'109a340e-3899-4c76-9313-046294996c0c',NULL,NULL,40,'stock_faible','Stock faible','RIZ 3 GOOD CASSE PARFUME 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(230,'ea819462-947f-40db-a71e-1efe658f8e98',NULL,NULL,42,'stock_faible','Stock faible','RIZ 3 GOOD CASSE PARFUME 5 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(231,'dedf264b-0436-4e25-b983-479c6e5e9e02',NULL,NULL,43,'stock_faible','Stock faible','RIZ 3 GOOD PARFUME LONG GRAIN 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(232,'e6a9ced2-39ab-411b-8c87-c19d20d8e1dd',NULL,NULL,44,'stock_faible','Stock faible','COQUILLETTE ROCH : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(233,'494fcb3e-71d9-49d1-a89d-55212b14b8e5',NULL,NULL,45,'stock_faible','Stock faible','SARDINE BONJOURNE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(234,'a6b25d6d-5eb8-4e62-980c-baea6f86c25d',NULL,NULL,46,'stock_faible','Stock faible','TOMATE GINNY : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(235,'7d0153b2-d334-4ae4-8c9d-77e6b7f59011',NULL,NULL,47,'stock_faible','Stock faible','HARACA ROUGE CASSE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(236,'8169e85f-fcdc-4342-9458-2fd312411cd5',NULL,NULL,48,'stock_faible','Stock faible','SPAGHETTI GOEYMEN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(237,'64e98bfb-18e6-43c0-817c-040b1743958d',NULL,NULL,49,'stock_faible','Stock faible','AWONLI HARICOT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(238,'8676a7e9-382f-420a-8c74-9dc450e7da70',NULL,NULL,50,'stock_faible','Stock faible','VODY 18% : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(239,'27625289-3384-4aee-8f06-a3d278164069',NULL,NULL,51,'stock_faible','Stock faible','RIZ 3 GOOD LONG GRAIN 5KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(240,'830674be-49a1-490e-830c-071339e11e28',NULL,NULL,52,'stock_faible','Stock faible','SACHET NOIR DE 5F : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(241,'09c5aaaf-705e-492e-851f-8784c114686a',NULL,NULL,53,'stock_faible','Stock faible','SACHET BLANC DE 5F : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(242,'0ac821df-6413-42d1-adf7-545e2eb1797c',NULL,NULL,54,'stock_faible','Stock faible','COUSCOUS BONJOURNE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(243,'9e484a79-e7c0-4b4a-b420-472ce9022559',NULL,NULL,55,'stock_faible','Stock faible','FARIME MOA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(244,'d6e0d246-30ba-4cff-b289-e2487a999fd4',NULL,NULL,56,'stock_faible','Stock faible','KATY 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(245,'52d507c0-0c7c-449d-8f45-a7a3cb21de7c',NULL,NULL,57,'stock_faible','Stock faible','YOUKI 1,5 LITRE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(246,'696fdce1-f1a1-4e3e-9368-34e72737ac02',NULL,NULL,58,'stock_faible','Stock faible','TOMATE MAGNIFICAT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(247,'545d3bc2-5827-4803-9936-ab9b19779a97',NULL,NULL,59,'stock_faible','Stock faible','SARDINES BEAUX RIVAGES : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(248,'2ccb4915-45ac-42f1-9571-83310fed21f7',NULL,NULL,60,'stock_faible','Stock faible','SPAGHETTI DANU : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(249,'b31cd58a-05e3-4575-835a-923301065990',NULL,NULL,61,'stock_faible','Stock faible','RIZ MARINA CASSE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(250,'e57a2a46-71e7-4b8c-ab52-f4f7b40772cd',NULL,NULL,62,'stock_faible','Stock faible','REAKTOR : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(251,'089496cb-ff41-4cf1-b966-3c17412e04b1',NULL,NULL,63,'stock_faible','Stock faible','BEAUFORT BOISSON : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(252,'82b32bde-dfa6-4562-bd17-613e18092b4b',NULL,NULL,64,'stock_faible','Stock faible','BOISSON ROX : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(253,'9c142084-4531-4928-84e6-119d01cab863',NULL,NULL,65,'stock_faible','Stock faible','MAYONNAISE GINNY : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(254,'a20f4467-ca73-4631-994d-e1a5ec084e73',NULL,NULL,66,'stock_faible','Stock faible','LAIT CEBON : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(255,'e8c58a29-54a6-49ce-ba95-4f8cbe9ac4c9',NULL,NULL,67,'stock_faible','Stock faible','MY CHOICE BLANC 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(256,'f52c6c5f-395b-4ae4-b0fc-238a00aeb9fd',NULL,NULL,68,'stock_faible','Stock faible','COQUILLETTE DANU : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(257,'5e1f0bf0-4bb8-4f58-8868-74d3a770efb0',NULL,NULL,69,'stock_faible','Stock faible','CHARBON SAC DE 100 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(258,'f35b7545-f8b2-4fb5-be77-a7f496a2d60c',NULL,NULL,70,'stock_faible','Stock faible','TOMATE BENNY 2200G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(259,'2bfe9dad-4d4a-468b-ab7c-ea0299186b0c',NULL,NULL,71,'stock_faible','Stock faible','COQUILLETTE OBA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(260,'88baff29-f710-4d3d-b0d8-9f9cade2518c',NULL,NULL,72,'stock_faible','Stock faible','MONSTER GRAND : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(261,'020343e7-5e58-4443-82f3-3cecb75c82e9',NULL,NULL,73,'stock_faible','Stock faible','SANGRIA FORTE 18% CARTON DE 48 : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(262,'181af669-c65a-43ad-a120-fe379655605a',NULL,NULL,74,'stock_faible','Stock faible','SANGRIA FORTE 18% DETAIL : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(263,'c093298c-0409-4f46-bbd7-e024ca7fa1c9',NULL,NULL,75,'stock_faible','Stock faible','CHATEAUX DE FRANCE 11% DETAIL : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(264,'5a57d87e-d37c-4041-a8a5-8751f50abd5a',NULL,NULL,76,'stock_faible','Stock faible','BULL IBO : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(265,'505f992d-ec12-43f4-86c4-11ffc892ad3b',NULL,NULL,77,'stock_faible','Stock faible','OMO VIVA CARTON DE 26 : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(266,'d8d7692b-b530-448a-b5bb-ed91c98c3180',NULL,NULL,78,'stock_faible','Stock faible','RIZ FESTIN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(267,'2f6f5052-bd72-4b29-b611-59274dd413df',NULL,NULL,79,'stock_faible','Stock faible','CLARK 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(268,'73d409fc-1d1d-4d52-88e1-7bfef838eaa4',NULL,NULL,80,'stock_faible','Stock faible','VODY 22% : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(269,'8dbb1a30-22a8-4e9b-8ea9-fe9d8171cbf9',NULL,NULL,81,'stock_faible','Stock faible','LAIT SUPER 8 : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(270,'18b2b22b-2d15-4140-b2dc-a2bf7763b372',NULL,NULL,82,'stock_faible','Stock faible','NONO 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(271,'ccc9f83d-46c0-4d8d-a13e-5d81bbbf8a14',NULL,NULL,83,'stock_faible','Stock faible','COUSCOUS LIDO : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(272,'1393f4b7-cd6b-44be-b380-e350d3f4c542',NULL,NULL,84,'stock_faible','Stock faible','YOUKI 0,5 LITRE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(273,'06400788-9bdf-463a-8b05-0b16420adfec',NULL,NULL,85,'stock_faible','Stock faible','GUINESS : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(274,'aa3b56fd-e8f1-4c5b-87dc-4c2aa61aeb4d',NULL,NULL,86,'stock_faible','Stock faible','BETA PETIT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(275,'1658f596-86e3-409f-b88a-29420d11131a',NULL,NULL,87,'stock_faible','Stock faible','LITTLE THAI : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(276,'4c3a5b3b-98ab-41d0-a03e-a88f1226a9be',NULL,NULL,88,'stock_faible','Stock faible','PJS 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(277,'9d14ea64-25ef-43d2-baf7-9b4db17c2da5',NULL,NULL,89,'stock_faible','Stock faible','DIVA ROYAL 25 KG SAC JAUNE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(278,'fdcd7275-db2d-417c-9a79-ca21279ea46d',NULL,NULL,90,'stock_faible','Stock faible','DIVA KAKI 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(279,'9d8149d3-6c69-497d-bff9-78d84a4f9a06',NULL,NULL,91,'stock_faible','Stock faible','ROOP 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(280,'8ab92e44-a90b-4294-a10a-243c01a6636b',NULL,NULL,92,'stock_faible','Stock faible','RIZ GINO 5KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(281,'6893393e-30b6-449a-89d7-0e56f203e378',NULL,NULL,93,'stock_faible','Stock faible','LAIT EN POUDRE GINNY : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(282,'04b0e323-1905-4615-b966-0bb2d7705296',NULL,NULL,94,'stock_faible','Stock faible','COQUILLETTE DIARI CARTON : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(283,'662a4932-2d0d-4672-bb6c-3fd30fc15b3a',NULL,NULL,95,'stock_faible','Stock faible','KANGAROU CASSE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(284,'ae2da466-dd12-4c6c-bc66-066b53082091',NULL,NULL,96,'stock_faible','Stock faible','DIVA SAC VIOLET 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(285,'2e03b4c9-7dee-4570-b07f-432b54dc36e9',NULL,NULL,97,'stock_faible','Stock faible','LUXE IBO 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(286,'9bc79f4e-5566-4441-bb62-af546aedbca6',NULL,NULL,98,'stock_faible','Stock faible','MAMAN PRETTY IBO 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(287,'f55c336b-23ad-4836-a3f4-d4babb4cc7fe',NULL,NULL,99,'stock_faible','Stock faible','TOMATE BENNY 400G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(288,'be78a7d9-2bc8-4058-8e5f-59d8df8d94e5',NULL,NULL,100,'stock_faible','Stock faible','COUSCOUS GINNY : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(289,'23b1beec-12d2-474c-93f4-4045cf44aef4',NULL,NULL,101,'stock_faible','Stock faible','OPPI UNIQUE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(290,'1aee7cba-c46a-407b-b4c3-85c92bd79ddd',NULL,NULL,102,'stock_faible','Stock faible','RAHI IBO 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(291,'ad6a9a89-765c-4a77-bd91-c544853c31d5',NULL,NULL,103,'stock_faible','Stock faible','CUBE ROYAL : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(292,'27fccb93-3b0b-4430-84e2-09798bcc7faa',NULL,NULL,104,'stock_faible','Stock faible','BAOBAB POUDRE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(293,'fe8b9c7a-53ea-4c53-b6d8-fbfdd3041d45',NULL,NULL,105,'stock_faible','Stock faible','SPAGHETTI DIARRI 500G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(294,'819c7174-9ebd-4dd0-b779-f22fe6be24cb',NULL,NULL,106,'stock_faible','Stock faible','SARDINE ALPHA CHEF : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(295,'8e3eb059-a03f-4c8b-bc43-94b9a92e6a2e',NULL,NULL,107,'stock_faible','Stock faible','FANTA PLASTIQUE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(296,'fdf0f0b1-400c-4bec-88ff-6febab8bc591',NULL,NULL,108,'stock_faible','Stock faible','BUDWEISER CANETTE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(297,'e6fb1dee-b9f7-4366-9973-3786e5b71f22',NULL,NULL,109,'stock_faible','Stock faible','TOMATE YOVO 70 G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(298,'3cf6ae4c-f969-4a0b-a738-c2a80536d095',NULL,NULL,110,'stock_faible','Stock faible','HEINEKEN PETIT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(299,'3ab96d3d-7224-48a8-8274-86b82bfde397',NULL,NULL,111,'stock_faible','Stock faible','BETA GRAND : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(300,'6a9af7cb-1b41-42d9-85bc-e0c6bd44f788',NULL,NULL,112,'stock_faible','Stock faible','SARDINE 222 : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(301,'194be807-5ee7-4074-8c6f-7de5c3252ade',NULL,NULL,113,'stock_faible','Stock faible','PRAGATI GOLD 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(302,'805dfd7c-cca8-4bbb-bf64-bd70f894ad90',NULL,NULL,114,'stock_faible','Stock faible','KATY 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(303,'9eabf7f6-1415-4334-bcbc-a60bb0d61ace',NULL,NULL,115,'stock_faible','Stock faible','JOKER 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(304,'ddd0dd5f-b7af-43e2-b8a7-ca4d469cb7d4',NULL,NULL,116,'stock_faible','Stock faible','GIL GIL CASSE 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(305,'78f78092-32d0-43a4-97cc-c8c4fdc35cf6',NULL,NULL,117,'stock_faible','Stock faible','DJOLOF 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(306,'bd517f97-6985-476a-891a-a76899526153',NULL,NULL,118,'stock_faible','Stock faible','VEDAN PETIT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(307,'3d85faa0-a345-426f-854c-7bcba8d5a6a9',NULL,NULL,119,'stock_faible','Stock faible','BEAU GARCON BASMATI 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(308,'1c729bf8-f919-4d6a-bb81-fb4560dae95e',NULL,NULL,120,'stock_faible','Stock faible','BEAU GARCON THAILANDAIS 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(309,'8318d283-a338-43ff-8b92-ee3e1daf1ae5',NULL,NULL,121,'stock_faible','Stock faible','JIYO 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(310,'893cc2b7-9c00-447e-b650-1c9e53ea1c11',NULL,NULL,122,'stock_faible','Stock faible','RIZ AAA 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(311,'3873aa7a-1f40-4c39-ad85-65dae2c35e34',NULL,NULL,123,'stock_faible','Stock faible','FOOTBALL 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(312,'a384d30f-4012-42fa-8fb9-e5e498a39485',NULL,NULL,124,'stock_faible','Stock faible','MEVIA EN PLASTIQUE 5 LITRES : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(313,'00f845df-066b-415e-8711-364f5e0af438',NULL,NULL,125,'stock_faible','Stock faible','SPAGHETTI 3 GOOD : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(314,'d5be1f18-f5ac-45fd-acd4-10239ab4e330',NULL,NULL,126,'stock_faible','Stock faible','COQUILLETTE 3 GOOD : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(315,'ea25fde8-59f9-434b-96b6-d111b19f7aa2',NULL,NULL,127,'stock_faible','Stock faible','LAIT CONCENTRE 3 GOOD : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(316,'566b9b4e-5519-4746-97e6-7020f1ed35c7',NULL,NULL,128,'stock_faible','Stock faible','TOMATE OD 3 GOOD : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(317,'2f1b32e0-f1a7-48ab-90a0-8ec0847eeca5',NULL,NULL,129,'stock_faible','Stock faible','OMO VIVA 800G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(318,'1aea06cc-ddf6-4907-8d19-36dc6883bdc7',NULL,NULL,130,'stock_faible','Stock faible','SAVON KANKPE CARTON DE 30 : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(319,'2e54c3fa-6dc7-494a-9e3d-f20f7771cd1a',NULL,NULL,131,'stock_faible','Stock faible','SAVON KANKPE DETAIL : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(320,'da841b1f-7afa-479b-a3b0-5883dede14b6',NULL,NULL,132,'stock_faible','Stock faible','STAR BIERE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(321,'1deed0c8-c6ac-47ce-9135-06603247c299',NULL,NULL,133,'stock_faible','Stock faible','RC CANETTE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(322,'00e5920a-7ede-478d-a6f5-29156d86b932',NULL,NULL,134,'stock_faible','Stock faible','RIZ IBO 8888 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(323,'886eed46-cd28-4453-a458-3f793d1308d8',NULL,NULL,135,'stock_faible','Stock faible','IBO DOUBLE ELEPHANT 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(324,'fb840d0a-7c50-40aa-88cf-ea6e55860524',NULL,NULL,136,'stock_faible','Stock faible','SARDINES JADU : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(325,'0f94d88d-bb11-45c6-8a86-475cb92a3f20',NULL,NULL,137,'stock_faible','Stock faible','COUSCOUS KOULHALA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(326,'2856cd88-f0e4-4c98-88ac-5bcf86fe5775',NULL,NULL,138,'stock_faible','Stock faible','PAON 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(327,'558e5144-0c5e-4d99-bcbe-69e4176d0a57',NULL,NULL,139,'stock_faible','Stock faible','SARDINES LOKKI : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(328,'895e2c4d-f050-4e66-84b4-5004b4f6204f',NULL,NULL,140,'stock_faible','Stock faible','SARDINES CLEMA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(329,'3953607b-9a4c-4166-8f07-73f519447f60',NULL,NULL,141,'stock_faible','Stock faible','ONIMA 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(330,'21854d57-3e5b-4644-a9b5-acd72760577f',NULL,NULL,142,'stock_faible','Stock faible','KT GOLD 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(331,'fa0f0e11-3e56-4859-9b21-d23b1782fd01',NULL,NULL,143,'stock_faible','Stock faible','SPAGHETTI BELINA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(332,'c99524ea-b13c-4861-927d-c0d2dc79ef55',NULL,NULL,144,'stock_faible','Stock faible','COUSCOUS FENA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(333,'fffdc284-a36a-417f-a409-90a6e8027a7f',NULL,NULL,145,'stock_faible','Stock faible','TOMATE YOVO 2200G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(334,'15cc659c-b3cf-433a-ae1b-9b4bbf067560',NULL,NULL,146,'stock_faible','Stock faible','PIVERT SAC VERT 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(335,'5dd6b45f-e9bd-4dd7-9ff3-1d630b4e6ebc',NULL,NULL,147,'stock_faible','Stock faible','PIVERT SAC VIOLET 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(336,'828d2f19-6e52-4438-a20d-686491ad8607',NULL,NULL,148,'stock_faible','Stock faible','STAR ORIGINAL BASMATI 25KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(337,'6aa52a74-c7bd-4162-98e5-3dd2a1aa6415',NULL,NULL,149,'stock_faible','Stock faible','FARM HOUSSE VERT 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(338,'29d3f5f9-0c04-4923-ae1c-d93ab61f77b7',NULL,NULL,150,'stock_faible','Stock faible','IBO JOLLOF GOLD 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(339,'eccba22a-b90e-4247-9890-44bc066b7eb4',NULL,NULL,151,'stock_faible','Stock faible','LEOPARD 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(340,'fc211656-7830-4a01-b8f5-5ecfa558317e',NULL,NULL,152,'stock_faible','Stock faible','MADHU CASSE 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(341,'703dfe02-168a-4733-8fe2-fab24fa50aa3',NULL,NULL,153,'stock_faible','Stock faible','LAIT EN POUDRE FAMILIA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(342,'9275a523-1b1b-474e-974d-3ea9c7dd5ca3',NULL,NULL,154,'stock_faible','Stock faible','SPAGHETTI MAGNIFICAT : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(343,'992e644e-4c5e-4a7a-8d95-4e3b7adf204b',NULL,NULL,155,'stock_faible','Stock faible','COQUILLETTE BELLA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(344,'0a4e9595-9fa1-4981-a920-4c13030e7aa2',NULL,NULL,156,'stock_faible','Stock faible','LAIT CONCENTRE MAGUIDA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(345,'5e6febe4-7776-422b-b882-3d319a721827',NULL,NULL,157,'stock_faible','Stock faible','LAIT CONCENTRE TOP SAHO : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(346,'a01ab343-c918-46a5-961b-ff7407a1d9e4',NULL,NULL,158,'stock_faible','Stock faible','LAIT CONCENTRE MY MILK : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(347,'aca2a6c0-e39d-43dc-b4e1-380681233bdb',NULL,NULL,159,'stock_faible','Stock faible','LAIT CONCENTRE UNITY : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(348,'ec2e8b38-231b-4201-8734-13d6c104461a',NULL,NULL,160,'stock_faible','Stock faible','TOMATE PSP 2200G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(349,'9a5a8219-fd44-47f6-b821-a0b49c5c6abe',NULL,NULL,161,'stock_faible','Stock faible','ONIMA 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(350,'77f49e87-697d-4a87-8b9d-be26565daae9',NULL,NULL,162,'stock_faible','Stock faible','CAFE BONJOURNE CARTON : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(351,'bb23b759-695a-49c3-bae8-534bb89ca4ba',NULL,NULL,163,'stock_faible','Stock faible','MILO FRESH CARTON : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(352,'54e9c68b-21e1-4c0a-97c8-5a7c5457b996',NULL,NULL,164,'stock_faible','Stock faible','BISSAP : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(353,'71ddc973-c7ac-4b39-8da3-3186af78be8e',NULL,NULL,165,'stock_faible','Stock faible','MYLY GOLD IBO 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(354,'ac472898-cf6a-406d-9bca-1ebcc9d5ca24',NULL,NULL,166,'stock_faible','Stock faible','OPPI SUPER 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(355,'f4fdeeb3-74a2-422f-8c72-53fe36fe658b',NULL,NULL,167,'stock_faible','Stock faible','OPPI POINTININI 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(356,'c0815e94-6fbe-4a6a-a517-7a5f2925b16a',NULL,NULL,168,'stock_faible','Stock faible','JOLIE 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(357,'86da97b8-f50f-434c-acd5-cc21f97194c1',NULL,NULL,169,'stock_faible','Stock faible','SARDINE DANU : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(358,'25a11e4d-381f-4f3e-9b94-7d5c76809c4f',NULL,NULL,170,'stock_faible','Stock faible','SAFARI RIZ BLANC 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(359,'5be7a258-3bb3-4f53-a6c2-5f63cf1a1bc9',NULL,NULL,171,'stock_faible','Stock faible','MAIS JAUNE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(360,'4482ada2-7574-4015-8913-aba7f21d8272',NULL,NULL,172,'stock_faible','Stock faible','SPAGHETTI BELLA : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(361,'6422504c-b446-4e3b-8daf-fbe6ecc6cf60',NULL,NULL,173,'stock_faible','Stock faible','JOLIE SAC ORANGE 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(362,'3f334a91-5424-4617-aab7-929c6f093614',NULL,NULL,174,'stock_faible','Stock faible','OMO WAVE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(363,'f2784cac-6da5-4990-ae9d-ab681a648e01',NULL,NULL,175,'stock_faible','Stock faible','INDOMIE GRAND : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(364,'e0dae1a6-a26f-4841-9a24-6f914b9fc55d',NULL,NULL,176,'stock_faible','Stock faible','SAGONO SPECIAL 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(365,'0c8df29f-405f-482e-8b50-6b2dfd72c22c',NULL,NULL,177,'stock_faible','Stock faible','LAIT TOUS LES JOURS : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(366,'0d3c0b55-7660-4a0f-80cc-a3e7ac179fa0',NULL,NULL,178,'stock_faible','Stock faible','PALMIDA BENIN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(367,'ce0b5dda-dde4-4b97-9803-562177d2bb48',NULL,NULL,179,'stock_faible','Stock faible','MAYONNAISE BONJOURNE GRAND : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(368,'75bf6261-8769-4d4e-bd7e-837eb9256a81',NULL,NULL,180,'stock_faible','Stock faible','SPAGHETTI BONJOURNE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(369,'2f43c661-91df-401d-8bf7-a1189861d1dd',NULL,NULL,181,'stock_faible','Stock faible','TIK TOK CASSE 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(370,'aa7345b9-3e08-484d-8424-35b617e91f48',NULL,NULL,182,'stock_faible','Stock faible','LATIF 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(371,'dedb66c7-383a-4757-9fd0-1b54c7dc17bd',NULL,NULL,183,'stock_faible','Stock faible','LEGENDE BIERE : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(372,'44255b49-4b53-4cd9-8051-2cae13da0ae7',NULL,NULL,184,'stock_faible','Stock faible','STAR CITRON : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(373,'dc2053ea-d87d-42a6-a5df-f415178617b6',NULL,NULL,185,'stock_faible','Stock faible','HARAKA VERT 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(374,'23647a92-1845-4ae7-950e-dd8754f6f98f',NULL,NULL,186,'stock_faible','Stock faible','RIZ BLANC ROSETTE 50 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:43','2026-08-18 21:10:43','2026-08-25 17:00:53'),
(375,'bea623e0-0def-4b42-81b8-106571e33e8a',NULL,NULL,187,'stock_faible','Stock faible','AWONLI PETIT GRAIN : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(376,'ae944f1d-aeb5-4507-a714-d43b6d4de4dd',NULL,NULL,188,'stock_faible','Stock faible','TOMATE JADU 2200G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(377,'603cdf50-5251-443e-8c61-8be4fb06ea8b',NULL,NULL,189,'stock_faible','Stock faible','GIL GIL LONG GRAIN 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(378,'1f2364a5-e057-4458-918c-f43b8964664b',NULL,NULL,190,'stock_faible','Stock faible','TOMATE AMINATA 2200G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(379,'db31c94c-806a-434f-8fd8-7afdce49ab0d',NULL,NULL,191,'stock_faible','Stock faible','TOMATE SALMA 2200G : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(380,'6b03ae5f-85f0-4a0a-8b2b-5ef34678d569',NULL,NULL,192,'stock_faible','Stock faible','TULIP 25 KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(381,'fa338690-aca6-4fd1-aa64-3e543f4808dc',NULL,NULL,193,'stock_faible','Stock faible','JOLI CLASSIC 50KG : 0 unité(s) (seuil : 5)','critique',0,'2026-08-18 23:10:44','2026-08-18 21:10:44','2026-08-25 17:00:53'),
(382,'01803960-de91-44fe-aa80-97e5fdc5e620',1,5,NULL,'echeance_jour','Échéance du jour','Maxim doit payer 3 750 FCFA aujourd\'hui.','info',0,'2026-08-18 22:00:00','2026-08-18 22:38:14','2026-08-18 23:23:58'),
(383,'93eda36a-4976-4760-b131-ce1a5462c447',2,6,NULL,'retard','Retard de paiement','AKOUTE : 1 jour(s) de retard. Restant : 6 150 FCFA.','info',0,'2026-08-25 17:00:53','2026-08-19 22:38:59','2026-08-25 17:00:53'),
(384,'66ec680b-a0af-425c-8a66-9b064133f869',2,6,NULL,'echeance_jour','Échéance du jour','AKOUTE doit payer 6 150 FCFA aujourd\'hui.','info',0,'2026-08-19 22:00:00','2026-08-20 12:48:32','2026-08-20 17:57:26'),
(385,'95c27032-208f-4609-9873-32c685cebfa6',1,5,NULL,'retard','Retard de paiement','Maxim : 1 jour(s) de retard. Restant : 3 750 FCFA.','info',0,'2026-08-25 17:00:53','2026-08-23 21:46:14','2026-08-25 17:00:53'),
(386,'65b27e92-2c97-430e-921e-27ac7c36764d',1,5,NULL,'echeance_jour','Échéance du jour','Maxim doit payer 3 750 FCFA aujourd\'hui.','info',0,'2026-08-23 22:00:00','2026-08-24 06:19:11','2026-08-24 20:44:08'),
(387,'fdb81c13-f048-4a67-b05e-d1ae4edb4f1f',2,6,NULL,'echeance_jour','Échéance du jour','AKOUTE doit payer 6 150 FCFA aujourd\'hui.','info',0,'2026-08-23 22:00:00','2026-08-24 06:19:11','2026-08-24 20:44:08'),
(388,'98344d7c-eb83-4cdf-a590-2081b49900f4',1,5,NULL,'echeance_jour','Échéance du jour','Maxim doit payer 3 750 FCFA aujourd\'hui.','info',0,'2026-08-24 22:00:00','2026-08-24 22:16:32','2026-08-25 15:53:08'),
(389,'41145378-70d7-4765-88d1-1830259badc4',2,6,NULL,'echeance_jour','Échéance du jour','AKOUTE doit payer 6 150 FCFA aujourd\'hui.','info',0,'2026-08-24 22:00:00','2026-08-24 22:16:32','2026-08-25 15:53:08');
/*!40000 ALTER TABLE `alertes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `approvisionnements`
--

DROP TABLE IF EXISTS `approvisionnements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `approvisionnements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `produit_id` bigint(20) unsigned NOT NULL,
  `quantite` decimal(10,2) NOT NULL,
  `prix_achat_unitaire` decimal(10,2) NOT NULL DEFAULT 0.00,
  `prix_vente_unitaire` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fournisseur` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `approvisionnements_uuid_unique` (`uuid`),
  KEY `approvisionnements_produit_id_foreign` (`produit_id`),
  KEY `approvisionnements_user_id_foreign` (`user_id`),
  CONSTRAINT `approvisionnements_produit_id_foreign` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE,
  CONSTRAINT `approvisionnements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approvisionnements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `approvisionnements` WRITE;
/*!40000 ALTER TABLE `approvisionnements` DISABLE KEYS */;
/*!40000 ALTER TABLE `approvisionnements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gerante_id` bigint(20) unsigned NOT NULL,
  `ancien_agent_id` bigint(20) unsigned NOT NULL,
  `nouvel_agent_id` bigint(20) unsigned NOT NULL,
  `nb_debiteurs_transferes` int(11) NOT NULL DEFAULT 0,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_gerante_id_foreign` (`gerante_id`),
  KEY `audit_logs_ancien_agent_id_foreign` (`ancien_agent_id`),
  KEY `audit_logs_nouvel_agent_id_foreign` (`nouvel_agent_id`),
  CONSTRAINT `audit_logs_ancien_agent_id_foreign` FOREIGN KEY (`ancien_agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `audit_logs_gerante_id_foreign` FOREIGN KEY (`gerante_id`) REFERENCES `users` (`id`),
  CONSTRAINT `audit_logs_nouvel_agent_id_foreign` FOREIGN KEY (`nouvel_agent_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `caisses`
--

DROP TABLE IF EXISTS `caisses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caisses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `date_ouverture` date NOT NULL,
  `date_fermeture` date DEFAULT NULL,
  `solde_initial` decimal(12,2) NOT NULL DEFAULT 0.00,
  `solde_theorique` decimal(12,2) NOT NULL DEFAULT 0.00,
  `solde_reel` decimal(12,2) DEFAULT NULL,
  `ecart` decimal(12,2) DEFAULT NULL,
  `statut` enum('ouverte','fermee') NOT NULL DEFAULT 'ouverte',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `periode` varchar(20) NOT NULL DEFAULT 'jour',
  `total_encaissements` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_decaissements` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_salaires` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_epargnes` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_penalites` decimal(12,2) NOT NULL DEFAULT 0.00,
  `agence_id` int(10) unsigned DEFAULT NULL,
  `type_caisse` varchar(20) DEFAULT 'agent',
  `caisse_parente_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `caisses_uuid_unique` (`uuid`),
  KEY `caisses_user_id_foreign` (`user_id`),
  CONSTRAINT `caisses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caisses`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `caisses` WRITE;
/*!40000 ALTER TABLE `caisses` DISABLE KEYS */;
INSERT INTO `caisses` VALUES
(1,'730012c0-31b8-4e32-aa36-4f1b8f0350ab',1,'2026-08-11',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-10 23:27:37','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(2,'2d150c45-9000-4161-9d1c-e5c2927cae92',1,'2026-08-12',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-12 14:46:25','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(3,'f261eea1-978a-4cea-bbff-43e5376fab34',1,'2026-08-14',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-14 04:42:31','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(4,'91dc74f3-a327-4480-80ba-9bf7b675198d',1,'2026-08-15','2026-08-23',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-15 11:15:13','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(5,'432877a3-0b4b-472d-97c2-7d42d2914ff7',1,'2026-08-17','2026-08-18',0.00,4000.00,NULL,NULL,'fermee',NULL,'2026-08-17 13:37:56','2026-08-24 19:18:30','jour',3700.00,0.00,0.00,300.00,0.00,1,'generale',NULL),
(6,'cc53218b-7a17-49c8-8516-9911197c7f2c',5,'2026-08-18','2026-08-19',4000.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-18 08:25:35','2026-08-24 19:01:47','jour',0.00,0.00,0.00,0.00,0.00,1,'agence',NULL),
(7,'c51e941f-cb11-4082-b19b-5a509bae67e7',3,'2026-08-18',NULL,0.00,6450.00,NULL,NULL,'ouverte',NULL,'2026-08-18 20:30:51','2026-08-24 19:01:47','jour',6150.00,0.00,0.00,300.00,0.00,1,'agent',NULL),
(8,'eb79bf14-30b1-458c-8e0a-928d6d236af7',5,'2026-08-19',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-18 22:34:57','2026-08-24 19:01:47','jour',0.00,0.00,0.00,0.00,0.00,1,'agence',NULL),
(9,'83c7a8a6-300e-4e81-bbe0-19a5bb2da7ce',3,'2026-08-19',NULL,0.00,4050.00,NULL,NULL,'ouverte',NULL,'2026-08-19 06:18:55','2026-08-24 19:01:47','jour',3750.00,0.00,0.00,300.00,0.00,1,'agent',NULL),
(10,'972d6249-c540-47f2-8121-9bd897fb0cf2',3,'2026-08-20',NULL,0.00,51919.77,NULL,NULL,'ouverte',NULL,'2026-08-19 22:36:02','2026-08-24 19:01:47','jour',40650.00,0.00,0.00,3000.00,8269.77,1,'agent',NULL),
(11,'bd546425-5a7a-4df8-a757-31205da7800a',3,'2026-08-22',NULL,0.00,16650.00,NULL,NULL,'ouverte',NULL,'2026-08-22 15:07:33','2026-08-24 19:01:47','jour',16050.00,0.00,0.00,600.00,0.00,1,'agent',NULL),
(12,'4147aa82-ea04-4c83-abba-7511ece7190d',1,'2026-08-23','2026-08-24',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-23 21:54:15','2026-08-24 19:18:30','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(13,'5ca021ad-7672-49c8-aa2a-02490cac34ea',1,'2026-08-24','2026-08-25',0.00,0.00,NULL,NULL,'fermee',NULL,'2026-08-24 06:20:52','2026-08-25 13:18:49','jour',0.00,0.00,0.00,0.00,0.00,1,'generale',NULL),
(14,'48762878-fa0a-4aaa-9062-5eef1f510c79',3,'2026-08-24',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-24 21:22:07','2026-08-24 21:22:07','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(15,'1289829e-465a-4604-ab2a-5d4b5e127656',5,'2026-08-24',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-24 21:22:07','2026-08-24 21:22:07','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(16,'fa2cb284-67bd-47c2-beb2-e4dd0c505415',1,'2026-08-25',NULL,0.00,0.00,NULL,NULL,'ouverte',NULL,'2026-08-25 13:18:49','2026-08-25 13:18:49','jour',0.00,0.00,0.00,0.00,0.00,NULL,'agent',NULL),
(17,'ed1ad87b-37e7-4b66-8b03-a53c910e96d1',3,'2026-08-25',NULL,0.00,9000.00,NULL,NULL,'ouverte',NULL,'2026-08-25 15:47:16','2026-08-25 15:47:57','jour',0.00,0.00,0.00,0.00,9000.00,NULL,'agent',NULL);
/*!40000 ALTER TABLE `caisses` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_nom_unique` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `clients_comptant`
--

DROP TABLE IF EXISTS `clients_comptant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients_comptant` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `quartier` varchar(255) DEFAULT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_comptant_uuid_unique` (`uuid`),
  KEY `clients_comptant_agent_id_foreign` (`agent_id`),
  CONSTRAINT `clients_comptant_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_comptant`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `clients_comptant` WRITE;
/*!40000 ALTER TABLE `clients_comptant` DISABLE KEYS */;
INSERT INTO `clients_comptant` VALUES
(1,'58117eed-f72f-45d8-a397-84ef6ab8e4e8','John SMITH','0143278322','',1,'2026-08-17 21:04:41','2026-08-17 21:04:41'),
(2,'d7637589-1d5a-45a5-8dfa-3871552717bd','John SMITH','0143278322','',5,'2026-08-18 22:37:36','2026-08-18 22:37:36'),
(3,'cb5b657e-b95b-43b8-b863-12d16a0cf32b','John SMITH','0143278322','',5,'2026-08-18 22:37:38','2026-08-18 22:37:38'),
(4,'3d6251f6-b7be-4872-855d-4c1c5bcbb9b8','John SMITH','0143278322','',5,'2026-08-18 22:37:39','2026-08-18 22:37:39'),
(5,'67f2ceb3-37ca-4d49-9bf0-fab59daba795','John SMITH','0143278322','',5,'2026-08-18 22:37:40','2026-08-18 22:37:40'),
(6,'f66fb23f-caf7-468d-a25a-8fbe080a1575','John SMITH','0143278322','',5,'2026-08-18 22:37:41','2026-08-18 22:37:41'),
(7,'ab4c4832-d44b-4c12-a9c7-9092ff585d4f','John SMITH','0143278322','',5,'2026-08-18 22:37:41','2026-08-18 22:37:41'),
(8,'0bb94942-4d57-4790-b21f-117f976c95b8','John SMITH','0143278322','',5,'2026-08-18 22:37:41','2026-08-18 22:37:41'),
(9,'ceb5b590-19ec-4bd7-83ec-0117a4b90045','John SMITH','0143278322','',5,'2026-08-18 22:37:41','2026-08-18 22:37:41'),
(10,'e39e4191-ed9f-4a05-823f-268110915657','John SMITH','0143278322','',5,'2026-08-18 22:37:42','2026-08-18 22:37:42'),
(11,'d0a13bda-3c51-48d2-a2d6-86bfebad0708','John SMITH','0143278322','',5,'2026-08-18 22:37:45','2026-08-18 22:37:45'),
(12,'4c67de95-65d7-4d72-bce2-03214e8bc4b8','John SMITH','0143278322','',5,'2026-08-18 22:37:46','2026-08-18 22:37:46'),
(13,'151d7b7a-b8f6-4d81-a7eb-5f6e3fe0ebcc','John SMITH','0143278322','',5,'2026-08-18 22:37:47','2026-08-18 22:37:47'),
(14,'d08fa1c4-d4c1-4e84-8c1f-8daf4fc970e1','John SMITH','0143278322','',5,'2026-08-18 22:37:47','2026-08-18 22:37:47'),
(15,'108efbd1-4a98-4e4c-8e96-55004c0c6617','John SMITH','0143278322','',5,'2026-08-18 22:37:47','2026-08-18 22:37:47');
/*!40000 ALTER TABLE `clients_comptant` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `debiteurs`
--

DROP TABLE IF EXISTS `debiteurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `debiteurs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `code_client` varchar(20) DEFAULT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `quartier` varchar(255) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `personne_reference_nom` varchar(255) DEFAULT NULL,
  `personne_reference_tel` varchar(255) DEFAULT NULL,
  `activite` varchar(255) DEFAULT NULL,
  `score_solvabilite` decimal(5,2) NOT NULL DEFAULT 1.00,
  `limite_credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `credits_autorises` int(10) unsigned NOT NULL DEFAULT 1,
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ancien_agent_id` bigint(20) unsigned DEFAULT NULL,
  `date_transfert` timestamp NULL DEFAULT NULL,
  `taux_recouvrement_au_transfert` decimal(5,2) DEFAULT NULL,
  `reste_a_payer_au_transfert` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `debiteurs_uuid_unique` (`uuid`),
  UNIQUE KEY `debiteurs_code_client_unique` (`code_client`),
  KEY `debiteurs_agent_id_foreign` (`agent_id`),
  KEY `debiteurs_ancien_agent_id_foreign` (`ancien_agent_id`),
  CONSTRAINT `debiteurs_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `debiteurs_ancien_agent_id_foreign` FOREIGN KEY (`ancien_agent_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debiteurs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `debiteurs` WRITE;
/*!40000 ALTER TABLE `debiteurs` DISABLE KEYS */;
INSERT INTO `debiteurs` VALUES
(1,'f3b914f4-67db-4f1e-9412-006112304171','CLI-AHOS0OBC',4,'HOMESSI','Clémence','0164913211','Atlantique > Abomey-Calavi > Togba > Maria-Gléta','Maison Jean',NULL,NULL,'Commerçante',50.00,0.00,1,0,'2026-08-15 19:17:48','2026-08-17 20:39:56',NULL,NULL,NULL,NULL),
(2,'c1cbb813-1b06-4b97-97e9-beca2ed42561','CLI-QUOVFD1G',2,'AKPO','Kenneth','0143276784','Littoral > Cotonou > 7eme > Vossa','Maison sous l\'eau',NULL,NULL,'Commerçant',50.00,0.00,1,0,'2026-08-15 19:28:14','2026-08-17 20:40:20',NULL,NULL,NULL,NULL),
(3,'878b6055-e4fe-4c09-960f-218ced74fdb0','CLI-FU89NJOO',3,'DOSSOU','WILSON','0143278322','Littoral > Cotonou > 7eme > Missite','Maison Smith',NULL,NULL,'Commerçant',50.00,0.00,1,0,'2026-08-17 13:42:46','2026-08-17 20:40:09',NULL,NULL,NULL,NULL),
(4,'d7f2d799-dbd3-43e0-b076-05aca682fb67','CLI-Y3QMWTV6',3,'KOUESSI','Anna','0165345609','Littoral > Cotonou > 4eme > Hounsa','Maison Dona',NULL,NULL,'Commerçante',50.00,0.00,1,0,'2026-08-17 20:08:41','2026-08-17 20:39:41',NULL,NULL,NULL,NULL),
(5,'53a59943-52d0-492e-b9ab-d148f17bf04b','CLI-YE7IDOYM',3,'Maxim','AKPO','0164913211','Littoral > Cotonou > 5eme > Datcha','Maison Jean','Wilfried Lawson','0165437854','Boutiquier',30.73,0.00,1,1,'2026-08-17 20:42:03','2026-08-25 15:58:52',NULL,NULL,NULL,NULL),
(6,'048e1567-9d55-4650-ada3-bcee9ed69207','CLI-VMCTI5GX',3,'AKOUTE','Desmond','0143278322','Littoral > Cotonou > 6eme > Vossa','Maison Smith','BOTCHI Paulin','0143275409','Commerçant',32.19,0.00,1,1,'2026-08-17 20:52:34','2026-08-25 15:57:20',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `debiteurs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `demandes_remboursement`
--

DROP TABLE IF EXISTS `demandes_remboursement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `demandes_remboursement` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `demandeur_id` bigint(20) unsigned NOT NULL,
  `validateur_id` bigint(20) unsigned DEFAULT NULL,
  `montant_credit_paye` decimal(12,2) NOT NULL,
  `montant_rembourse` decimal(12,2) NOT NULL,
  `montant_epargne_rembourse` decimal(12,2) NOT NULL,
  `statut` varchar(20) NOT NULL DEFAULT 'en_attente',
  `commentaire_gerante` text DEFAULT NULL,
  `date_validation` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `demandes_remboursement_uuid_unique` (`uuid`),
  KEY `demandes_remboursement_vente_id_foreign` (`vente_id`),
  KEY `demandes_remboursement_demandeur_id_foreign` (`demandeur_id`),
  KEY `demandes_remboursement_validateur_id_foreign` (`validateur_id`),
  CONSTRAINT `demandes_remboursement_demandeur_id_foreign` FOREIGN KEY (`demandeur_id`) REFERENCES `users` (`id`),
  CONSTRAINT `demandes_remboursement_validateur_id_foreign` FOREIGN KEY (`validateur_id`) REFERENCES `users` (`id`),
  CONSTRAINT `demandes_remboursement_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demandes_remboursement`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `demandes_remboursement` WRITE;
/*!40000 ALTER TABLE `demandes_remboursement` DISABLE KEYS */;
/*!40000 ALTER TABLE `demandes_remboursement` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `derogation_solvabilites`
--

DROP TABLE IF EXISTS `derogation_solvabilites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `derogation_solvabilites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `vente_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `score_au_moment` decimal(5,2) DEFAULT NULL,
  `motif` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `resultat_credit` varchar(30) NOT NULL DEFAULT 'en_cours',
  PRIMARY KEY (`id`),
  KEY `debiteur_id` (`debiteur_id`),
  KEY `vente_id` (`vente_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `derogation_solvabilites_ibfk_1` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `derogation_solvabilites_ibfk_2` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `derogation_solvabilites_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `derogation_solvabilites`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `derogation_solvabilites` WRITE;
/*!40000 ALTER TABLE `derogation_solvabilites` DISABLE KEYS */;
/*!40000 ALTER TABLE `derogation_solvabilites` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `echeances`
--

DROP TABLE IF EXISTS `echeances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `echeances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `date_echeance` date NOT NULL,
  `montant_prevu` decimal(12,2) NOT NULL,
  `montant_paye` decimal(12,2) NOT NULL DEFAULT 0.00,
  `statut` enum('en_attente','paye','partiel','en_retard','annule') NOT NULL DEFAULT 'en_attente',
  `jours_retard` int(11) NOT NULL DEFAULT 0,
  `date_paiement` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `echeances_uuid_unique` (`uuid`),
  KEY `echeances_vente_id_date_echeance_index` (`vente_id`,`date_echeance`),
  KEY `echeances_statut_date_echeance_index` (`statut`,`date_echeance`),
  CONSTRAINT `echeances_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `echeances`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `echeances` WRITE;
/*!40000 ALTER TABLE `echeances` DISABLE KEYS */;
INSERT INTO `echeances` VALUES
(1,'0c6e83ba-2179-43d9-8d2d-cb05b464452a',1,'2026-08-18',3750.00,3750.00,'paye',0,'2026-08-17','2026-08-17 20:59:49','2026-08-18 13:48:47'),
(2,'703d0bdd-4624-47ae-9ed1-b3bff0e61ebd',1,'2026-08-19',3750.00,3750.00,'paye',0,'2026-08-19','2026-08-17 20:59:49','2026-08-19 06:18:55'),
(3,'c17794df-0edd-4c8a-8f40-c2cb28f922f9',1,'2026-08-20',3750.00,3750.00,'paye',0,'2026-08-20','2026-08-17 20:59:49','2026-08-19 22:37:22'),
(4,'486f85a2-6815-4a27-a981-f9ebc2c62f7e',1,'2026-08-21',3750.00,3750.00,'paye',0,'2026-08-22','2026-08-17 20:59:49','2026-08-22 15:07:33'),
(5,'717c67e9-a17a-4b35-a260-8257647990fb',1,'2026-08-22',3750.00,0.00,'en_retard',3,NULL,'2026-08-17 20:59:49','2026-08-25 15:58:52'),
(6,'a18bf66e-5969-4b97-93d3-6cccf509b56b',1,'2026-08-23',3750.00,0.00,'en_retard',2,NULL,'2026-08-17 20:59:49','2026-08-25 15:58:52'),
(7,'3997833b-b566-44fe-b899-d1b001769baa',1,'2026-08-24',3750.00,0.00,'en_retard',1,NULL,'2026-08-17 20:59:49','2026-08-25 15:58:52'),
(8,'711490a4-72bb-4951-8a01-1690460fca20',1,'2026-08-25',3750.00,0.00,'en_retard',0,NULL,'2026-08-17 20:59:49','2026-08-25 15:58:52'),
(9,'bae43e5d-1843-483c-ac12-2408f4898299',1,'2026-08-26',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(10,'cfc410ae-5054-4f16-9588-5f7da2b54700',1,'2026-08-27',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(11,'d9837383-2b62-4ed5-a7c5-45af7bf2aa93',1,'2026-08-28',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(12,'495d2117-4a1d-41a4-a123-d6accede8bbf',1,'2026-08-29',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(13,'b0f20867-09da-481f-a894-0cbadc8000c6',1,'2026-08-30',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(14,'f803c345-2d72-47fc-bddd-237870c3ada8',1,'2026-08-31',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(15,'72320398-01d8-4e72-820b-2cdeec1542fe',1,'2026-09-01',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(16,'a73806e6-1ca7-418e-b365-6099802dd776',1,'2026-09-02',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(17,'df48db56-d770-405a-8686-cc614d368a37',1,'2026-09-03',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(18,'fa9582ef-d582-4ed7-9702-1f232f6ca822',1,'2026-09-04',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(19,'311fb348-5a18-4009-8d86-89e266b9e7a0',1,'2026-09-05',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(20,'35feea4c-685b-4926-a28c-9508bcb7486f',1,'2026-09-06',3750.00,0.00,'en_attente',0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(21,'32cd0bc7-3b43-4018-8f00-22e110b74470',2,'2026-08-18',6150.00,6150.00,'paye',0,'2026-08-20','2026-08-17 21:03:11','2026-08-20 20:14:58'),
(22,'a530ea95-99e7-4fab-96cf-97fcb2cc1a3b',2,'2026-08-19',6150.00,6150.00,'paye',0,'2026-08-20','2026-08-17 21:03:11','2026-08-20 21:05:16'),
(23,'3ce5ee23-f046-4690-a90a-1d92e3f85701',2,'2026-08-20',6150.00,6150.00,'paye',0,'2026-08-20','2026-08-17 21:03:11','2026-08-20 21:21:34'),
(24,'5b3fd319-53c3-4f92-9428-dfc13d2d175c',2,'2026-08-21',6150.00,6150.00,'paye',0,'2026-08-22','2026-08-17 21:03:11','2026-08-22 15:07:33'),
(25,'8328ec09-01d0-46ce-9ba6-9638def233d4',2,'2026-08-22',6150.00,6150.00,'paye',0,'2026-08-22','2026-08-17 21:03:11','2026-08-22 15:07:33'),
(26,'798a4fea-0aee-418e-b434-dbb2c768cb51',2,'2026-08-23',6150.00,0.00,'en_retard',2,NULL,'2026-08-17 21:03:11','2026-08-25 15:57:20'),
(27,'67f96605-2013-4ce7-acff-369f6242a090',2,'2026-08-24',6150.00,0.00,'en_retard',1,NULL,'2026-08-17 21:03:11','2026-08-25 15:57:20'),
(28,'c1b00919-5519-485c-89cb-6cef3717358c',2,'2026-08-25',6150.00,0.00,'en_retard',0,NULL,'2026-08-17 21:03:11','2026-08-25 15:57:20'),
(29,'82ed0635-a8b8-4ad6-ba80-4ae6405ec613',2,'2026-08-26',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(30,'752b805c-0565-4e9b-8281-6411058f14de',2,'2026-08-27',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(31,'50ac5b3a-2e7c-4e8e-8d81-767e44094771',2,'2026-08-28',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(32,'460fa7be-dc1e-42cb-8e14-af4e53dc21ea',2,'2026-08-29',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(33,'6637d8b2-c82e-4508-98e3-beeb72b5268f',2,'2026-08-30',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(34,'ed97ea64-a52f-4b03-8233-e69215a79a0d',2,'2026-08-31',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(35,'330b81f4-3f09-411c-9763-b7fd7229f655',2,'2026-09-01',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(36,'d843671a-43ec-4288-b67b-859fe8221053',2,'2026-09-02',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(37,'73014cdd-aefc-46fd-aaa0-de074a11059b',2,'2026-09-03',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(38,'07d16df4-20ff-49d4-ab11-9da8f3092705',2,'2026-09-04',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(39,'178a6c1b-f915-4122-a931-29773a6d9acd',2,'2026-09-05',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07'),
(40,'5b31d698-df6f-4ff8-adac-506e7daf31e1',2,'2026-09-06',6150.00,0.00,'en_attente',0,NULL,'2026-08-17 21:03:11','2026-08-20 12:43:07');
/*!40000 ALTER TABLE `echeances` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `epargnes`
--

DROP TABLE IF EXISTS `epargnes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `epargnes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_collecte` date NOT NULL,
  `statut` enum('collecte','recuperee') NOT NULL DEFAULT 'collecte',
  `recuperee_par` bigint(20) unsigned DEFAULT NULL,
  `date_recuperation` date DEFAULT NULL,
  `confirmation_client` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `epargnes_uuid_unique` (`uuid`),
  KEY `epargnes_vente_id_foreign` (`vente_id`),
  KEY `epargnes_debiteur_id_foreign` (`debiteur_id`),
  KEY `epargnes_recuperee_par_foreign` (`recuperee_par`),
  CONSTRAINT `epargnes_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `epargnes_recuperee_par_foreign` FOREIGN KEY (`recuperee_par`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `epargnes_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epargnes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `epargnes` WRITE;
/*!40000 ALTER TABLE `epargnes` DISABLE KEYS */;
INSERT INTO `epargnes` VALUES
(4,'9f596767-3259-4dc2-8303-04b9045f22ed',1,5,300.00,'2026-08-19','collecte',NULL,NULL,0,'2026-08-19 06:18:55','2026-08-19 06:18:55'),
(6,'8b5e477b-87f4-4cb4-9036-71916d4dd13e',1,5,300.00,'2026-08-20','collecte',NULL,NULL,0,'2026-08-19 22:37:22','2026-08-19 22:37:22'),
(11,'d14ab5a8-a677-4f13-902b-6873d5ab78f2',1,5,300.00,'2026-08-17','collecte',NULL,NULL,0,'2026-08-20 19:15:11','2026-08-20 19:15:11'),
(12,'c03c5be8-b6ee-4663-8486-200f5b6718bf',2,6,300.00,'2026-08-20','collecte',NULL,NULL,0,'2026-08-20 20:14:58','2026-08-20 20:14:58'),
(13,'58e7d0ce-cf2e-4afa-8b8b-ae152b66152b',2,6,300.00,'2026-08-20','collecte',NULL,NULL,0,'2026-08-20 21:05:16','2026-08-20 21:05:16'),
(14,'8b009275-9671-4024-9c89-4dbda10a2cb5',2,6,300.00,'2026-08-20','collecte',NULL,NULL,0,'2026-08-20 21:21:34','2026-08-20 21:21:34'),
(15,'61957a9b-3651-4cfb-a50e-ee207ae4ff5a',2,6,300.00,'2026-08-22','collecte',NULL,NULL,0,'2026-08-22 15:07:33','2026-08-22 15:07:33'),
(16,'bb7b2050-b49b-440e-a6cc-c3074b6ed50c',1,5,300.00,'2026-08-22','collecte',NULL,NULL,0,'2026-08-22 15:07:33','2026-08-22 15:07:33'),
(17,'586d6dd8-a14a-40e4-9e01-6581377ea679',2,6,-1000.00,'2026-08-25','collecte',NULL,NULL,0,'2026-08-25 15:48:06','2026-08-25 15:48:06'),
(18,'e7a020e2-2c8c-497d-863b-c6cdc2baa97b',1,5,-1000.00,'2026-08-25','collecte',NULL,NULL,0,'2026-08-25 15:48:15','2026-08-25 15:48:15');
/*!40000 ALTER TABLE `epargnes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `journals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `numero_ecriture` varchar(255) NOT NULL,
  `date_ecriture` date NOT NULL,
  `compte_debit` varchar(255) NOT NULL,
  `compte_credit` varchar(255) NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `montant_ht` decimal(12,2) DEFAULT NULL,
  `montant_tva` decimal(12,2) DEFAULT NULL,
  `montant_ttc` decimal(12,2) DEFAULT NULL,
  `taux_tva` decimal(5,2) DEFAULT 18.00,
  `libelle` varchar(255) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `recouvrement_id` bigint(20) unsigned DEFAULT NULL,
  `vente_id` bigint(20) unsigned DEFAULT NULL,
  `mouvement_caisse_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `journals_uuid_unique` (`uuid`),
  KEY `journals_recouvrement_id_foreign` (`recouvrement_id`),
  KEY `journals_vente_id_foreign` (`vente_id`),
  KEY `journals_mouvement_caisse_id_foreign` (`mouvement_caisse_id`),
  KEY `journals_user_id_foreign` (`user_id`),
  KEY `journals_date_ecriture_index` (`date_ecriture`),
  KEY `journals_compte_debit_index` (`compte_debit`),
  KEY `journals_compte_credit_index` (`compte_credit`),
  CONSTRAINT `journals_mouvement_caisse_id_foreign` FOREIGN KEY (`mouvement_caisse_id`) REFERENCES `mouvements_caisse` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journals_recouvrement_id_foreign` FOREIGN KEY (`recouvrement_id`) REFERENCES `recouvrements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `journals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `journals_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES
(1,'009a745f-8a98-428d-964f-bc12f2039126','ECR-20260817-EAKX','2026-08-17','411000','701000',75000.00,NULL,NULL,NULL,18.00,'Vente crédit Maxim','VTE-7ea546c4',NULL,1,NULL,1,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(2,'6a4f3e80-1900-4743-ba42-88f36cc4fb25','ECR-20260817-W5NO','2026-08-17','411000','701000',123000.00,NULL,NULL,NULL,18.00,'Vente crédit AKOUTE','VTE-bf517af3',NULL,2,NULL,1,'2026-08-17 21:03:11','2026-08-17 21:03:11'),
(3,'739170ac-f9a2-433f-8460-b5b690352402','ECR-20260817-3LAF','2026-08-17','521000','411000',3700.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-965813f4',1,1,NULL,1,'2026-08-17 21:14:29','2026-08-17 21:14:29'),
(4,'43627fd8-463d-4475-a1b1-0e1a38cc0bab','ECR-20260818-8IEG','2026-08-18','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-e417a46d',NULL,2,NULL,3,'2026-08-18 20:30:51','2026-08-18 20:30:51'),
(5,'65b275c5-755f-4746-8547-6e2c4a21e9ff','ECR-20260819-IIU2','2026-08-19','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-b3db80b2',3,1,NULL,3,'2026-08-19 06:18:55','2026-08-19 06:18:55'),
(6,'5e975705-19b4-444e-846f-28b732a59999','ECR-20260820-8UQY','2026-08-20','521000','758000',1025.02,NULL,NULL,NULL,18.00,'Pénalité retard 1.0250235993056j - AKOUTE','PENAL-92cf6415',NULL,NULL,NULL,3,'2026-08-19 22:36:02','2026-08-19 22:36:02'),
(7,'285b6a3b-793e-4b51-8b60-71f8bd1ef08f','ECR-20260820-JLIQ','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-f9f87a67',NULL,2,NULL,3,'2026-08-19 22:36:02','2026-08-19 22:36:02'),
(8,'f28362df-ace7-4733-a282-aee7bfd51f8a','ECR-20260820-CJ3O','2026-08-20','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-64155dd6',5,1,NULL,3,'2026-08-19 22:37:22','2026-08-19 22:37:22'),
(9,'68524661-5ca4-4977-8535-9c25751e53bf','ECR-20260820-TDQQ','2026-08-17','521000','758000',1651.35,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKPO','PENAL-5889f828',NULL,NULL,NULL,3,'2026-08-20 02:50:00','2026-08-20 02:50:00'),
(10,'3f43d719-7693-414d-88e7-b18f8b7b6a96','ECR-20260820-AVXJ','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-f8f5b333',NULL,2,NULL,3,'2026-08-20 10:49:51','2026-08-20 10:49:51'),
(11,'407db36d-5dff-4953-b4b9-8d5e9424a2c1','ECR-20260820-0LCQ','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-0a802adc',NULL,2,NULL,3,'2026-08-20 11:19:54','2026-08-20 11:19:54'),
(12,'fa4c0a26-6f5d-431e-a5fe-dd1925303c80','ECR-20260820-OVVX','2026-08-20','521000','758000',2593.40,NULL,NULL,NULL,18.00,'Pénalité retard 2.5934045772454j - AKOUTE','PENAL-5879a184',NULL,NULL,NULL,3,'2026-08-20 12:14:30','2026-08-20 12:14:30'),
(13,'a4581e6c-ea83-4aa5-b0e4-d5d4e7d993b6','ECR-20260820-MD1H','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-037aee07',8,2,NULL,3,'2026-08-20 20:14:58','2026-08-20 20:14:58'),
(14,'d9fa8616-78be-4bed-a552-8ee8e3dae8fb','ECR-20260820-0EVW','2026-08-20','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - Maxim','PENAL-cd50085b',NULL,NULL,NULL,3,'2026-08-20 20:24:45','2026-08-20 20:24:45'),
(15,'a1387a34-45df-4641-8ca2-3066037dbe9e','ECR-20260820-ULVK','2026-08-20','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKOUTE','PENAL-d71e9194',NULL,NULL,NULL,3,'2026-08-20 20:25:09','2026-08-20 20:25:09'),
(16,'5ccff7c8-9cb2-4254-a08f-00e7920565b5','ECR-20260820-UCVE','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-23c42791',9,2,NULL,3,'2026-08-20 21:05:16','2026-08-20 21:05:16'),
(17,'75c473b2-bb8a-493e-9aaa-7cdc9d1c10fb','ECR-20260820-JBUI','2026-08-20','521000','411000',6150.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-93a769c1',10,2,NULL,3,'2026-08-20 21:21:34','2026-08-20 21:21:34'),
(18,'d8e767f2-f0f7-46f9-a899-3b40e4aa5663','ECR-20260822-YJ8I','2026-08-22','521000','411000',12300.00,NULL,NULL,NULL,18.00,'Encaissement AKOUTE - Vente #bf517af3','REC-0aa1acd2',11,2,NULL,3,'2026-08-22 15:07:33','2026-08-22 15:07:33'),
(19,'3a413b8c-63e4-4610-83b5-49007f09afb6','ECR-20260822-Z6ZN','2026-08-22','521000','411000',3750.00,NULL,NULL,NULL,18.00,'Encaissement Maxim - Vente #7ea546c4','REC-90f95ce0',12,1,NULL,3,'2026-08-22 15:07:33','2026-08-22 15:07:33'),
(20,'b45e74e4-6b6f-4383-89b4-0f96c8b34998','ECR-20260825-AXBQ','2026-08-25','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - Maxim','PENAL-c04c79bc',NULL,NULL,NULL,3,'2026-08-25 15:47:16','2026-08-25 15:47:16'),
(21,'dcaa1767-4c5b-40fe-8475-ebd4127006bf','ECR-20260825-GLGN','2026-08-25','521000','758000',3000.00,NULL,NULL,NULL,18.00,'Pénalité retard 3j - Maxim','PENAL-fd30e325',NULL,NULL,NULL,3,'2026-08-25 15:47:24','2026-08-25 15:47:24'),
(22,'69f6d4f8-70d1-4c38-b60f-5e1a793c50db','ECR-20260825-MHML','2026-08-25','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - Maxim','PENAL-45fd29f6',NULL,NULL,NULL,3,'2026-08-25 15:47:37','2026-08-25 15:47:37'),
(23,'6a913fa8-d997-456e-a177-05d11d8da00d','ECR-20260825-HQBP','2026-08-25','521000','758000',1000.00,NULL,NULL,NULL,18.00,'Pénalité retard 1j - AKOUTE','PENAL-c3569e4e',NULL,NULL,NULL,3,'2026-08-25 15:47:46','2026-08-25 15:47:46'),
(24,'699f5459-5709-4417-a468-5e35bb7fb9ed','ECR-20260825-BCHR','2026-08-25','521000','758000',2000.00,NULL,NULL,NULL,18.00,'Pénalité retard 2j - AKOUTE','PENAL-e997b479',NULL,NULL,NULL,3,'2026-08-25 15:47:57','2026-08-25 15:47:57');
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `localisations`
--

DROP TABLE IF EXISTS `localisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `localisations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `parent_nom` varchar(255) DEFAULT NULL,
  `parent_type` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1032 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localisations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `localisations` WRITE;
/*!40000 ALTER TABLE `localisations` DISABLE KEYS */;
INSERT INTO `localisations` VALUES
(1,'departement','Alibori',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(2,'departement','Atacora',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(3,'departement','Atlantique',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(4,'departement','Borgou',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(5,'departement','Collines',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(6,'departement','Couffo',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(7,'departement','Donga',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(8,'departement','Littoral',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(9,'departement','Mono',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(10,'departement','Oueme',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(11,'departement','Plateau',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(12,'departement','Zou',NULL,NULL,'2026-08-12 12:43:31','2026-08-12 12:43:31'),
(13,'commune','Banikoara','Alibori','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(14,'arrondissement','Founougo','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(15,'arrondissement','Gomparou','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(16,'arrondissement','Goumori','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(17,'arrondissement','Kokey','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(18,'arrondissement','Kokiborou','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(19,'arrondissement','Ounet','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(20,'arrondissement','Somperoukou','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(21,'arrondissement','Soroko','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(22,'arrondissement','Toura','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(23,'arrondissement','Banikoara','Banikoara','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(24,'commune','Gogounou','Alibori','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(25,'arrondissement','Bagou','Gogounou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(26,'arrondissement','Gounarou','Gogounou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(27,'arrondissement','Sori','Gogounou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(28,'arrondissement','Sougou-Kpan-Trossi','Gogounou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(29,'arrondissement','Wara','Gogounou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(30,'arrondissement','Gogounou','Gogounou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(31,'commune','Kandi','Alibori','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(32,'arrondissement','Angaradebou','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(33,'arrondissement','Bensekou','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(34,'arrondissement','Donwari','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(35,'arrondissement','Kassakou','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(36,'arrondissement','Saah','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(37,'arrondissement','Sam','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(38,'arrondissement','Sonsoro','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(39,'arrondissement','Kandi 1','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(40,'arrondissement','Kandi 2','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(41,'arrondissement','Kandi 3','Kandi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(42,'commune','Karimama','Alibori','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(43,'arrondissement','Birni Lafia','Karimama','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(44,'arrondissement','Bogo-Bogo','Karimama','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(45,'arrondissement','Kompa','Karimama','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(46,'arrondissement','Monsey','Karimama','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(47,'arrondissement','Karimama','Karimama','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(48,'commune','Malanville','Alibori','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(49,'arrondissement','Garou','Malanville','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(50,'arrondissement','Guene','Malanville','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(51,'arrondissement','Madecali','Malanville','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(52,'arrondissement','Toumboutou','Malanville','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(53,'arrondissement','Malanville','Malanville','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(54,'commune','Segbana','Alibori','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(55,'arrondissement','Libante','Segbana','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(56,'arrondissement','Liboussou','Segbana','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(57,'arrondissement','Lougou','Segbana','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(58,'arrondissement','Sokotindji','Segbana','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(59,'arrondissement','Segbana','Segbana','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(60,'commune','Boukoumbe','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(61,'arrondissement','Dipoli','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(62,'arrondissement','Korontiere','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(63,'arrondissement','Koussoucoingou','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(64,'arrondissement','Manta','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(65,'arrondissement','Nata','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(66,'arrondissement','Tabota','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(67,'arrondissement','Boukoumbe','Boukoumbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(68,'commune','Cobly','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(69,'arrondissement','Datori','Cobly','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(70,'arrondissement','Kountori','Cobly','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(71,'arrondissement','Tapoga','Cobly','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(72,'arrondissement','Cobly','Cobly','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(73,'commune','Kerou','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(74,'arrondissement','Brignamaro','Kerou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(75,'arrondissement','Firou','Kerou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(76,'arrondissement','Kaobagou','Kerou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(77,'arrondissement','Kerou','Kerou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(78,'commune','Kouande','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(79,'arrondissement','Birni','Kouande','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(80,'arrondissement','Chabi-Couma','Kouande','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(81,'arrondissement','Foo-Tance','Kouande','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(82,'arrondissement','Guilmaro','Kouande','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(83,'arrondissement','Oroukayo','Kouande','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(84,'arrondissement','Kouande','Kouande','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(85,'commune','Materi','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(86,'arrondissement','Dassari','Materi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(87,'arrondissement','Gouande','Materi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(88,'arrondissement','Nodi','Materi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(89,'arrondissement','Tantega','Materi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(90,'arrondissement','Tchanhouncossi','Materi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(91,'arrondissement','Materi','Materi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(92,'commune','Natitingou','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(93,'arrondissement','Kotopounga','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(94,'arrondissement','Kouaba','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(95,'arrondissement','Kouandata','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(96,'arrondissement','Perma','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(97,'arrondissement','Tchoumi-Tchoumi','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(98,'arrondissement','Natitingou I','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(99,'arrondissement','Natitingou II','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(100,'arrondissement','Natitingou III','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(101,'arrondissement','Peporiyakou','Natitingou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(102,'commune','Ouassa-Pehunco','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(103,'arrondissement','Gnemasson','Ouassa-Pehunco','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(104,'arrondissement','Tobre','Ouassa-Pehunco','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(105,'arrondissement','Pehunco','Ouassa-Pehunco','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(106,'commune','Tanguieta','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(107,'arrondissement','Cotiakou','Tanguieta','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(108,'arrondissement','NDahonta','Tanguieta','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(109,'arrondissement','Taiacou','Tanguieta','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(110,'arrondissement','Tanongou','Tanguieta','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(111,'arrondissement','Tanguieta','Tanguieta','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(112,'commune','Toukountouna','Atacora','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(113,'arrondissement','Kouarfa','Toukountouna','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(114,'arrondissement','Tampegre','Toukountouna','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(115,'arrondissement','Toukountouna','Toukountouna','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(116,'commune','Abomey-Calavi','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(117,'arrondissement','Akassato','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(118,'arrondissement','Godomey','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(119,'arrondissement','Golo-Djigbe','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(120,'arrondissement','Hevie','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(121,'arrondissement','Kpanroun','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(122,'arrondissement','Ouedo','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(123,'arrondissement','Togba','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(124,'arrondissement','Zinvie','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(125,'arrondissement','Abomey-Calavi','Abomey-Calavi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(126,'commune','Allada','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(127,'arrondissement','Agbanou','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(128,'arrondissement','Ahouannonzoun','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(129,'arrondissement','Attogon','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(130,'arrondissement','Avakpa','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(131,'arrondissement','Ayou','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(132,'arrondissement','Hinvi','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(133,'arrondissement','Lissegazoun','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(134,'arrondissement','Lon-Agonmey','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(135,'arrondissement','Sekou','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(136,'arrondissement','Tokpa','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(137,'arrondissement','Allada Centre','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(138,'arrondissement','Togoudo','Allada','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(139,'commune','Kpomasse','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(140,'arrondissement','Aganmalome','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(141,'arrondissement','Agbanto','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(142,'arrondissement','Agonkanme','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(143,'arrondissement','Dedome','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(144,'arrondissement','Dekanme','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(145,'arrondissement','Segbeya','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(146,'arrondissement','Segbohoue','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(147,'arrondissement','Tokpa-Dome','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(148,'arrondissement','Kpomasse Centre','Kpomasse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(149,'commune','Ouidah','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(150,'arrondissement','Avlekete','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(151,'arrondissement','Djegbadji','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(152,'arrondissement','Gakpe','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(153,'arrondissement','Houakpe-Daho','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(154,'arrondissement','Pahou','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(155,'arrondissement','Savi','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(156,'arrondissement','Ouidah I','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(157,'arrondissement','Ouidah II','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(158,'arrondissement','Ouidah III','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(159,'arrondissement','Ouidah IV','Ouidah','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(160,'commune','So-Ava','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(161,'arrondissement','Ahomey-Lokpo','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(162,'arrondissement','Dekanmey','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(163,'arrondissement','Ganvie 1','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(164,'arrondissement','Ganvie 2','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(165,'arrondissement','Houedo-Aguekon','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(166,'arrondissement','Vekky','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(167,'arrondissement','So-Ava','So-Ava','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(168,'commune','Toffo','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(169,'arrondissement','Ague','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(170,'arrondissement','Colli','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(171,'arrondissement','Coussi','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(172,'arrondissement','Dame','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(173,'arrondissement','Djanglanme','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(174,'arrondissement','Houegbo','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(175,'arrondissement','Kpome','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(176,'arrondissement','Sehoue','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(177,'arrondissement','Sey','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(178,'arrondissement','Toffo','Toffo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(179,'commune','Tori-Bossito','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(180,'arrondissement','Avame','Tori-Bossito','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(181,'arrondissement','Azohoue-Aliho','Tori-Bossito','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(182,'arrondissement','Azohoue-Cada','Tori-Bossito','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(183,'arrondissement','Tori-Cada','Tori-Bossito','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(184,'arrondissement','Tori-Gare','Tori-Bossito','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(185,'arrondissement','Tori-Bossito','Tori-Bossito','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(186,'commune','Ze','Atlantique','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(187,'arrondissement','Adjan','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(188,'arrondissement','Dawe','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(189,'arrondissement','Djigbe','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(190,'arrondissement','Dodji-Bata','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(191,'arrondissement','Hekanme','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(192,'arrondissement','Koundokpoe','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(193,'arrondissement','Sedje-Denou','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(194,'arrondissement','Sedje-Houegoudo','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(195,'arrondissement','Tangbo','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(196,'arrondissement','Yokpo','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(197,'arrondissement','Ze','Ze','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(198,'commune','Bembereke','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(199,'arrondissement','Beroubouay','Bembereke','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(200,'arrondissement','Bouanri','Bembereke','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(201,'arrondissement','Gamia','Bembereke','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(202,'arrondissement','Ina','Bembereke','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(203,'arrondissement','Bembereke','Bembereke','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(204,'commune','Kalale','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(205,'arrondissement','Basso','Kalale','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(206,'arrondissement','Bouca','Kalale','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(207,'arrondissement','Derassi','Kalale','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(208,'arrondissement','Dunkassa','Kalale','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(209,'arrondissement','Peonga','Kalale','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(210,'arrondissement','Kalale','Kalale','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(211,'commune','NDali','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(212,'arrondissement','Bori','NDali','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(213,'arrondissement','Gbegourou','NDali','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(214,'arrondissement','Ouenou','NDali','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(215,'arrondissement','Sirarou','NDali','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(216,'arrondissement','NDali','NDali','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(217,'commune','Nikki','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(218,'arrondissement','Biro','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(219,'arrondissement','Gnonkourokali','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(220,'arrondissement','Ouenou','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(221,'arrondissement','Serekali','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(222,'arrondissement','Suya','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(223,'arrondissement','Tasso','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(224,'arrondissement','Nikki','Nikki','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(225,'commune','Parakou','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(226,'arrondissement','1er Arrondissement','Parakou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(227,'arrondissement','2eme Arrondissement','Parakou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(228,'arrondissement','3eme Arrondissement','Parakou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(229,'commune','Perere','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(230,'arrondissement','Gninsy','Perere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(231,'arrondissement','Guinagourou','Perere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(232,'arrondissement','Kpebie','Perere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(233,'arrondissement','Pane','Perere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(234,'arrondissement','Sontou','Perere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(235,'arrondissement','Perere','Perere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(236,'commune','Sinende','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(237,'arrondissement','Fo-Boure','Sinende','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(238,'arrondissement','Sekere','Sinende','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(239,'arrondissement','Sikki','Sinende','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(240,'arrondissement','Sinende','Sinende','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(241,'commune','Tchaourou','Borgou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(242,'arrondissement','Alafiarou','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(243,'arrondissement','Beterou','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(244,'arrondissement','Goro','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(245,'arrondissement','Kika','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(246,'arrondissement','Sanson','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(247,'arrondissement','Tchatchou','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(248,'arrondissement','Tchaourou','Tchaourou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(249,'commune','Bante','Collines','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(250,'arrondissement','Agoua','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(251,'arrondissement','Akpassi','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(252,'arrondissement','Atokolibe','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(253,'arrondissement','Bobe','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(254,'arrondissement','Gouka','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(255,'arrondissement','Koko','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(256,'arrondissement','Lougba','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(257,'arrondissement','Pira','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(258,'arrondissement','Bante','Bante','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(259,'commune','Dassa-Zoume','Collines','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(260,'arrondissement','Akoffodjoule','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(261,'arrondissement','Gbaffo','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(262,'arrondissement','Kere','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(263,'arrondissement','Kpingni','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(264,'arrondissement','Lema','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(265,'arrondissement','Paouingnan','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(266,'arrondissement','Soclogbo','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(267,'arrondissement','Tre','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(268,'arrondissement','Dassa I','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(269,'arrondissement','Dassa II','Dassa-Zoume','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(270,'commune','Glazoue','Collines','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(271,'arrondissement','Aklampa','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(272,'arrondissement','Assante','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(273,'arrondissement','Gome','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(274,'arrondissement','Kpakpaza','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(275,'arrondissement','Magoumi','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(276,'arrondissement','Ouedeme','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(277,'arrondissement','Sokponta','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(278,'arrondissement','Thio','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(279,'arrondissement','Zaffe','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(280,'arrondissement','Glazoue','Glazoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(281,'commune','Ouesse','Collines','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(282,'arrondissement','Challa-Ogoi','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(283,'arrondissement','Djegbe','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(284,'arrondissement','Gbanlin','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(285,'arrondissement','Ikemon','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(286,'arrondissement','Kilibo','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(287,'arrondissement','Laminou','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(288,'arrondissement','Odougba','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(289,'arrondissement','Toui','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(290,'arrondissement','Ouesse','Ouesse','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(291,'commune','Savalou','Collines','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(292,'arrondissement','Djalloukou','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(293,'arrondissement','Doume','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(294,'arrondissement','Gobada','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(295,'arrondissement','Kpataba','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(296,'arrondissement','Lahotan','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(297,'arrondissement','Lema','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(298,'arrondissement','Logozohe','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(299,'arrondissement','Monkpa','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(300,'arrondissement','Ottola','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(301,'arrondissement','Tchetti','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(302,'arrondissement','Savalou-Aga','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(303,'arrondissement','Savalou-Agbado','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(304,'arrondissement','Savalou-Attake','Savalou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(305,'commune','Save','Collines','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(306,'arrondissement','Besse','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(307,'arrondissement','Kaboua','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(308,'arrondissement','Offe','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(309,'arrondissement','Okpara','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(310,'arrondissement','Sakin','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(311,'arrondissement','Adido','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(312,'arrondissement','Boni','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(313,'arrondissement','Plateau','Save','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(314,'commune','Aplahoue','Couffo','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(315,'arrondissement','Atomey','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(316,'arrondissement','Azove','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(317,'arrondissement','Dekpo-Centre','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(318,'arrondissement','Godohou','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(319,'arrondissement','Kissamey','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(320,'arrondissement','Lonkly','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(321,'arrondissement','Aplahoue','Aplahoue','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(322,'commune','Djakotomey','Couffo','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(323,'arrondissement','Adjintimey','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(324,'arrondissement','Betoumey','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(325,'arrondissement','Gohomey','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(326,'arrondissement','Houegamey','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(327,'arrondissement','Kinkinhoue','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(328,'arrondissement','Kokohoue','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(329,'arrondissement','Kpoba','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(330,'arrondissement','Sokouhoue','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(331,'arrondissement','Djakotomey I','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(332,'arrondissement','Djakotomey II','Djakotomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(333,'commune','Dogbo','Couffo','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(334,'arrondissement','Ayomi','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(335,'arrondissement','Deve','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(336,'arrondissement','Honton','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(337,'arrondissement','Lokogohoue','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(338,'arrondissement','Madjre','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(339,'arrondissement','Totchangni Centre','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(340,'arrondissement','Tota','Dogbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(341,'commune','Klouekanmey','Couffo','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(342,'arrondissement','Adjahonme','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(343,'arrondissement','Ahogbeya','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(344,'arrondissement','Ayahohoue','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(345,'arrondissement','Djotto','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(346,'arrondissement','Hondjin','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(347,'arrondissement','Lanta','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(348,'arrondissement','Tchikpe','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(349,'arrondissement','Klouekanme','Klouekanmey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(350,'commune','Lalo','Couffo','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(351,'arrondissement','Adoukandji','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(352,'arrondissement','Ahodjinnako','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(353,'arrondissement','Ahomadegbe','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(354,'arrondissement','Banigbe','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(355,'arrondissement','Gnizounme','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(356,'arrondissement','Hlassame','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(357,'arrondissement','Lokogba','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(358,'arrondissement','Tchito','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(359,'arrondissement','Tohou','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(360,'arrondissement','Zalli','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(361,'arrondissement','Lalo','Lalo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(362,'commune','Toviklin','Couffo','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(363,'arrondissement','Adjido','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(364,'arrondissement','Avedjin','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(365,'arrondissement','Doko','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(366,'arrondissement','Houedogli','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(367,'arrondissement','Missinko','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(368,'arrondissement','Tannou-Gola','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(369,'arrondissement','Toviklin','Toviklin','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(370,'commune','Bassila','Donga','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(371,'arrondissement','Aledjo','Bassila','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(372,'arrondissement','Manigri','Bassila','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(373,'arrondissement','Penessoulou','Bassila','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(374,'arrondissement','Bassila','Bassila','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(375,'commune','Copargo','Donga','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(376,'arrondissement','Anandana','Copargo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(377,'arrondissement','Pabegou','Copargo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(378,'arrondissement','Singre','Copargo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(379,'arrondissement','Copargo','Copargo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(380,'commune','Djougou','Donga','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(381,'arrondissement','Barei','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(382,'arrondissement','Barienou','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(383,'arrondissement','Bellefoungou','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(384,'arrondissement','Bougou','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(385,'arrondissement','Koloconde','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(386,'arrondissement','Onklou','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(387,'arrondissement','Partago','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(388,'arrondissement','Pelebina','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(389,'arrondissement','Serou','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(390,'arrondissement','Djougou I','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(391,'arrondissement','Djougou II','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(392,'arrondissement','Djougou III','Djougou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(393,'commune','Ouake','Donga','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(394,'arrondissement','Badjoude','Ouake','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(395,'arrondissement','Komde','Ouake','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(396,'arrondissement','Semere 1','Ouake','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(397,'arrondissement','Semere 2','Ouake','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(398,'arrondissement','Tchalinga','Ouake','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(399,'arrondissement','Ouake','Ouake','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(400,'commune','Cotonou','Littoral','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(401,'arrondissement','1er','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(402,'arrondissement','2eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(403,'arrondissement','3eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(404,'arrondissement','4eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(405,'arrondissement','5eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(406,'arrondissement','6eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(407,'arrondissement','7eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(408,'arrondissement','8eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(409,'arrondissement','9eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(410,'arrondissement','10eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(411,'arrondissement','11eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(412,'arrondissement','12eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(413,'arrondissement','13eme','Cotonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(414,'commune','Athieme','Mono','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(415,'arrondissement','Adohoun','Athieme','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(416,'arrondissement','Atchannou','Athieme','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(417,'arrondissement','Dedekpoe','Athieme','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(418,'arrondissement','Kpinnou','Athieme','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(419,'arrondissement','Athieme','Athieme','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(420,'commune','Bopa','Mono','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(421,'arrondissement','Agbodji','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(422,'arrondissement','Badazouin','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(423,'arrondissement','Gbakpodji','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(424,'arrondissement','Lobogo','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(425,'arrondissement','Possotome','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(426,'arrondissement','Yegodoe','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(427,'arrondissement','Bopa','Bopa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(428,'commune','Come','Mono','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(429,'arrondissement','Agatogbo','Come','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(430,'arrondissement','Akodeha','Come','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(431,'arrondissement','Ouedeme-Pedah','Come','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(432,'arrondissement','Oumako','Come','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(433,'arrondissement','Come','Come','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(434,'commune','Grand-Popo','Mono','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(435,'arrondissement','Adjaha','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(436,'arrondissement','Agoue','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(437,'arrondissement','Avlo','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(438,'arrondissement','Djanglanmey','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(439,'arrondissement','Gbehoue','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(440,'arrondissement','Sazue','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(441,'arrondissement','Grand-Popo','Grand-Popo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(442,'commune','Houeyogbe','Mono','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(443,'arrondissement','Dahe','Houeyogbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(444,'arrondissement','Doutou','Houeyogbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(445,'arrondissement','Honhoue','Houeyogbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(446,'arrondissement','Zoungbonou','Houeyogbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(447,'arrondissement','Houeyogbe','Houeyogbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(448,'arrondissement','Se','Houeyogbe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(449,'commune','Lokossa','Mono','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(450,'arrondissement','Agame','Lokossa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(451,'arrondissement','Houin','Lokossa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(452,'arrondissement','Koudo','Lokossa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(453,'arrondissement','Ouedeme-Adja','Lokossa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(454,'arrondissement','Lokossa','Lokossa','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(455,'commune','Adjarra','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(456,'arrondissement','Aglogbe','Adjarra','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(457,'arrondissement','Honvie','Adjarra','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(458,'arrondissement','Malanhoui','Adjarra','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(459,'arrondissement','Mededjonou','Adjarra','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(460,'arrondissement','Adjarra 1','Adjarra','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(461,'arrondissement','Adjarra 2','Adjarra','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(462,'commune','Adjohoun','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(463,'arrondissement','Akpadanou','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(464,'arrondissement','Awonou','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(465,'arrondissement','Azowlisse','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(466,'arrondissement','Deme','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(467,'arrondissement','Gangban','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(468,'arrondissement','Kode','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(469,'arrondissement','Togbota','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(470,'arrondissement','Adjohoun','Adjohoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(471,'commune','Aguegues','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(472,'arrondissement','Avagbodji','Aguegues','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(473,'arrondissement','Houedome','Aguegues','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(474,'arrondissement','Zoungame','Aguegues','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(475,'commune','Akpro-Misserete','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(476,'arrondissement','Gome-Sota','Akpro-Misserete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(477,'arrondissement','Katagon','Akpro-Misserete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(478,'arrondissement','Vakon','Akpro-Misserete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(479,'arrondissement','Zoungbome','Akpro-Misserete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(480,'arrondissement','Akpro-Misserete','Akpro-Misserete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(481,'commune','Avrankou','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(482,'arrondissement','Atchoukpa','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(483,'arrondissement','Djomon','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(484,'arrondissement','Gbozoume','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(485,'arrondissement','Kouti','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(486,'arrondissement','Ouanho','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(487,'arrondissement','Sado','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(488,'arrondissement','Avrankou','Avrankou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(489,'commune','Bonou','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(490,'arrondissement','Affame','Bonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(491,'arrondissement','Atchonsa','Bonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(492,'arrondissement','Dame-Wogon','Bonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(493,'arrondissement','Hounvigue','Bonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(494,'arrondissement','Bonou','Bonou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(495,'commune','Dangbo','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(496,'arrondissement','Dekin','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(497,'arrondissement','Gbeko','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(498,'arrondissement','Houedomey','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(499,'arrondissement','Hozin','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(500,'arrondissement','Kessounou','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(501,'arrondissement','Zoungue','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(502,'arrondissement','Dangbo','Dangbo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(503,'commune','Porto-Novo','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(504,'arrondissement','1er','Porto-Novo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(505,'arrondissement','2eme','Porto-Novo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(506,'arrondissement','3eme','Porto-Novo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(507,'arrondissement','4eme','Porto-Novo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(508,'arrondissement','5eme','Porto-Novo','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(509,'commune','Seme-Podji','Oueme','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(510,'arrondissement','Agblangandan','Seme-Podji','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(511,'arrondissement','Aholouyeme','Seme-Podji','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(512,'arrondissement','Djeregbe','Seme-Podji','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(513,'arrondissement','Ekpe','Seme-Podji','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(514,'arrondissement','Tohoue','Seme-Podji','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(515,'arrondissement','Seme-Podji','Seme-Podji','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(516,'commune','Adja-Ouere','Plateau','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(517,'arrondissement','Ikpinle','Adja-Ouere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(518,'arrondissement','Kpoulou','Adja-Ouere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(519,'arrondissement','Masse','Adja-Ouere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(520,'arrondissement','Oko-Akare','Adja-Ouere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(521,'arrondissement','Tatonnonkon','Adja-Ouere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(522,'arrondissement','Adja-Ouere','Adja-Ouere','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(523,'commune','Ifangni','Plateau','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(524,'arrondissement','Banigbe','Ifangni','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(525,'arrondissement','Daagbe','Ifangni','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(526,'arrondissement','Ko-Koumolou','Ifangni','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(527,'arrondissement','Lagbe','Ifangni','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(528,'arrondissement','Tchaada','Ifangni','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(529,'arrondissement','Ifangni','Ifangni','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(530,'commune','Ketou','Plateau','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(531,'arrondissement','Adakplame','Ketou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(532,'arrondissement','Idigny','Ketou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(533,'arrondissement','Kpankou','Ketou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(534,'arrondissement','Odometa','Ketou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(535,'arrondissement','Okpometa','Ketou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(536,'arrondissement','Ketou','Ketou','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(537,'commune','Pobe','Plateau','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(538,'arrondissement','Ahoyeye','Pobe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(539,'arrondissement','Igana','Pobe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(540,'arrondissement','Issaba','Pobe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(541,'arrondissement','Towe','Pobe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(542,'arrondissement','Pobe','Pobe','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(543,'commune','Sakete','Plateau','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(544,'arrondissement','Aguidi','Sakete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(545,'arrondissement','Ita-Djebou','Sakete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(546,'arrondissement','Takon','Sakete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(547,'arrondissement','Yoko','Sakete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(548,'arrondissement','Sakete 1','Sakete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(549,'arrondissement','Sakete 2','Sakete','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(550,'commune','Abomey','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(551,'arrondissement','Agbokpa','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(552,'arrondissement','Detohou','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(553,'arrondissement','Sehoun','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(554,'arrondissement','Zounzonme','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(555,'arrondissement','Djegbe','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(556,'arrondissement','Hounli','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(557,'arrondissement','Vidole','Abomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(558,'commune','Agbangnizoun','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(559,'arrondissement','Adanhondjigo','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(560,'arrondissement','Adingnigon','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(561,'arrondissement','Kinta','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(562,'arrondissement','Kpota','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(563,'arrondissement','Lissazounme','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(564,'arrondissement','Sahe','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(565,'arrondissement','Sinwe','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(566,'arrondissement','Tanve','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(567,'arrondissement','Zoungoundo','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(568,'arrondissement','Agbangnizoun','Agbangnizoun','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(569,'commune','Bohicon','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(570,'arrondissement','Agongointo','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(571,'arrondissement','Avogbanna','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(572,'arrondissement','Gnidjazoun','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(573,'arrondissement','Lissezoun','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(574,'arrondissement','Ouassaho','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(575,'arrondissement','Passagon','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(576,'arrondissement','Saclo','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(577,'arrondissement','Sodohome','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(578,'arrondissement','Bohicon I','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(579,'arrondissement','Bohicon II','Bohicon','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(580,'commune','Cove','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(581,'arrondissement','Houeko','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(582,'arrondissement','Adogbe','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(583,'arrondissement','Gounli','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(584,'arrondissement','Houin-Hounso','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(585,'arrondissement','Lainta-Cogbe','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(586,'arrondissement','Naogon','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(587,'arrondissement','Soli','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(588,'arrondissement','Zogba','Cove','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(589,'commune','Djidja','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(590,'arrondissement','Agondji','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(591,'arrondissement','Agouna','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(592,'arrondissement','Dan','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(593,'arrondissement','Dohouime','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(594,'arrondissement','Gobaix','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(595,'arrondissement','Houto','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(596,'arrondissement','Monsourou','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(597,'arrondissement','Mougnon','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(598,'arrondissement','Oumbegame','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(599,'arrondissement','Setto','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(600,'arrondissement','Zounkon','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(601,'arrondissement','Djidja Centre','Djidja','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(602,'commune','Ouinhi','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(603,'arrondissement','Dasso','Ouinhi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(604,'arrondissement','Sagon','Ouinhi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(605,'arrondissement','Tohoues','Ouinhi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(606,'arrondissement','Ouinhi Centre','Ouinhi','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(607,'commune','Zagnanado','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(608,'arrondissement','Agonlin-Houegbo','Zagnanado','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(609,'arrondissement','Baname','Zagnanado','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(610,'arrondissement','Don-Tan','Zagnanado','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(611,'arrondissement','Dovi','Zagnanado','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(612,'arrondissement','Kpedekpo','Zagnanado','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(613,'arrondissement','Zagnanado Centre','Zagnanado','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(614,'commune','Za-Kpota','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(615,'arrondissement','Allahe','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(616,'arrondissement','Assanlin','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(617,'arrondissement','Houngome','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(618,'arrondissement','Kpakpame','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(619,'arrondissement','Kpozoun','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(620,'arrondissement','Za-Tanta','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(621,'arrondissement','Zeko','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(622,'arrondissement','Za-Kpota','Za-Kpota','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(623,'commune','Zogbodomey','Zou','departement','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(624,'arrondissement','Akiza','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(625,'arrondissement','Avlame','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(626,'arrondissement','Cana I','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(627,'arrondissement','Cana II','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(628,'arrondissement','Dome','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(629,'arrondissement','Koussoukpa','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(630,'arrondissement','Kpokissa','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(631,'arrondissement','Massi','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(632,'arrondissement','Tanwe-Hessou','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(633,'arrondissement','Zoukou','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(634,'arrondissement','Zogbodomey Centre','Zogbodomey','commune','2026-08-12 12:43:31','2026-08-12 12:43:31'),
(720,'quartier','Adjagbo','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(721,'quartier','Agassa-Godomey','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(722,'quartier','Agonme','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(723,'quartier','Agonsoundja','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(724,'quartier','Akassato Centre','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(725,'quartier','Gbetagbo','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(726,'quartier','Glo-Tokpa','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(727,'quartier','Houeke-Gbo','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(728,'quartier','Houeke-Honou','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(729,'quartier','Koletin','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(730,'quartier','Kpodji-Les-Monts','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(731,'quartier','Missessinto','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(732,'quartier','Zekanmey-Dome','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(733,'quartier','Zopah Palmeraie','Akassato','arrondissement','2026-08-12 12:43:32','2026-08-12 12:43:32'),
(734,'quartier','Abikouholi','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(735,'quartier','Agbo-Codji-Sedegbe','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(736,'quartier','Agonkanmey','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(737,'quartier','Aimevo','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(738,'quartier','Alegleta','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(739,'quartier','Amanhoun','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(740,'quartier','Assrossa','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(741,'quartier','Atrokpo-Codji','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(742,'quartier','Cococodji','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(743,'quartier','Cocotomey','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(744,'quartier','Dekoungbe-Eglise','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(745,'quartier','Dekoungbe-Usine','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(746,'quartier','Denou','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(747,'quartier','Djekpota','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(748,'quartier','DjouKpa-Togoudo','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(749,'quartier','Fandji','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(750,'quartier','Fignonhou','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(751,'quartier','Finafa','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(752,'quartier','Ganganzounme','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(753,'quartier','Gbegnigan-Midokpo','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(754,'quartier','Gbodje-Womey','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(755,'quartier','Gninkindji','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(756,'quartier','Godomey-NGbeho','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(757,'quartier','Godomey-Togoudo','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(758,'quartier','Hedome','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(759,'quartier','Helouto','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(760,'quartier','Houakomey','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(761,'quartier','Hounsa-Agbodokpa','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(762,'quartier','La Paix','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(763,'quartier','Lobozounkpa','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(764,'quartier','Maria-Gleta','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(765,'quartier','Ningboto','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(766,'quartier','Nonhouenou','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(767,'quartier','Ounvenoumede','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(768,'quartier','Plateau','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(769,'quartier','Salamey','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(770,'quartier','Sedjannanko','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(771,'quartier','Sedomey','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(772,'quartier','Seloli-Fandji','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(773,'quartier','Sodo','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(774,'quartier','Tankpe','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(775,'quartier','Togbin-Daho','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(776,'quartier','Togbin-Kpevi','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(777,'quartier','Tognin-Fandji','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(778,'quartier','Tokpa','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(779,'quartier','Womey Centre','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(780,'quartier','Yenandjro','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(781,'quartier','Yolomahouto','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(782,'quartier','Zounga','Godomey','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(783,'quartier','Adjame','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(784,'quartier','Agongbe','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(785,'quartier','Agonkessa','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(786,'quartier','Alladacome','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(787,'quartier','Azonsa','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(788,'quartier','Djissoukpa','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(789,'quartier','Domey-Gbo','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(790,'quartier','Golo-Djigbe','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(791,'quartier','Golo-Fanto','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(792,'quartier','Lohoussa','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(793,'quartier','Missebo-Espace Saint','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(794,'quartier','Yekon-Aga','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(795,'quartier','Yekon-Do','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(796,'quartier','Zekanmey','Golo-Djigbe','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(797,'quartier','Adovie','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(798,'quartier','Akossavie','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(799,'quartier','Dossounou','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(800,'quartier','Hevie Centre','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(801,'quartier','Houinme','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(802,'quartier','Hounyeva','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(803,'quartier','Hounzevie','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(804,'quartier','Sogan','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(805,'quartier','Zoungo','Hevie','arrondissement','2026-08-12 12:43:33','2026-08-12 12:43:33'),
(865,'quartier','Aidojebo','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(866,'quartier','Ahouansori Ague','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(867,'quartier','Ahouansori S Toweta','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(868,'quartier','Ahouansori Toweta II','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(869,'quartier','Ahouansori Yehoueme','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(870,'quartier','Dandji','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(871,'quartier','Gbedokpo','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(872,'quartier','Gbedokpo II','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(873,'quartier','Hinvi','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(874,'quartier','Jinongbo','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(875,'quartier','Koutong Beyi','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(876,'quartier','Ladji Gbodo','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(877,'quartier','Vossa','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(878,'quartier','Yagbe','6eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(879,'quartier','Dagbedji','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(880,'quartier','Enagnon','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(881,'quartier','Gbakpadji','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(882,'quartier','Gbedagba','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(883,'quartier','Houeyiho I','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(884,'quartier','Houeyiho II','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(885,'quartier','Kouhounou','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(886,'quartier','Missite','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(887,'quartier','Segbeyi','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(888,'quartier','Segbeyi-Vodoungbo','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(889,'quartier','Vossa','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(890,'quartier','Yenawa','7eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(891,'quartier','Agbontin','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(892,'quartier','Agla','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(893,'quartier','Agla Akplomey','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(894,'quartier','Agla Figaro','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(895,'quartier','Agla Les Chateaux','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(896,'quartier','Ahogbohouedo','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(897,'quartier','Aidjedo','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(898,'quartier','Fifadji','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(899,'quartier','Gbedagba','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(900,'quartier','Gbegamey','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(901,'quartier','Houego','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(902,'quartier','Houeyiho','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(903,'quartier','Mededjro','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(904,'quartier','Minontin','8eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(905,'quartier','Figaro','9eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(906,'quartier','Mifongou','9eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(907,'quartier','Togoudo','9eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(908,'quartier','Zongo Gbigba','9eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(909,'quartier','Gbedjewin','10eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(910,'quartier','Kouhounou','10eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(911,'quartier','Missigbo','10eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(912,'quartier','Missessin','10eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(913,'quartier','Yenawa','10eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(914,'quartier','Agbato','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(915,'quartier','Cadjehoun','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(916,'quartier','Cadjehoun Kpota','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(917,'quartier','Cocotie','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(918,'quartier','Gizo','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(919,'quartier','Haie Vive','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(920,'quartier','Les Cocotiers','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(921,'quartier','Vodje','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(922,'quartier','Vodje Kpota','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(923,'quartier','Vodje Rail','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(924,'quartier','Zone Residentielle','11eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(925,'quartier','Aibatin 1','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(926,'quartier','Aibatin 2','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(927,'quartier','Cadjehoun 2','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(928,'quartier','Fidjrosse 1','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(929,'quartier','Fidjrosse 2','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(930,'quartier','Fidjrosse Kpwota','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(931,'quartier','Fifi','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(932,'quartier','Houeyiho','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(933,'quartier','Kpota','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(934,'quartier','Yagbe','12eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(935,'quartier','Agla','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(936,'quartier','Aibatin','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(937,'quartier','Ahogbohouedo','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(938,'quartier','Gbedagba','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(939,'quartier','Houego','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(940,'quartier','Kpota','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(941,'quartier','Missessin','13eme','arrondissement','2026-08-12 19:27:20','2026-08-12 19:27:20'),
(942,'quartier','Agbokou','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(943,'quartier','Agbokou Ague','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(944,'quartier','Agbokou Odo','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(945,'quartier','Akonaboe','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(946,'quartier','Attake','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(947,'quartier','Attake Yenawa','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(948,'quartier','Avasa','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(949,'quartier','Dodji','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(950,'quartier','Gbedji','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(951,'quartier','Houezé','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(952,'quartier','Logou','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(953,'quartier','Sado','1er','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(954,'quartier','Agaji','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(955,'quartier','Attake Akabanou','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(956,'quartier','Donou','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(957,'quartier','Gbodje','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(958,'quartier','Gboparou','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(959,'quartier','Guinvié','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(960,'quartier','Kandevienne','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(961,'quartier','Opoku','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(962,'quartier','Zoukou','2eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(963,'quartier','Adjina','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(964,'quartier','Adjina Nord','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(965,'quartier','Adjina Sud','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(966,'quartier','Agbodjedo','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(967,'quartier','Ahouanleko','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(968,'quartier','Akonaboe','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(969,'quartier','Dowota','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(970,'quartier','Gbeko','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(971,'quartier','Hassiou','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(972,'quartier','Houinme','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(973,'quartier','Houinme Gbeyigbo','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(974,'quartier','Oussou','3eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(975,'quartier','Anavie','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(976,'quartier','Djegan Dagba','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(977,'quartier','Djegan Kpota','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(978,'quartier','Djegan Pevi','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(979,'quartier','Gbedji','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(980,'quartier','Garden','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(981,'quartier','Hounsa','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(982,'quartier','Kpokame','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(983,'quartier','Pota','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(984,'quartier','Zinvié','4eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(985,'quartier','Datcha','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(986,'quartier','Djoulde','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(987,'quartier','Gbeko','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(988,'quartier','Houegbo','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(989,'quartier','Koutong Be','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(990,'quartier','Ouando','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(991,'quartier','Ouando Leko','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(992,'quartier','Tokpo','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(993,'quartier','Zougbo','5eme','arrondissement','2026-08-12 19:27:21','2026-08-12 19:27:21'),
(994,'quartier','Kpanroun','Kpanroun','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(995,'quartier','Avagbo','Kpanroun','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(996,'quartier','Djitinkon','Kpanroun','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(997,'quartier','Kpola','Kpanroun','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(998,'quartier','Anagbo','Kpanroun','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(999,'quartier','Zinvié-kpota','Kpanroun','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(1000,'quartier','Ouèdo-Centre','Ouedo','arrondissement','2026-08-15 19:12:35','2026-08-15 19:12:35'),
(1001,'quartier','Adjagbo','Ouedo','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1002,'quartier','Kpocon','Ouedo','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1003,'quartier','Kpame','Ouedo','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1004,'quartier','Aïfa','Ouedo','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1005,'quartier','Dessato','Ouedo','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1006,'quartier','Togba-Houèdo','Togba','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1007,'quartier','Tankpè','Togba','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1008,'quartier','Ouèdo-Gbadji','Togba','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1009,'quartier','Maria-Gléta','Togba','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1010,'quartier','Agonglo','Togba','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1011,'quartier','Zinvié-Centre','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1012,'quartier','Adja-Gbo','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1013,'quartier','Dangbodji','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1014,'quartier','Wawata','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1015,'quartier','Gozoumkpa','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1016,'quartier','Sègbohouè','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1017,'quartier','Gbégnourou','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1018,'quartier','Kpotomi','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1019,'quartier','Zoungbodji','Zinvie','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1020,'quartier','Abomey-Calavi Centre','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1021,'quartier','Agori','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1022,'quartier','Aitchédji','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1023,'quartier','Cité BOAD','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1024,'quartier','Fandji','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1025,'quartier','Gbodjo','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1026,'quartier','Kpota','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1027,'quartier','Tokpa-Zoungo','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1028,'quartier','Zogbadjè','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1029,'quartier','Zoundja','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1030,'quartier','Sèmè','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36'),
(1031,'quartier','Gbégnigan','Abomey-Calavi','arrondissement','2026-08-15 19:12:36','2026-08-15 19:12:36');
/*!40000 ALTER TABLE `localisations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `magasins`
--

DROP TABLE IF EXISTS `magasins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `magasins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) DEFAULT NULL,
  `nom` varchar(150) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `responsable` varchar(100) DEFAULT NULL,
  `actif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magasins`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `magasins` WRITE;
/*!40000 ALTER TABLE `magasins` DISABLE KEYS */;
/*!40000 ALTER TABLE `magasins` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2026_08_05_172745_create_users_table',1),
(2,'2026_08_05_172746_create_debiteurs_table',1),
(3,'2026_08_05_172747_create_produits_table',1),
(4,'2026_08_05_172748_create_ventes_table',1),
(5,'2026_08_05_172749_create_recouvrements_table',1),
(6,'2026_08_05_172750_create_sync_logs_table',1),
(7,'2026_08_05_182038_create_cache_table',1),
(8,'2026_08_05_192156_add_transfer_columns_to_debiteurs_table',1),
(9,'2026_08_05_195936_add_transfer_columns_to_debiteurs_table',1),
(10,'2026_08_05_200016_create_audit_logs_table',1),
(11,'2026_08_05_210405_add_type_vente_epargne_to_ventes_table',1),
(12,'2026_08_05_210520_add_type_vente_epargne_to_ventes_table',1),
(13,'2026_08_08_210309_create_mouvements_stock_table',1),
(14,'2026_08_08_234847_add_fields_to_produits_table',1),
(15,'2026_08_08_235137_add_date_mouvement_to_mouvements_stock',1),
(16,'2026_08_09_010353_create_clients_comptant_table',1),
(17,'2026_08_09_020716_create_echeances_table',1),
(18,'2026_08_09_023935_create_alertes_table',1),
(19,'2026_08_09_030158_create_caisses_table',1),
(20,'2026_08_09_033517_create_journal_table',1),
(21,'2026_08_09_102839_create_notifications_table',1),
(22,'2026_08_11_004137_create_synthese_journaliere_table',1),
(23,'2026_08_11_114941_modify_role_column_in_users_table',2),
(24,'2026_08_11_115255_update_role_values_in_users_table',2),
(25,'2026_08_11_115451_update_role_values_in_users_table',2),
(26,'2026_08_11_XXXXXX_update_role_values_in_users_table',2),
(27,'2026_08_11_191524_add_epargne_penalite_to_ventes',3),
(28,'2026_08_11_191648_create_epargnes_table',4),
(29,'2026_08_11_191802_create_penalites_table',5),
(30,'2026_08_11_233253_add_penalite_config_to_ventes',6),
(31,'2026_08_12_122929_create_permissions_table',7),
(32,'2026_08_12_131354_enrichir_debiteurs_table',8),
(33,'2026_08_12_131428_create_scores_solvabilite_table',8),
(34,'2026_08_12_143834_create_localisations_benin_table',9),
(35,'2026_08_12_220220_create_categories_table',10),
(36,'2026_08_12_221342_add_stock_initial_to_produits',11),
(37,'2026_08_12_221345_create_approvisionnements_table',12),
(38,'2026_08_13_002723_add_action_to_mouvements_stock',13),
(39,'2026_08_14_045958_create_vente_produits_table',14),
(40,'2026_08_14_212438_fix_score_solvabilite_decimal',15),
(41,'2026_08_17_151240_add_delai_avant_echeances_to_ventes',16),
(42,'2026_08_17_194639_create_demandes_remboursement_table',17),
(43,'2026_08_18_002250_add_created_by_to_ventes',18),
(44,'2026_08_20_015306_create_tournee_demarrages_table',19),
(45,'2026_08_20_024042_add_statut_to_penalites_table',20),
(46,'2026_08_23_122223_add_unique_echeance_id_to_penalites',21),
(47,'2026_08_24_212113_sync_caisses_hierarchie_state',22),
(48,'2026_08_25_153936_add_validation_to_mouvements_caisse',23),
(49,'2026_08_25_162331_add_validation_to_mouvements_caisse',24),
(50,'2026_08_25_163118_enrichir_validation_remise',25);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `mouvements_caisse`
--

DROP TABLE IF EXISTS `mouvements_caisse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_caisse` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `caisse_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `recouvrement_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('encaissement','decaissement','depot','retrait','transfert','salaire','epargne','penalite','remise','versement') DEFAULT NULL,
  `statut_validation` enum('en_attente','valide','ecart','rejete') NOT NULL DEFAULT 'en_attente',
  `montant` decimal(12,2) NOT NULL,
  `montant_declare` decimal(12,2) DEFAULT NULL,
  `montant_recu` decimal(12,2) DEFAULT NULL,
  `ecart_remise` decimal(12,2) DEFAULT NULL,
  `mode_paiement` varchar(255) NOT NULL DEFAULT 'especes',
  `reference` varchar(255) DEFAULT NULL,
  `motif` text DEFAULT NULL,
  `motif_rejet` text DEFAULT NULL,
  `date_mouvement` datetime NOT NULL,
  `heure_mouvement` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `beneficiaire` varchar(255) DEFAULT NULL,
  `valide_par` bigint(20) unsigned DEFAULT NULL,
  `valide_le` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mouvements_caisse_uuid_unique` (`uuid`),
  KEY `mouvements_caisse_caisse_id_foreign` (`caisse_id`),
  KEY `mouvements_caisse_user_id_foreign` (`user_id`),
  KEY `mouvements_caisse_recouvrement_id_foreign` (`recouvrement_id`),
  KEY `mouvements_caisse_valide_par_foreign` (`valide_par`),
  KEY `idx_remise_validation` (`type`,`statut_validation`),
  CONSTRAINT `mouvements_caisse_caisse_id_foreign` FOREIGN KEY (`caisse_id`) REFERENCES `caisses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mouvements_caisse_recouvrement_id_foreign` FOREIGN KEY (`recouvrement_id`) REFERENCES `recouvrements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mouvements_caisse_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `mouvements_caisse_valide_par_foreign` FOREIGN KEY (`valide_par`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_caisse`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mouvements_caisse` WRITE;
/*!40000 ALTER TABLE `mouvements_caisse` DISABLE KEYS */;
INSERT INTO `mouvements_caisse` VALUES
(1,'3f0ee3b3-e8be-450b-be44-b37600c67051',5,1,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-17 23:14:29',NULL,'2026-08-17 21:14:29','2026-08-25 14:23:54',NULL,NULL,NULL),
(2,'424a8b50-c2f8-4b8d-b880-0104431da0df',5,1,1,'encaissement','valide',3700.00,NULL,NULL,NULL,'especes','REC-965813f4','Paiement Maxim',NULL,'2026-08-17 23:14:29',NULL,'2026-08-17 21:14:29','2026-08-25 14:23:54',NULL,NULL,NULL),
(3,'0adf6e56-5a5e-420f-afe2-d443c5193db2',7,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-18 22:30:51',NULL,'2026-08-18 20:30:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(4,'c16f60e2-ef56-4650-9b6f-81fab67f4585',7,3,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-e417a46d','Paiement AKOUTE',NULL,'2026-08-18 22:30:51',NULL,'2026-08-18 20:30:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(5,'69af7140-b3c1-43ed-8248-dca7b65f3a49',9,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-19 08:18:55',NULL,'2026-08-19 06:18:55','2026-08-25 14:23:54',NULL,NULL,NULL),
(6,'34bc664b-83d4-4bdc-bf7c-ab25cefb0a6d',9,3,3,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REC-b3db80b2','Paiement Maxim',NULL,'2026-08-19 08:18:55',NULL,'2026-08-19 06:18:55','2026-08-25 14:23:54',NULL,NULL,NULL),
(7,'5a69890a-dc6f-4142-b6e8-2f28f697adef',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 00:36:02',NULL,'2026-08-19 22:36:02','2026-08-25 14:23:54',NULL,NULL,NULL),
(9,'85ee00be-0fda-4eb7-838a-8aeb6fedace9',10,3,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-f9f87a67','Paiement AKOUTE',NULL,'2026-08-20 00:36:02',NULL,'2026-08-19 22:36:02','2026-08-25 14:23:54',NULL,NULL,NULL),
(10,'4c54f359-abf0-4549-a688-599e27ee8d68',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-20 00:37:22',NULL,'2026-08-19 22:37:22','2026-08-25 14:23:54',NULL,NULL,NULL),
(11,'84b313b2-e307-4d97-9ac3-2b6d96cdd840',10,3,5,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REC-64155dd6','Paiement Maxim',NULL,'2026-08-20 00:37:22',NULL,'2026-08-19 22:37:22','2026-08-25 14:23:54',NULL,NULL,NULL),
(13,'ac7b8b56-d7dd-43de-9362-e97371469e9b',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 12:49:51',NULL,'2026-08-20 10:49:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(14,'c2aca7c4-1336-494b-994f-a0a193593292',10,3,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-f8f5b333','Paiement AKOUTE',NULL,'2026-08-20 12:49:51',NULL,'2026-08-20 10:49:51','2026-08-25 14:23:54',NULL,NULL,NULL),
(15,'d2113814-8c83-4b5b-95a7-e7e64b6d6bd5',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 13:19:54',NULL,'2026-08-20 11:19:54','2026-08-25 14:23:54',NULL,NULL,NULL),
(16,'87a32cba-d2e0-4635-8534-666bbdd79dde',10,3,NULL,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-0a802adc','Paiement AKOUTE',NULL,'2026-08-20 13:19:54',NULL,'2026-08-20 11:19:54','2026-08-25 14:23:54',NULL,NULL,NULL),
(17,'2bf0a125-069c-4d22-b642-d9f385a8348b',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 14:14:30',NULL,'2026-08-20 12:14:30','2026-08-25 14:23:54',NULL,NULL,NULL),
(19,'064ae3cb-d1e3-4c30-a428-6ed4b1d4b61b',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 14:14:30',NULL,'2026-08-20 12:14:30','2026-08-25 14:23:54',NULL,NULL,NULL),
(20,'6793b20d-8c1f-4dd4-83ef-097c05f8914b',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-20 21:15:11',NULL,'2026-08-20 19:15:11','2026-08-25 14:23:54',NULL,NULL,NULL),
(21,'c1f20b3e-eef4-4bd8-b594-2f302ac4615e',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 22:14:58',NULL,'2026-08-20 20:14:58','2026-08-25 14:23:54',NULL,NULL,NULL),
(22,'9450472e-be6d-48a1-8a66-68091d04f95f',10,3,8,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-037aee07','Paiement AKOUTE',NULL,'2026-08-20 22:14:58',NULL,'2026-08-20 20:14:58','2026-08-25 14:23:54',NULL,NULL,NULL),
(25,'0ae84d15-ef80-4c99-a433-6d0a49d133f8',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 23:05:16',NULL,'2026-08-20 21:05:16','2026-08-25 14:23:54',NULL,NULL,NULL),
(26,'9b7e98a3-4434-4baa-beed-160bce2f72bc',10,3,9,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-23c42791','Paiement AKOUTE',NULL,'2026-08-20 23:05:16',NULL,'2026-08-20 21:05:16','2026-08-25 14:23:54',NULL,NULL,NULL),
(27,'9e54e2c2-6ef7-4aef-8f9a-aecf3e628bbf',10,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-20 23:21:34',NULL,'2026-08-20 21:21:34','2026-08-25 14:23:54',NULL,NULL,NULL),
(28,'03d0a84d-e3f1-4876-96a4-b35a777cf0f8',10,3,10,'encaissement','valide',6150.00,NULL,NULL,NULL,'especes','REC-93a769c1','Paiement AKOUTE',NULL,'2026-08-20 23:21:34',NULL,'2026-08-20 21:21:34','2026-08-25 14:23:54',NULL,NULL,NULL),
(29,'2fc826ef-cc38-4ab6-8ff0-244eb00ed773',11,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-bf517af3','Épargne AKOUTE',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(30,'45a93290-1fc3-4359-9389-0a4970f3bae0',11,3,11,'encaissement','valide',12300.00,NULL,NULL,NULL,'especes','REC-0aa1acd2','Paiement AKOUTE',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(31,'65e9a4c4-9d09-4d85-999c-3106788ffc9a',11,3,NULL,'epargne','valide',300.00,NULL,NULL,NULL,'especes','EPARGNE-7ea546c4','Épargne Maxim',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(32,'62625e78-d7d1-45f6-b7d6-a6bfc71c071a',11,3,12,'encaissement','valide',3750.00,NULL,NULL,NULL,'especes','REC-90f95ce0','Paiement Maxim',NULL,'2026-08-22 17:07:33',NULL,'2026-08-22 15:07:33','2026-08-25 14:23:54',NULL,NULL,NULL),
(33,'5e8b4e04-5f09-468b-8c6a-87f32da9a6c1',14,3,NULL,'remise','valide',5000.00,NULL,NULL,NULL,'especes','REMISE-NJG6HRCL','Remise à l agence',NULL,'2026-08-24 23:22:07',NULL,'2026-08-24 21:22:07','2026-08-25 14:23:54',NULL,NULL,NULL),
(34,'b5f66a3c-1102-4ef0-96a2-909a2c6a53da',15,3,NULL,'versement','valide',5000.00,NULL,NULL,NULL,'especes','REMISE-NJG6HRCL','Versement de Mensah',NULL,'2026-08-24 23:22:07',NULL,'2026-08-24 21:22:07','2026-08-25 14:23:54',NULL,NULL,NULL);
/*!40000 ALTER TABLE `mouvements_caisse` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `mouvements_stock`
--

DROP TABLE IF EXISTS `mouvements_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mouvements_stock` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `produit_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` enum('entree','sortie','inventaire','retour','perte') NOT NULL,
  `action` varchar(20) NOT NULL DEFAULT 'creation',
  `date_mouvement` timestamp NULL DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `prix_unitaire` decimal(12,2) NOT NULL DEFAULT 0.00,
  `fournisseur` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `motif` text DEFAULT NULL,
  `stock_avant` int(11) NOT NULL DEFAULT 0,
  `stock_apres` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mouvements_stock_uuid_unique` (`uuid`),
  KEY `mouvements_stock_produit_id_foreign` (`produit_id`),
  KEY `mouvements_stock_user_id_foreign` (`user_id`),
  CONSTRAINT `mouvements_stock_produit_id_foreign` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`),
  CONSTRAINT `mouvements_stock_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mouvements_stock`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mouvements_stock` WRITE;
/*!40000 ALTER TABLE `mouvements_stock` DISABLE KEYS */;
INSERT INTO `mouvements_stock` VALUES
(1,'6b4f8dac-6651-4813-8f94-3757ee12f4d4',1,1,'sortie','vente','2026-08-16 22:00:00',3,23000.00,NULL,NULL,'Vente credit #7ea546c4 (regularisation)',2,-1,'2026-08-17 20:59:49','2026-08-17 22:31:51'),
(2,'3b7df861-0c26-4d2b-a813-bd7096fcd365',1,1,'sortie','vente','2026-08-16 22:00:00',3,23000.00,NULL,NULL,'Vente credit #bf517af3 (regularisation)',2,-1,'2026-08-17 21:03:11','2026-08-17 22:31:51'),
(3,'08ab04cb-5331-4970-9f00-b532e2c1a8cc',2,1,'sortie','vente','2026-08-16 22:00:00',2,17000.00,NULL,NULL,'Vente credit #bf517af3 (regularisation)',10,8,'2026-08-17 21:03:11','2026-08-17 22:31:51'),
(4,'595634ba-2e71-4e82-b2d6-280d92afebcc',3,1,'sortie','vente','2026-08-16 22:00:00',2,7000.00,NULL,NULL,'Vente credit #bf517af3 (regularisation)',3,1,'2026-08-17 21:03:11','2026-08-17 22:31:51'),
(5,'90ae43a7-b10c-4477-9bdc-0e7529d35cc6',1,5,'entree','creation',NULL,1,1000.00,NULL,NULL,NULL,-6,-5,'2026-08-18 16:08:01','2026-08-18 16:08:01'),
(6,'275bcbe8-8bc5-4ab1-963d-8d8a18146ad7',1,5,'entree','creation',NULL,15,20000.00,'SONIMEX','001',NULL,-5,10,'2026-08-18 19:22:19','2026-08-18 19:22:19'),
(7,'1fc889b7-3dcb-4f06-822b-e67a72abbc1a',2,5,'entree','creation',NULL,10,13500.00,'SONIMEX','002',NULL,-2,8,'2026-08-18 19:24:19','2026-08-18 19:24:19'),
(8,'a1672854-4d67-41f5-8090-2d633182a0c9',3,5,'entree','creation',NULL,10,5000.00,'SONIMEX','002',NULL,-2,8,'2026-08-18 19:24:53','2026-08-18 19:24:53'),
(9,'f7823d3d-6af9-4363-875a-893672da322d',4,5,'entree','creation',NULL,10,10000.00,'SONIMEX','003',NULL,0,10,'2026-08-18 19:26:31','2026-08-18 19:26:31'),
(10,'b036079a-12f0-4fb8-87b3-bbf060fe8909',5,5,'entree','creation',NULL,10,4000.00,'SONIMEX','004',NULL,0,10,'2026-08-18 19:27:01','2026-08-18 19:27:01');
/*!40000 ALTER TABLE `mouvements_stock` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `lien` varchar(255) DEFAULT NULL,
  `lue` tinyint(1) NOT NULL DEFAULT 0,
  `envoyee_whatsapp` tinyint(1) NOT NULL DEFAULT 0,
  `date_envoi` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notifications_uuid_unique` (`uuid`),
  KEY `notifications_user_id_lue_index` (`user_id`,`lue`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,'d723e6ee-2112-4b46-b895-2f8a7e96bf3d',1,'stock','Stock faible','SUCRE KAKI 50KG : 2 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(2,'3fdae9b5-4a6b-4cbb-a7f8-449c07dbf5ac',1,'stock','Stock faible','TULIP JAUNE 50KG : 3 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(3,'51bad13c-149e-4dce-8f10-2f6545c41029',1,'stock','Stock faible','FARM HOUSSE 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(4,'fbe4a25a-b7e8-4df6-ae7b-34f20a8d9078',1,'stock','Stock faible','COOKZEN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(5,'9a0e0862-abc5-4def-90b5-9281dd7db29c',1,'stock','Stock faible','HARICOT ROUGE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(6,'7dda750c-c474-4c5b-8a10-3f6b9a1d145c',1,'stock','Stock faible','MAIS BLANC : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(7,'f2e6b57b-3888-4a88-aa5d-4da60706658f',1,'stock','Stock faible','FARINE GMB : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(8,'96e9a4f9-2f46-4ea1-9125-77356bf24637',1,'stock','Stock faible','COQUIL SACHET BONJOURNE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(9,'9545ffdd-8be7-4d9a-b1ba-2a567a16c78f',1,'stock','Stock faible','CUBE MAGGI POULET : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(10,'616e60c5-44d2-4644-9bd9-fdbd10a5fde1',1,'stock','Stock faible','SOJA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(11,'60e5169c-9164-4afd-ac5c-5c33e10fbce9',1,'stock','Stock faible','SARDINE ATLANTA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(12,'cd36a726-dc27-4f8a-9b74-ea82d20b725c',1,'stock','Stock faible','MAYONNAISE MEVIA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(13,'772d20e8-dee4-4370-b29e-1c6a34ffb3c3',1,'stock','Stock faible','LAIT PEAK : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(14,'348483e6-4a57-40a4-811d-32c101e9fe93',1,'stock','Stock faible','Cube VEDAN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(15,'6e483d9b-9ea6-4e8f-858a-5877afce77b2',1,'stock','Stock faible','SPAGHETTI DOGA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(16,'ba156750-3d9f-438d-8c71-80dc0aabd672',1,'stock','Stock faible','SPRITE PLASTIQUE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(17,'8e45b6c6-857c-4caa-9ac5-c9669d4c4823',1,'stock','Stock faible','LA CASERA PLASTIQUE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(18,'7f8e3722-febe-4d56-9b0d-58c231314065',1,'stock','Stock faible','LEVURE JADU : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(19,'bdf52726-b7f5-49ba-aa29-96d08b8a1193',1,'stock','Stock faible','SEL SAC BLANC : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(20,'2c419d7f-69f7-4f2e-8500-a624fdc57e42',1,'stock','Stock faible','GARI SOHUI : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(21,'3c0d1388-a495-4a22-a898-d3b8854a2e6e',1,'stock','Stock faible','COCA COLA PLASTIQUE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(22,'3e9ce269-d1d1-4d5d-9835-c36337a8bf20',1,'stock','Stock faible','BICARBONATE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(23,'39650cc7-7d95-46a5-9a74-1cf06efaccd5',1,'stock','Stock faible','BOISSON ENERGIE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(24,'a9b80c20-7e22-4fa4-b8ad-c48d557e732f',1,'stock','Stock faible','HARICOT TAWA MOYEN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(25,'afbf28a7-dbbe-479b-8a60-cf033f081b1c',1,'stock','Stock faible','TOMATE SHALOM : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(26,'eac933f7-afd7-4fbc-a4da-c5ba2d59de8f',1,'stock','Stock faible','TOMATE SURE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(27,'95e738b8-bc4b-4aed-bfd5-f7c46280fed4',1,'stock','Stock faible','BIG JOE 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(28,'761a3096-9cc9-40e0-8117-d304b4061912',1,'stock','Stock faible','RIZ CLARK 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(29,'c11e0590-4082-423e-b1a6-e5ffc2fbba19',1,'stock','Stock faible','BLIGOE PETIT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(30,'6a9721b5-c72b-4bcf-b3ee-4f01140116d3',1,'stock','Stock faible','VOANZOU PETIT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(31,'167216aa-5578-4f34-99d9-19a9aa7fdf16',1,'stock','Stock faible','TOMATE AMAZONE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(32,'cedce063-a1ec-40a0-a834-4e19e7bb8f3a',1,'stock','Stock faible','MIL KAKI : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(33,'5bb783c2-5fcf-4cb5-8678-de96139935d4',1,'stock','Stock faible','FANTA CANETTE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(34,'962b1928-5bc3-46ef-9773-3966d19c47d0',1,'stock','Stock faible','COCA CANETTE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(35,'22b4fe7d-7056-4e96-84f4-10224cdc60d0',1,'stock','Stock faible','SPRITE CANETTE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(36,'cc42428a-df1f-41d7-a18d-cbb313530341',1,'stock','Stock faible','MALTA GUINESS : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(37,'479b0c9c-26ac-4d99-ae49-5dca58dd89f8',1,'stock','Stock faible','DESPERADO GRAND : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(38,'042c7d44-67b3-4c34-a0ee-76f52dfffb4a',1,'stock','Stock faible','RIZ 3 GOOD CASSE PARFUME 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(39,'8be6ddf0-498f-4501-baa6-682eef30f696',1,'stock','Stock faible','RIZ 3 GOOD CASSE PARFUME 5 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(40,'49957422-0d35-4aef-b4cf-4df6dd1ac842',1,'stock','Stock faible','RIZ 3 GOOD PARFUME LONG GRAIN 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(41,'3c181998-7f18-4681-b557-3a3363b1dd8d',1,'stock','Stock faible','COQUILLETTE ROCH : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(42,'ad182f33-9b06-4c10-a4a5-1347914f94eb',1,'stock','Stock faible','SARDINE BONJOURNE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(43,'355cbd01-ce66-41b5-9696-a36d8a137688',1,'stock','Stock faible','TOMATE GINNY : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(44,'5db540ca-c634-4e92-a008-a8090d3598bf',1,'stock','Stock faible','HARACA ROUGE CASSE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(45,'6e5c1eb4-4728-4a6a-8ca3-6b16e705b107',1,'stock','Stock faible','SPAGHETTI GOEYMEN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(46,'ebbcea21-2342-4667-bf8e-187d729470f1',1,'stock','Stock faible','AWONLI HARICOT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(47,'f5300952-beb8-422c-b409-b8066c73244c',1,'stock','Stock faible','VODY 18% : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(48,'66f2971f-bde6-44bb-a626-5892637f17ef',1,'stock','Stock faible','RIZ 3 GOOD LONG GRAIN 5KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(49,'e18361f7-2c5c-4a63-a6fa-19a51046226b',1,'stock','Stock faible','SACHET NOIR DE 5F : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(50,'f048bde8-31ff-4400-b38f-2fef24413220',1,'stock','Stock faible','SACHET BLANC DE 5F : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(51,'7716cc26-620a-4a95-b76c-0e04defe49ce',1,'stock','Stock faible','COUSCOUS BONJOURNE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(52,'6fcc9ab9-af49-4467-ac38-de3b014091a6',1,'stock','Stock faible','FARIME MOA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(53,'65a04284-c240-455e-80d4-2f90394c617d',1,'stock','Stock faible','KATY 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(54,'c57a303d-e59c-431c-807c-7cba20c3c885',1,'stock','Stock faible','YOUKI 1,5 LITRE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(55,'69855827-d06b-498b-bf0d-a95847b904f9',1,'stock','Stock faible','TOMATE MAGNIFICAT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(56,'e3610bb6-e5fb-4357-a814-94fcdf450093',1,'stock','Stock faible','SARDINES BEAUX RIVAGES : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(57,'11df9049-7184-4224-a74a-b5633c48c275',1,'stock','Stock faible','SPAGHETTI DANU : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(58,'64842cea-a834-46f4-bfe0-fbb243957ecf',1,'stock','Stock faible','RIZ MARINA CASSE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(59,'0370e9c2-1025-4140-ae7f-6d0d57704031',1,'stock','Stock faible','REAKTOR : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(60,'35f58632-2364-48aa-acb7-99d58077387f',1,'stock','Stock faible','BEAUFORT BOISSON : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(61,'d5f1496d-f8f2-403a-902d-da328eaabef8',1,'stock','Stock faible','BOISSON ROX : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(62,'dfbe52c8-09cc-4b8d-9f9c-f66ea62aa7bb',1,'stock','Stock faible','MAYONNAISE GINNY : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(63,'7a9a87ef-b558-4cf1-838f-40d5a586e846',1,'stock','Stock faible','LAIT CEBON : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(64,'5ead44ad-6598-4d4b-af02-c5f5b5f167a7',1,'stock','Stock faible','MY CHOICE BLANC 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(65,'ba67649e-098e-4a90-ae61-8ee56077da8d',1,'stock','Stock faible','COQUILLETTE DANU : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(66,'f5738334-e1f7-4ce3-947e-54efa50f4af3',1,'stock','Stock faible','CHARBON SAC DE 100 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(67,'1b7b81ac-fcf4-40a6-aaaf-39ead6eb8906',1,'stock','Stock faible','TOMATE BENNY 2200G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(68,'f4f788c3-31a2-4881-b4da-43af7162282e',1,'stock','Stock faible','COQUILLETTE OBA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(69,'5b8db2c7-9655-4ee6-b3e1-b49bead81114',1,'stock','Stock faible','MONSTER GRAND : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(70,'fe33eb27-e7a5-483c-82d5-d92af4e46df0',1,'stock','Stock faible','SANGRIA FORTE 18% CARTON DE 48 : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(71,'4e4167b8-d569-491a-a296-7f0cef71fb7a',1,'stock','Stock faible','SANGRIA FORTE 18% DETAIL : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(72,'7276b42e-e430-4a02-8ee6-7042067c08ff',1,'stock','Stock faible','CHATEAUX DE FRANCE 11% DETAIL : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(73,'8fdf3586-ba4a-4626-878d-f65d08466880',1,'stock','Stock faible','BULL IBO : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(74,'29f303d4-65cc-4184-9095-9602c967cfa0',1,'stock','Stock faible','OMO VIVA CARTON DE 26 : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(75,'ac51f46d-ed15-4c95-94ac-6203126d1fa7',1,'stock','Stock faible','RIZ FESTIN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(76,'78b5fc90-3562-4bc8-bdb6-279fb111cc12',1,'stock','Stock faible','CLARK 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(77,'321b4f49-a334-49dd-9bf2-feebe86796ac',1,'stock','Stock faible','VODY 22% : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(78,'124d2e71-00ff-400e-a4fe-aa7280113c39',1,'stock','Stock faible','LAIT SUPER 8 : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(79,'47175a6d-30c2-4b5b-af11-d1fa38257d65',1,'stock','Stock faible','NONO 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(80,'1df88629-7e67-48dd-b8dc-dd43a9c48fd8',1,'stock','Stock faible','COUSCOUS LIDO : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(81,'360d9d5a-0230-4f30-a8a3-12160112067a',1,'stock','Stock faible','YOUKI 0,5 LITRE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(82,'f30578bb-b132-4d38-8821-c9c0786cb212',1,'stock','Stock faible','BETA PETIT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(83,'25435c56-e482-4b1a-b013-66eddbd7a375',1,'stock','Stock faible','LITTLE THAI : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(84,'ddfeb8aa-0a77-46f2-859c-fe534a0820f5',1,'stock','Stock faible','PJS 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(85,'4026cfc4-155f-467c-9f69-2b04bcfafb34',1,'stock','Stock faible','DIVA ROYAL 25 KG SAC JAUNE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(86,'bf18a2a5-f6ec-4e01-98b9-38ea121fd165',1,'stock','Stock faible','DIVA KAKI 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(87,'50c6f8e8-0bb1-4db3-ab2d-1de15d319999',1,'stock','Stock faible','ROOP 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(88,'5d36ccf7-d7d7-4289-8440-d5b512b97ba2',1,'stock','Stock faible','RIZ GINO 5KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(89,'adbf43b0-ac39-4a74-9f31-0caf0866c58e',1,'stock','Stock faible','LAIT EN POUDRE GINNY : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(90,'f50c2615-ee70-48c8-928c-dc5ebc8ff22e',1,'stock','Stock faible','COQUILLETTE DIARI CARTON : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(91,'96d7a40f-bfe6-4671-b83b-e3856f7ddd21',1,'stock','Stock faible','KANGAROU CASSE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(92,'ea3d03d4-28c5-41fa-bc94-a45181582a43',1,'stock','Stock faible','DIVA SAC VIOLET 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(93,'bb727f8f-5ade-4177-82ea-09ab41b1ba50',1,'stock','Stock faible','LUXE IBO 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(94,'df87e835-97d0-498e-95db-7f5a5bec9092',1,'stock','Stock faible','MAMAN PRETTY IBO 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(95,'d7012174-c0ac-4766-a91b-443f5d5cc742',1,'stock','Stock faible','TOMATE BENNY 400G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(96,'39620fc1-5911-4611-a546-7f10cb820b5f',1,'stock','Stock faible','COUSCOUS GINNY : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(97,'9a3db1cc-f8e6-42fc-b41b-a2120831f4e6',1,'stock','Stock faible','OPPI UNIQUE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(98,'a978dec4-ebcf-48ba-92aa-3ede16472a71',1,'stock','Stock faible','RAHI IBO 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(99,'1f755cfe-21ab-48db-91fd-8414ea2dfee3',1,'stock','Stock faible','CUBE ROYAL : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(100,'33a071d5-11a3-4946-b479-e13d1fd1332b',1,'stock','Stock faible','BAOBAB POUDRE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(101,'87ac16ad-0c66-449d-b003-d0568a4eae8f',1,'stock','Stock faible','SPAGHETTI DIARRI 500G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(102,'78784f60-e5e0-45b8-a03d-6d7ccccb61ff',1,'stock','Stock faible','SARDINE ALPHA CHEF : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(103,'4ebd38b1-7ca5-4ce1-bd53-da67f08b870c',1,'stock','Stock faible','FANTA PLASTIQUE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(104,'bcd94d20-020c-4308-b1d9-4cd58c0ae935',1,'stock','Stock faible','BUDWEISER CANETTE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(105,'0a635221-a8b0-4676-96c6-7371b2c7f8dc',1,'stock','Stock faible','TOMATE YOVO 70 G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(106,'59430ef4-0a7f-40d2-9dfb-4d8463b5728e',1,'stock','Stock faible','HEINEKEN PETIT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(107,'4c25775a-8e6a-471c-9bdc-43c23f34131a',1,'stock','Stock faible','BETA GRAND : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(108,'fd0d70cb-a92a-40e7-9a64-40f049c581fa',1,'stock','Stock faible','SARDINE 222 : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(109,'0464683c-bfd5-4fdc-8368-ac670feba522',1,'stock','Stock faible','PRAGATI GOLD 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(110,'0413a529-076c-4a6c-a311-3dc232370aee',1,'stock','Stock faible','KATY 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(111,'e79fad36-5bb8-4c93-a487-d1aff4c05f12',1,'stock','Stock faible','JOKER 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(112,'35ddcfc9-2af2-47c1-b8d2-de56d12399f1',1,'stock','Stock faible','GIL GIL CASSE 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(113,'411cbf70-f54b-4ae6-a669-147310779c1b',1,'stock','Stock faible','DJOLOF 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(114,'277318ab-a5be-482c-b273-0f3b17971e09',1,'stock','Stock faible','VEDAN PETIT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(115,'aeeb73f6-2393-439b-8904-180b008e3c7d',1,'stock','Stock faible','BEAU GARCON BASMATI 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(116,'e3bdefd1-74da-4b1f-a5a6-c1ff2be017f9',1,'stock','Stock faible','BEAU GARCON THAILANDAIS 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(117,'0c78924c-c2a1-4edf-9f88-4ac586a1d78b',1,'stock','Stock faible','JIYO 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(118,'feb7dd9e-61c7-4d23-84b5-c2825b707a14',1,'stock','Stock faible','RIZ AAA 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(119,'7ef48357-8aa6-4acf-8a65-bd9c4476b663',1,'stock','Stock faible','FOOTBALL 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(120,'2211bc33-2492-4e8d-b14d-e6bfa501ee59',1,'stock','Stock faible','MEVIA EN PLASTIQUE 5 LITRES : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(121,'90a7b418-6899-4837-b731-0dae2b66aeeb',1,'stock','Stock faible','SPAGHETTI 3 GOOD : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(122,'89356c60-ee22-42f8-9c6c-0f07840fddbe',1,'stock','Stock faible','COQUILLETTE 3 GOOD : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(123,'e0bc5c47-bf14-4092-9b55-33432ef24120',1,'stock','Stock faible','LAIT CONCENTRE 3 GOOD : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(124,'27da90f5-79b5-41c2-ad5e-66178e08f585',1,'stock','Stock faible','TOMATE OD 3 GOOD : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(125,'25bc1f87-4ee9-4fd5-bd92-ec2e05bc5930',1,'stock','Stock faible','OMO VIVA 800G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(126,'e68678db-c8ee-4edb-9ae0-d4676be1d3a8',1,'stock','Stock faible','SAVON KANKPE CARTON DE 30 : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(127,'badf0974-7c76-454a-ba1d-3deb00d17c8a',1,'stock','Stock faible','SAVON KANKPE DETAIL : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(128,'2a22f8fc-db75-44e4-abc7-d623fdd22126',1,'stock','Stock faible','STAR BIERE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(129,'531f1577-549c-4a6d-8dff-4c024b1e603c',1,'stock','Stock faible','RC CANETTE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(130,'14e9238f-511e-4370-b0ea-7f80d00b4ae2',1,'stock','Stock faible','RIZ IBO 8888 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(131,'f561f6b2-1136-41c8-a1b4-42ce8762dd88',1,'stock','Stock faible','IBO DOUBLE ELEPHANT 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(132,'946f6bfd-3c8c-4f9c-bc5a-ed4d60121cda',1,'stock','Stock faible','SARDINES JADU : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(133,'388a1323-b7ba-4e07-b1b3-d6a0a5c8897e',1,'stock','Stock faible','COUSCOUS KOULHALA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(134,'6516667f-9f02-4c29-b1ad-afd1c8c5095f',1,'stock','Stock faible','PAON 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(135,'cf5927fa-b2aa-42a4-a455-5d59c4c9e515',1,'stock','Stock faible','SARDINES LOKKI : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(136,'b2cc9ad6-8799-450d-bcdd-f110b1f398fd',1,'stock','Stock faible','SARDINES CLEMA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(137,'d6f50150-3afd-4a02-baa1-fd1f6e19006a',1,'stock','Stock faible','ONIMA 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(138,'0a7e8e58-f734-4c65-9c83-974c842565be',1,'stock','Stock faible','KT GOLD 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(139,'2e34641f-c150-4d0f-8daa-63e3a74b650f',1,'stock','Stock faible','SPAGHETTI BELINA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(140,'e898c43d-ea13-4cd5-b234-c92283f47cf2',1,'stock','Stock faible','COUSCOUS FENA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(141,'3c0e50d4-56a4-4349-982c-fa5985bec24f',1,'stock','Stock faible','TOMATE YOVO 2200G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(142,'f744cc03-ce02-4563-a6c1-8cf3412441fc',1,'stock','Stock faible','PIVERT SAC VERT 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(143,'1c60f494-781b-4169-b146-68a8a211a71a',1,'stock','Stock faible','PIVERT SAC VIOLET 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(144,'43dc3067-a204-4d97-b5e7-4a57c2df37ce',1,'stock','Stock faible','STAR ORIGINAL BASMATI 25KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(145,'671f06c5-c687-48e2-ba43-740e93421a48',1,'stock','Stock faible','FARM HOUSSE VERT 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(146,'29b904f2-3a3b-43c9-b465-6a8343e1094a',1,'stock','Stock faible','IBO JOLLOF GOLD 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(147,'f1c1a6a5-75d1-4120-bee4-aba10b02e36c',1,'stock','Stock faible','LEOPARD 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(148,'04a0bd72-7918-4f4a-b61c-ab6bb3b8d287',1,'stock','Stock faible','MADHU CASSE 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(149,'791f3606-230c-49de-a4e1-9170da76dbf9',1,'stock','Stock faible','LAIT EN POUDRE FAMILIA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(150,'7cc3bb0b-80b8-4aac-8dd2-f20b43fa31f4',1,'stock','Stock faible','SPAGHETTI MAGNIFICAT : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(151,'0fffd652-7ff6-446f-a13c-6f87a8c49359',1,'stock','Stock faible','COQUILLETTE BELLA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(152,'c95da453-44b9-4fe9-8821-261c78250874',1,'stock','Stock faible','LAIT CONCENTRE MAGUIDA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(153,'ca431781-8540-48e6-8067-efbefa790361',1,'stock','Stock faible','LAIT CONCENTRE TOP SAHO : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(154,'3d89ff57-ac94-421d-a5dc-f3a718476f51',1,'stock','Stock faible','LAIT CONCENTRE MY MILK : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(155,'d66c211d-925a-4bef-be65-331b3c746680',1,'stock','Stock faible','LAIT CONCENTRE UNITY : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(156,'20261587-e5e0-4c9a-a25b-1304ecd2e247',1,'stock','Stock faible','TOMATE PSP 2200G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(157,'07adfc1d-9f40-40f8-967b-4313b236bb76',1,'stock','Stock faible','ONIMA 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(158,'e53a7755-a753-4940-9f64-0273206a0ac0',1,'stock','Stock faible','CAFE BONJOURNE CARTON : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(159,'99604489-fee2-4b6f-812f-037786b70f79',1,'stock','Stock faible','MILO FRESH CARTON : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(160,'d3814688-fdc1-499c-abc1-bb2791b0c596',1,'stock','Stock faible','BISSAP : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(161,'6a14982b-8f77-42d9-b689-97fefc200d07',1,'stock','Stock faible','MYLY GOLD IBO 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(162,'e7ffebfd-a3d5-44bd-8786-1ccd08956d5f',1,'stock','Stock faible','OPPI SUPER 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(163,'3232bbc7-6abb-4907-bba7-cdedf0d68f1c',1,'stock','Stock faible','OPPI POINTININI 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(164,'3a0821de-06ac-4f45-b19d-77f794dbf636',1,'stock','Stock faible','JOLIE 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(165,'61b518ca-a37b-4768-ac46-05debef80ff5',1,'stock','Stock faible','SARDINE DANU : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(166,'5dda2edd-34b4-405e-853e-343cbd1430b3',1,'stock','Stock faible','SAFARI RIZ BLANC 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(167,'920e9aec-980e-4de0-9551-097d4ebddcd9',1,'stock','Stock faible','MAIS JAUNE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(168,'b2b3da09-3669-4b1b-acf7-05dd48e24e03',1,'stock','Stock faible','SPAGHETTI BELLA : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(169,'c6774a35-2f32-4434-b221-c3f9fdddd344',1,'stock','Stock faible','JOLIE SAC ORANGE 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(170,'e1b6cf38-aa33-4102-9fd1-69204926a496',1,'stock','Stock faible','OMO WAVE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(171,'aeb4abe4-9a0e-4a45-9fd7-0d5d421a6906',1,'stock','Stock faible','INDOMIE GRAND : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(172,'8871e2fa-2740-4a4a-8a7b-97980223623f',1,'stock','Stock faible','SAGONO SPECIAL 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(173,'18b9bfe7-e773-47ca-956a-6be3cef67198',1,'stock','Stock faible','LAIT TOUS LES JOURS : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(174,'554f29ef-9095-490c-9618-793c2233814c',1,'stock','Stock faible','PALMIDA BENIN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(175,'886f3f76-2ad4-402d-9a91-6da7b8e8c60c',1,'stock','Stock faible','MAYONNAISE BONJOURNE GRAND : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(176,'999d3a0b-4cf8-4077-9ad8-514edf5e07ca',1,'stock','Stock faible','SPAGHETTI BONJOURNE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(177,'149037fb-4607-4c4e-b9af-c16d178f5796',1,'stock','Stock faible','TIK TOK CASSE 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(178,'f55a7db0-ac86-4030-b00c-b5edd7bf61ae',1,'stock','Stock faible','LATIF 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(179,'482b4b12-51e1-4bef-aa71-33f60e070cb1',1,'stock','Stock faible','LEGENDE BIERE : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(180,'b678fb91-a170-4bbf-8bb1-1fac23719c2d',1,'stock','Stock faible','STAR CITRON : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(181,'1125f7e2-e8e3-4e53-853f-e28ee9580558',1,'stock','Stock faible','HARAKA VERT 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(182,'17b21652-6c38-4034-83f3-324c1471040f',1,'stock','Stock faible','RIZ BLANC ROSETTE 50 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(183,'8a3dc3f5-8666-410b-af89-f99557bd15a5',1,'stock','Stock faible','AWONLI PETIT GRAIN : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(184,'2f159f26-756c-4aae-ab87-023808389182',1,'stock','Stock faible','TOMATE JADU 2200G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(185,'4e7d45c8-f36c-4a05-a1e1-11701b67e087',1,'stock','Stock faible','GIL GIL LONG GRAIN 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(186,'09b083bc-7180-45d6-b90d-c20ca376178d',1,'stock','Stock faible','TOMATE AMINATA 2200G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(187,'51f2c76d-0a94-4e75-85c3-b6894b866194',1,'stock','Stock faible','TOMATE SALMA 2200G : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(188,'95e2cff4-6c0f-45ac-ab9e-a6277a9ab371',1,'stock','Stock faible','TULIP 25 KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(189,'8d30584e-da55-44b1-b056-7d3c6d0999f1',1,'stock','Stock faible','JOLI CLASSIC 50KG : 0 unité(s) (seuil : 5)','#stocks',0,0,NULL,'2026-08-17 20:59:50','2026-08-17 20:59:50'),
(198,'76114a5b-54f5-425a-ba38-cb3f57cae9a3',3,'retard','Retard de paiement','Maxim a 1 jour(s) de retard. Restant : 3 750 FCFA.','#agent-space',0,0,NULL,'2026-08-23 20:40:39','2026-08-23 20:40:39'),
(199,'b8d1f1e6-4b40-47d6-bd13-2b04631dfb20',3,'echeance','Échéance du jour','Maxim doit payer 3 750 FCFA aujourd\'hui.','#agent-space',0,0,NULL,'2026-08-24 19:56:49','2026-08-24 19:56:49'),
(200,'6d764d4c-5084-4627-9a11-c81fe46ace71',3,'echeance','Échéance du jour','AKOUTE doit payer 6 150 FCFA aujourd\'hui.','#agent-space',0,0,NULL,'2026-08-24 19:56:49','2026-08-24 19:56:49'),
(201,'515b0539-66cd-4a7b-aa88-1240bb009663',3,'retard','Retard de paiement','Maxim a 1 jour(s) de retard. Restant : 7 500 FCFA.','#agent-space',0,0,NULL,'2026-08-24 19:56:49','2026-08-24 19:56:49'),
(202,'b374ee35-7084-4b60-a7cd-7a551c1d57c4',3,'retard','Retard de paiement','AKOUTE a 0 jour(s) de retard. Restant : 6 150 FCFA.','#agent-space',0,0,NULL,'2026-08-24 19:56:49','2026-08-24 19:56:49'),
(207,'4d49a6c1-c39d-470d-b624-11fc7b82052e',3,'retard','Retard de paiement','Maxim a 3 jour(s) de retard. Restant : 11 250 FCFA.','#agent-space',0,0,NULL,'2026-08-25 16:13:37','2026-08-25 16:13:37'),
(208,'212e95d7-001e-46d3-960f-00e5f830bec8',3,'retard','Retard de paiement','AKOUTE a 2 jour(s) de retard. Restant : 12 300 FCFA.','#agent-space',0,0,NULL,'2026-08-25 16:13:37','2026-08-25 16:13:37'),
(209,'dca3eb0c-b771-4c1d-9a05-d8bad0b10aba',3,'echeance','Échéance du jour','Maxim doit payer 3 750 FCFA aujourd\'hui.','#agent-space',0,0,NULL,'2026-08-26 01:05:55','2026-08-26 01:05:55'),
(210,'84d1b88d-2a35-4028-8ac2-59fc4a0391cd',3,'echeance','Échéance du jour','AKOUTE doit payer 6 150 FCFA aujourd\'hui.','#agent-space',0,0,NULL,'2026-08-26 01:05:55','2026-08-26 01:05:55'),
(211,'fcb1f57f-c3c0-4cc1-9536-91a8791076aa',3,'retard','Retard de paiement','Maxim a 3 jour(s) de retard. Restant : 15 000 FCFA.','#agent-space',0,0,NULL,'2026-08-26 01:05:55','2026-08-26 01:05:55'),
(212,'cbbc7ea1-d1c8-459c-bafe-40d144059c3f',3,'retard','Retard de paiement','AKOUTE a 2 jour(s) de retard. Restant : 18 450 FCFA.','#agent-space',0,0,NULL,'2026-08-26 01:05:55','2026-08-26 01:05:55');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `penalites`
--

DROP TABLE IF EXISTS `penalites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `penalites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `echeance_id` bigint(20) unsigned DEFAULT NULL,
  `recouvrement_id` bigint(20) unsigned DEFAULT NULL,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `statut` varchar(255) NOT NULL DEFAULT 'en_attente',
  `date_paiement` datetime DEFAULT NULL,
  `mode_paiement` varchar(255) DEFAULT NULL,
  `refus_defalque_epargne` tinyint(1) NOT NULL DEFAULT 0,
  `jours_retard` int(11) NOT NULL DEFAULT 0,
  `date_appliquee` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `penalites_uuid_unique` (`uuid`),
  UNIQUE KEY `penalites_echeance_id_unique` (`echeance_id`),
  KEY `penalites_vente_id_foreign` (`vente_id`),
  KEY `penalites_recouvrement_id_foreign` (`recouvrement_id`),
  KEY `penalites_debiteur_id_foreign` (`debiteur_id`),
  CONSTRAINT `penalites_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `penalites_echeance_id_foreign` FOREIGN KEY (`echeance_id`) REFERENCES `echeances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `penalites_recouvrement_id_foreign` FOREIGN KEY (`recouvrement_id`) REFERENCES `recouvrements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `penalites_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penalites`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `penalites` WRITE;
/*!40000 ALTER TABLE `penalites` DISABLE KEYS */;
INSERT INTO `penalites` VALUES
(1,'82e64c13-f349-404e-8eb3-b060515e8aea',1,5,NULL,5,4000.00,'en_attente',NULL,NULL,0,4,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(2,'f677c27d-11ab-4d3e-a8b4-fc199bbcdbac',1,6,NULL,5,3000.00,'en_attente',NULL,NULL,0,3,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(3,'19bab52b-54ea-412c-a0ff-14895d212341',2,26,NULL,6,3000.00,'en_attente',NULL,NULL,0,3,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(4,'4d04b4ca-9603-41ff-bf64-97f0d93721c0',1,7,NULL,5,2000.00,'en_attente',NULL,NULL,0,2,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(5,'9dc71317-2404-40bf-a750-fcee78d4e4ee',2,27,NULL,6,2000.00,'en_attente',NULL,NULL,0,2,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(6,'74dabbc8-8c70-4046-942c-cab953aa98b1',2,21,NULL,6,2000.00,'en_attente',NULL,NULL,0,2,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(7,'92acf498-c307-44b7-93e4-902dbf1e00b6',2,22,NULL,6,1000.00,'en_attente',NULL,NULL,0,1,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(8,'d204a789-deed-42f1-9718-5b806ce64478',1,4,NULL,5,1000.00,'en_attente',NULL,NULL,0,1,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(9,'782e345b-8511-4d02-9b4b-42cd06cdca65',2,24,NULL,6,1000.00,'en_attente',NULL,NULL,0,1,'2026-08-26','2026-08-25 16:24:33','2026-08-26 13:42:08'),
(10,'fe57ded9-5bbc-4e2c-aa6c-96db03a4b868',1,8,NULL,5,1000.00,'en_attente',NULL,NULL,0,1,'2026-08-26','2026-08-26 01:05:55','2026-08-26 13:42:08'),
(11,'e3b831a7-1f82-43da-98f6-a399a3b238ba',2,28,NULL,6,1000.00,'en_attente',NULL,NULL,0,1,'2026-08-26','2026-08-26 01:05:55','2026-08-26 13:42:08');
/*!40000 ALTER TABLE `penalites` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `page` varchar(255) NOT NULL,
  `acces` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_user_id_page_unique` (`user_id`,`page`),
  CONSTRAINT `permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,1,'produits',1,'2026-08-12 10:42:59','2026-08-12 10:42:59'),
(2,2,'notifications',1,'2026-08-12 10:58:57','2026-08-12 10:58:57');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `produits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `categorie_id` bigint(20) unsigned DEFAULT NULL,
  `nom` varchar(255) NOT NULL,
  `categorie` varchar(255) DEFAULT NULL,
  `prix_achat` decimal(12,2) NOT NULL DEFAULT 0.00,
  `prix_vente` decimal(12,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_initial` decimal(10,2) NOT NULL DEFAULT 0.00,
  `seuil_alerte` int(11) NOT NULL DEFAULT 5,
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `conditionnement` varchar(255) DEFAULT NULL,
  `unite` varchar(255) DEFAULT 'pièce',
  `code` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `marge` decimal(5,2) GENERATED ALWAYS AS (`prix_vente` - `prix_achat`) VIRTUAL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `produits_uuid_unique` (`uuid`),
  UNIQUE KEY `produits_code_unique` (`code`),
  KEY `produits_categorie_id_foreign` (`categorie_id`),
  CONSTRAINT `produits_categorie_id_foreign` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `produits` WRITE;
/*!40000 ALTER TABLE `produits` DISABLE KEYS */;
INSERT INTO `produits` VALUES
(1,'dc983971-13e1-4388-a237-13914652edf6',NULL,'SUCRE KAKI 50KG',NULL,20000.00,22000.00,10,0.00,5,1,'2026-08-12 20:39:29','2026-08-18 19:22:19',NULL,'pièce','SUCRE-KAKI-50KG-001',NULL,999.99),
(2,'d5691a2c-a99c-49fb-a5af-25a00bdc7c86',NULL,'HUILE 25 LITRES',NULL,13500.00,17500.00,8,0.00,5,1,'2026-08-12 20:39:29','2026-08-18 19:24:19',NULL,'pièce','HUILE-25-LITRES-002',NULL,999.99),
(3,'5ab6f7d7-7ac3-4b2b-bbe4-8c82697d784c',NULL,'TULIP JAUNE 50KG',NULL,5000.00,7500.00,8,0.00,5,1,'2026-08-12 20:39:29','2026-08-18 19:24:53',NULL,'pièce','TULIP-JAUNE-50K-003',NULL,999.99),
(4,'efa3e24d-cb6d-4307-978c-eeb15d122660',NULL,'FARM HOUSSE 50KG',NULL,10000.00,15000.00,10,0.00,5,1,'2026-08-12 20:39:29','2026-08-18 19:26:31',NULL,'pièce','FARM-HOUSSE-50K-004',NULL,999.99),
(5,'0c58a951-add3-4d79-ab0d-47a953f95fd7',NULL,'COOKZEN',NULL,4000.00,6000.00,10,0.00,5,1,'2026-08-12 20:39:29','2026-08-18 19:27:01',NULL,'pièce','COOKZEN-005',NULL,999.99),
(6,'3b9c1512-7881-4ff1-83b3-24932d81c78d',NULL,'HARICOT ROUGE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','HARICOT-ROUGE-006',NULL,0.00),
(7,'e04812fa-9741-45bd-a1b0-34dd6ba1d8b2',NULL,'MAIS BLANC',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MAIS-BLANC-007',NULL,0.00),
(8,'7e1fb50d-5295-45be-a181-bd76fe44b74f',NULL,'FARINE GMB',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','FARINE-GMB-008',NULL,0.00),
(9,'e9ec3cf6-05d5-4fdf-903f-e7aa0e4bcab2',NULL,'LAIT EN POUDRE ZELANDE',NULL,6500.00,6900.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-18 14:52:26',NULL,'pièce','LAIT-EN-POUDRE-009',NULL,400.00),
(10,'cdeb4f3a-7162-4869-bc99-4f7991652e64',NULL,'COQUIL SACHET BONJOURNE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUIL-SACHET-B-010',NULL,0.00),
(11,'87c481cd-e687-4463-aa14-cd9870fead9a',NULL,'CUBE MAGGI POULET',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CUBE-MAGGI-POUL-011',NULL,0.00),
(12,'10e43876-493a-4866-99a8-7eafdeb7295f',NULL,'SOJA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SOJA-012',NULL,0.00),
(13,'fb9ed7e8-09f6-49f5-93d6-5a544ad73a7f',NULL,'SARDINE ATLANTA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINE-ATLANTA-013',NULL,0.00),
(14,'8a85d25e-c17c-43cb-92c3-89e5f612cd38',NULL,'MAYONNAISE MEVIA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MAYONNAISE-MEVI-014',NULL,0.00),
(15,'86ddef17-213e-4426-84e6-b4ee0c261edb',NULL,'LAIT PEAK',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-PEAK-015',NULL,0.00),
(16,'b712d894-5010-4d75-9161-8dd55956af9b',NULL,'Cube VEDAN',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CUBE-VEDAN-016',NULL,0.00),
(17,'06009c76-e7f4-48e3-be1d-43f36235690a',NULL,'SPAGHETTI DOGA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-DOGA-017',NULL,0.00),
(18,'48052789-b1c6-4fc5-a787-8df6cdcd4cae',NULL,'SPRITE PLASTIQUE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPRITE-PLASTIQU-018',NULL,0.00),
(19,'c99207d6-4d96-4cb3-a108-01a982804d55',NULL,'LA CASERA PLASTIQUE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LA-CASERA-PLAST-019',NULL,0.00),
(20,'2c10ec3f-8bfd-4ae0-a080-54507014dcdd',NULL,'LEVURE JADU',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LEVURE-JADU-020',NULL,0.00),
(21,'07785115-9888-4351-a3c8-48bd6362cdad',NULL,'SEL SAC BLANC',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SEL-SAC-BLANC-021',NULL,0.00),
(22,'1a8a44ce-19d9-42fe-ba6f-91387e10f34b',NULL,'GARI SOHUI',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','GARI-SOHUI-022',NULL,0.00),
(23,'008ed40e-1e66-4cc1-b4ab-7a84c99afde0',NULL,'COCA COLA PLASTIQUE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COCA-COLA-PLAST-023',NULL,0.00),
(24,'36e7cd09-adf6-4a00-984d-ecd636016f63',NULL,'BICARBONATE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BICARBONATE-024',NULL,0.00),
(25,'6eaef3b4-0fe5-461e-bc59-6a3bc0996cfd',NULL,'BOISSON ENERGIE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BOISSON-ENERGIE-025',NULL,0.00),
(26,'2f048f70-1e34-4810-9c56-71e84f4fa17a',NULL,'HARICOT TAWA MOYEN',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','HARICOT-TAWA-MO-026',NULL,0.00),
(27,'3ec32313-65f3-4d6f-9df8-b49e78850929',NULL,'TOMATE SHALOM',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-SHALOM-027',NULL,0.00),
(28,'a42e63e6-e185-4b92-9523-28dfd8854ffe',NULL,'TOMATE SURE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-SURE-028',NULL,0.00),
(29,'35c30998-c5ef-488f-aaa2-63ac289cfe13',NULL,'BIG JOE 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BIG-JOE-25KG-029',NULL,0.00),
(30,'873dfce9-d918-4567-b632-23b717f771f1',NULL,'RIZ CLARK 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-CLARK-50-KG-030',NULL,0.00),
(31,'522b775d-2b0c-4724-a0f9-17c207a97996',NULL,'BLIGOE PETIT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BLIGOE-PETIT-031',NULL,0.00),
(32,'30c31dea-6030-442d-bf7d-b4e8a2c7bad2',NULL,'VOANZOU PETIT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','VOANZOU-PETIT-032',NULL,0.00),
(33,'2b707f82-d7f9-4bc5-a785-2cc00fe801d7',NULL,'TOMATE AMAZONE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-AMAZONE-033',NULL,0.00),
(34,'c3bd540e-41b5-4d19-818e-d5f67d828e3b',NULL,'MIL KAKI',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MIL-KAKI-034',NULL,0.00),
(35,'512290a8-ecf5-441d-abc6-35eaa41a7f79',NULL,'FANTA CANETTE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','FANTA-CANETTE-035',NULL,0.00),
(36,'329ad12d-54aa-49b2-9f3f-4839e045b9db',NULL,'COCA CANETTE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COCA-CANETTE-036',NULL,0.00),
(37,'0e36ecf4-3540-4168-b571-2ec15f257407',NULL,'SPRITE CANETTE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPRITE-CANETTE-037',NULL,0.00),
(38,'b4e5bd32-67f6-4beb-8392-726e14951645',NULL,'MALTA GUINESS',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MALTA-GUINESS-038',NULL,0.00),
(39,'0711a12b-a3b9-48e8-9712-00a1b63778a3',NULL,'DESPERADO GRAND',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','DESPERADO-GRAND-039',NULL,0.00),
(40,'a9310789-9cb0-4b86-aa75-e0e984b0878e',NULL,'RIZ 3 GOOD CASSE PARFUME 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-3-GOOD-CASS-040',NULL,0.00),
(42,'9ce44b4d-179f-4941-bf72-8c05356aab13',NULL,'RIZ 3 GOOD CASSE PARFUME 5 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-3-GOOD-CASS-041',NULL,0.00),
(43,'e063f2e1-4fe9-45f6-9452-e938c24f2bd8',NULL,'RIZ 3 GOOD PARFUME LONG GRAIN 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-3-GOOD-PARF-042',NULL,0.00),
(44,'c6e36554-69cc-4136-9587-c58334f9854c',NULL,'COQUILLETTE ROCH',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUILLETTE-ROC-043',NULL,0.00),
(45,'4ca76d18-9ab1-46a7-ad22-f7cee680c994',NULL,'SARDINE BONJOURNE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINE-BONJOUR-044',NULL,0.00),
(46,'e3d940bf-566a-4072-b486-477b1c66a203',NULL,'TOMATE GINNY',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-GINNY-045',NULL,0.00),
(47,'19bc6bc4-ec0b-42d1-b895-54072c338731',NULL,'HARACA ROUGE CASSE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','HARACA-ROUGE-CA-046',NULL,0.00),
(48,'8081236d-41cb-47a1-8f0e-8e61f0a877ba',NULL,'SPAGHETTI GOEYMEN',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-GOEYM-047',NULL,0.00),
(49,'2db913ae-4f96-4741-a5f4-e8840e638d74',NULL,'AWONLI HARICOT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','AWONLI-HARICOT-048',NULL,0.00),
(50,'fa2c1988-4362-4100-903d-ebdc5753a5ef',NULL,'VODY 18%',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','VODY-18-049',NULL,0.00),
(51,'49425625-a061-4f30-a69b-e60e8dac11bc',NULL,'RIZ 3 GOOD LONG GRAIN 5KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-3-GOOD-LONG-050',NULL,0.00),
(52,'bc311794-5990-4cca-bb2c-3becc9c420ca',NULL,'SACHET NOIR DE 5F',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SACHET-NOIR-DE-051',NULL,0.00),
(53,'85c00287-ef1c-410e-9848-27dbd15038e4',NULL,'SACHET BLANC DE 5F',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SACHET-BLANC-DE-052',NULL,0.00),
(54,'effed77d-9ddd-4d93-829b-62395f8a9f4d',NULL,'COUSCOUS BONJOURNE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COUSCOUS-BONJOU-053',NULL,0.00),
(55,'89220144-bdcb-49a7-aac5-c1fc56f9b703',NULL,'FARIME MOA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','FARIME-MOA-054',NULL,0.00),
(56,'06230223-97ef-4202-874c-3761dc40a46c',NULL,'KATY 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','KATY-50KG-055',NULL,0.00),
(57,'c400782e-4589-44c2-99cf-64822961c44b',NULL,'YOUKI 1,5 LITRE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','YOUKI-15-LITRE-056',NULL,0.00),
(58,'31ae3ab6-7847-411e-850a-1a324318b6a9',NULL,'TOMATE MAGNIFICAT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-MAGNIFIC-057',NULL,0.00),
(59,'9558c45f-8de9-46b6-aaf2-1b1496dcb583',NULL,'SARDINES BEAUX RIVAGES',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINES-BEAUX-058',NULL,0.00),
(60,'a2b0b6ed-ab7c-4f07-a22a-0678aee51f27',NULL,'SPAGHETTI DANU',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-DANU-059',NULL,0.00),
(61,'2bb81567-9212-453e-bdb7-55d74a605ecf',NULL,'RIZ MARINA CASSE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-MARINA-CASS-060',NULL,0.00),
(62,'1b475887-55d9-4362-a319-2764898c6035',NULL,'REAKTOR',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','REAKTOR-061',NULL,0.00),
(63,'f821e5f0-ac15-4dd7-90ef-915e5a2fd754',NULL,'BEAUFORT BOISSON',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BEAUFORT-BOISSO-062',NULL,0.00),
(64,'be5821df-28f2-4030-9e48-326a3d1d9299',NULL,'BOISSON ROX',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BOISSON-ROX-063',NULL,0.00),
(65,'d50a63e0-5489-4015-850a-f462331efad8',NULL,'MAYONNAISE GINNY',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MAYONNAISE-GINN-064',NULL,0.00),
(66,'ab626357-dbe1-4662-9560-dccf31b765a7',NULL,'LAIT CEBON',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-CEBON-065',NULL,0.00),
(67,'f2eb6c86-d1d2-4eb4-a00f-445d0d59f6c9',NULL,'MY CHOICE BLANC 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MY-CHOICE-BLANC-066',NULL,0.00),
(68,'0e83d024-bc0b-480e-8e09-c1c6c2cbfe04',NULL,'COQUILLETTE DANU',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUILLETTE-DAN-067',NULL,0.00),
(69,'631489fd-ccb6-43ea-b35f-33910a870053',NULL,'CHARBON SAC DE 100 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CHARBON-SAC-DE-068',NULL,0.00),
(70,'923cbdd7-6e2b-4996-9d4b-f6919053b156',NULL,'TOMATE BENNY 2200G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-BENNY-22-069',NULL,0.00),
(71,'44bd88d8-7e08-4c4a-96fa-34708a391c13',NULL,'COQUILLETTE OBA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUILLETTE-OBA-070',NULL,0.00),
(72,'8a5fded9-2c90-4e51-b9bd-c1b7c01ffd34',NULL,'MONSTER GRAND',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MONSTER-GRAND-071',NULL,0.00),
(73,'8b9b9b6f-886b-433e-a61d-87f8e58ac29f',NULL,'SANGRIA FORTE 18% CARTON DE 48',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SANGRIA-FORTE-1-072',NULL,0.00),
(74,'cfc16bf6-753e-4100-90be-010b2609b642',NULL,'SANGRIA FORTE 18% DETAIL',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SANGRIA-FORTE-1-073',NULL,0.00),
(75,'a47ac942-f702-40cf-9281-ff9858e4c901',NULL,'CHATEAUX DE FRANCE 11% DETAIL',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CHATEAUX-DE-FRA-074',NULL,0.00),
(76,'2197bfbb-45b7-4312-af9f-6bee61d10b84',NULL,'BULL IBO',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BULL-IBO-075',NULL,0.00),
(77,'73130c65-f0f7-4c2a-bad8-47b7307b7699',NULL,'OMO VIVA CARTON DE 26',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','OMO-VIVA-CARTON-076',NULL,0.00),
(78,'7c23d86e-cdbc-4898-8eff-853c3f20e85a',NULL,'RIZ FESTIN',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-FESTIN-077',NULL,0.00),
(79,'49a971af-f419-45f2-b476-58daffe1a8e1',NULL,'CLARK 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CLARK-25KG-078',NULL,0.00),
(80,'24aae18e-5d1f-4d22-a58e-8615403f3d4f',NULL,'VODY 22%',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','VODY-22-079',NULL,0.00),
(81,'bc3a4f31-ef2b-412d-96b5-eac37f97ac17',NULL,'LAIT SUPER 8',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-SUPER-8-080',NULL,0.00),
(82,'61981dc5-a3d0-48d6-9d09-708e4c5b4087',NULL,'NONO 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','NONO-25-KG-081',NULL,0.00),
(83,'cf39bc50-9b4c-4567-87b5-c5bf42ead3ec',NULL,'COUSCOUS LIDO',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COUSCOUS-LIDO-082',NULL,0.00),
(84,'80ea2a22-4269-40e2-8d23-d9ae96e28439',NULL,'YOUKI 0,5 LITRE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','YOUKI-05-LITRE-083',NULL,0.00),
(85,'4e09355c-e54d-4fe1-937a-83356a1ca3de',NULL,'GUINESS',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','GUINESS-084',NULL,0.00),
(86,'dfe9ec71-045b-4d03-9758-b39ac1f8df7e',NULL,'BETA PETIT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BETA-PETIT-085',NULL,0.00),
(87,'b72dfaf9-7012-4e59-b515-f26d529649d7',NULL,'LITTLE THAI',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LITTLE-THAI-086',NULL,0.00),
(88,'be2494b6-6542-480e-9bf4-fa3a99f34e06',NULL,'PJS 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','PJS-50-KG-087',NULL,0.00),
(89,'c706b891-017f-4753-989f-dbc9da47a574',NULL,'DIVA ROYAL 25 KG SAC JAUNE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','DIVA-ROYAL-25-K-088',NULL,0.00),
(90,'8071c6d5-6dad-4a06-aa31-f6e258ea4f90',NULL,'DIVA KAKI 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','DIVA-KAKI-25-KG-089',NULL,0.00),
(91,'cff128a3-5068-4b98-b80e-641f33e330e7',NULL,'ROOP 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','ROOP-50KG-090',NULL,0.00),
(92,'7824992e-81a1-415a-92cb-3a9240449436',NULL,'RIZ GINO 5KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-GINO-5KG-091',NULL,0.00),
(93,'d2efc139-f7d7-48a2-931e-d0c68cea3b45',NULL,'LAIT EN POUDRE GINNY',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-EN-POUDRE-092',NULL,0.00),
(94,'3f92295e-e275-4a63-89f3-ff1642e64b6d',NULL,'COQUILLETTE DIARI CARTON',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUILLETTE-DIA-093',NULL,0.00),
(95,'a4070365-d56a-4779-98f0-1b8b9ed57b4f',NULL,'KANGAROU CASSE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','KANGAROU-CASSE-094',NULL,0.00),
(96,'e4017806-7eab-4677-89d9-726138bc58af',NULL,'DIVA SAC VIOLET 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','DIVA-SAC-VIOLET-095',NULL,0.00),
(97,'c60ffe49-6696-42c8-a989-4e18f8a11aa7',NULL,'LUXE IBO 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LUXE-IBO-50KG-096',NULL,0.00),
(98,'3f3eaedb-8173-4e00-9199-f8c45f85dc8b',NULL,'MAMAN PRETTY IBO 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MAMAN-PRETTY-IB-097',NULL,0.00),
(99,'82ed1203-ba4c-4b67-95e4-be402638eece',NULL,'TOMATE BENNY 400G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-BENNY-40-098',NULL,0.00),
(100,'f931afa8-0f9e-43c6-9fac-c34623606728',NULL,'COUSCOUS GINNY',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COUSCOUS-GINNY-099',NULL,0.00),
(101,'393b132f-fcb7-4faa-8604-c5e8b3e85f35',NULL,'OPPI UNIQUE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','OPPI-UNIQUE-100',NULL,0.00),
(102,'00d641a5-498e-4353-bd35-530cc8cd0567',NULL,'RAHI IBO 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RAHI-IBO-50KG-101',NULL,0.00),
(103,'a9792d0b-f624-4fe1-9b80-6499cfaa637c',NULL,'CUBE ROYAL',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CUBE-ROYAL-102',NULL,0.00),
(104,'2e730e46-0783-44c6-a3bd-d7036493c9ae',NULL,'BAOBAB POUDRE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BAOBAB-POUDRE-103',NULL,0.00),
(105,'acd5a4f5-0edc-4499-9808-9393a1dcb3a7',NULL,'SPAGHETTI DIARRI 500G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-DIARR-104',NULL,0.00),
(106,'3049a641-b926-4205-8d7d-0978b957a609',NULL,'SARDINE ALPHA CHEF',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINE-ALPHA-C-105',NULL,0.00),
(107,'008a0318-7e4d-47c5-8963-c9b807c2307a',NULL,'FANTA PLASTIQUE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','FANTA-PLASTIQUE-106',NULL,0.00),
(108,'39b1c019-82a1-43b7-a912-d73435e61e84',NULL,'BUDWEISER CANETTE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BUDWEISER-CANET-107',NULL,0.00),
(109,'03e2303a-2264-47be-b4d2-d15a015978aa',NULL,'TOMATE YOVO 70 G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-YOVO-70-108',NULL,0.00),
(110,'fdba5f5d-7bcf-4862-956b-6f0bd1fcc90e',NULL,'HEINEKEN PETIT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','HEINEKEN-PETIT-109',NULL,0.00),
(111,'5d2feb69-a5cb-46da-9917-70dc5415611a',NULL,'BETA GRAND',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BETA-GRAND-110',NULL,0.00),
(112,'d601c85c-6a4d-4459-86eb-86fc32d5ac53',NULL,'SARDINE 222',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINE-222-111',NULL,0.00),
(113,'55497954-863a-45d4-8340-4e5cd8a0f3a2',NULL,'PRAGATI GOLD 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','PRAGATI-GOLD-25-112',NULL,0.00),
(114,'43515bb4-2929-4e92-a627-43615d5a818c',NULL,'KATY 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','KATY-25KG-113',NULL,0.00),
(115,'a9ab23c1-b845-4bd1-b2f2-da125c540b29',NULL,'JOKER 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','JOKER-25-KG-114',NULL,0.00),
(116,'a8fcda68-7870-48c2-929f-21ae73812183',NULL,'GIL GIL CASSE 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','GIL-GIL-CASSE-2-115',NULL,0.00),
(117,'6f617479-3ab4-4e0c-80b9-d28aa9056905',NULL,'DJOLOF 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','DJOLOF-50KG-116',NULL,0.00),
(118,'2ddd4adb-ad19-4c38-b0dc-cb5a8ff9ba60',NULL,'VEDAN PETIT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','VEDAN-PETIT-117',NULL,0.00),
(119,'7fcbf4ad-c4ed-41e5-ba1c-38bba6b10aab',NULL,'BEAU GARCON BASMATI 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BEAU-GARCON-BAS-118',NULL,0.00),
(120,'ff925e56-a4ba-4f86-8f65-da28d419cba3',NULL,'BEAU GARCON THAILANDAIS 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BEAU-GARCON-THA-119',NULL,0.00),
(121,'59191d43-df53-4859-ac9e-a1167f4da929',NULL,'JIYO 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','JIYO-25-KG-120',NULL,0.00),
(122,'b2f85706-7ae2-4808-8a4b-abc60cad63e0',NULL,'RIZ AAA 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-AAA-50-KG-121',NULL,0.00),
(123,'e16d7ee3-3d2a-4132-a2f7-94880edb0d2b',NULL,'FOOTBALL 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','FOOTBALL-50-KG-122',NULL,0.00),
(124,'0edcb3c2-d79c-4e48-ae6d-f76984a8f7d8',NULL,'MEVIA EN PLASTIQUE 5 LITRES',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MEVIA-EN-PLASTI-123',NULL,0.00),
(125,'26c8bcad-8c97-4b03-ad54-ea71f618db9d',NULL,'SPAGHETTI 3 GOOD',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-3-GOO-124',NULL,0.00),
(126,'c52bd33a-5245-4061-9545-03dcbba09f32',NULL,'COQUILLETTE 3 GOOD',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUILLETTE-3-G-125',NULL,0.00),
(127,'10d7479c-44ee-4f52-8c40-7b796c7ab643',NULL,'LAIT CONCENTRE 3 GOOD',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-CONCENTRE-126',NULL,0.00),
(128,'cf54640c-4168-4413-b51e-b94d0af51784',NULL,'TOMATE OD 3 GOOD',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-OD-3-GOO-127',NULL,0.00),
(129,'efefd3cd-0aed-462d-8640-e677ed833827',NULL,'OMO VIVA 800G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','OMO-VIVA-800G-128',NULL,0.00),
(130,'65f3912e-171e-49da-82d0-2e9765ae1d5b',NULL,'SAVON KANKPE CARTON DE 30',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SAVON-KANKPE-CA-129',NULL,0.00),
(131,'c416c556-8545-4726-88a3-ed4e38fce35b',NULL,'SAVON KANKPE DETAIL',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SAVON-KANKPE-DE-130',NULL,0.00),
(132,'7efd75bc-7618-4d80-8728-f50804c32567',NULL,'STAR BIERE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','STAR-BIERE-131',NULL,0.00),
(133,'4266df46-2784-4d8d-9b72-087ea78e0680',NULL,'RC CANETTE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RC-CANETTE-132',NULL,0.00),
(134,'09ddbd0d-e460-46a2-b199-fc47a3fac256',NULL,'RIZ IBO 8888 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-IBO-8888-50-133',NULL,0.00),
(135,'a9d559cd-ecd4-4e26-a4d5-e63ddd8f3496',NULL,'IBO DOUBLE ELEPHANT 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','IBO-DOUBLE-ELEP-134',NULL,0.00),
(136,'e0fba1c2-5cb6-43ee-9a03-6f058e382734',NULL,'SARDINES JADU',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINES-JADU-135',NULL,0.00),
(137,'5613aa35-7560-46ac-b978-67232fd6f754',NULL,'COUSCOUS KOULHALA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COUSCOUS-KOULHA-136',NULL,0.00),
(138,'2a220808-ddab-4ae7-a516-3f20207984da',NULL,'PAON 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','PAON-50-KG-137',NULL,0.00),
(139,'9d756f79-8a47-4427-8895-09b73ed1da49',NULL,'SARDINES LOKKI',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINES-LOKKI-138',NULL,0.00),
(140,'c968c1c4-f070-4ee3-b6b0-d06ad3920c85',NULL,'SARDINES CLEMA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINES-CLEMA-139',NULL,0.00),
(141,'25a7e272-af1b-49c4-825e-e81fd66874bb',NULL,'ONIMA 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','ONIMA-25-KG-140',NULL,0.00),
(142,'98e6f380-a7b9-4ca9-a3be-13081f20e1b1',NULL,'KT GOLD 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','KT-GOLD-50-KG-141',NULL,0.00),
(143,'6d36e5db-3114-4d4b-8dc1-268578faa727',NULL,'SPAGHETTI BELINA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-BELIN-142',NULL,0.00),
(144,'fafbbf3c-fe6b-40cd-a27c-133f938d2eae',NULL,'COUSCOUS FENA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COUSCOUS-FENA-143',NULL,0.00),
(145,'1790047e-0b15-4a10-abb6-2fbeefbdc33f',NULL,'TOMATE YOVO 2200G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-YOVO-220-144',NULL,0.00),
(146,'d6a1e944-e288-4cf7-980d-6918c0fc14d6',NULL,'PIVERT SAC VERT 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','PIVERT-SAC-VERT-145',NULL,0.00),
(147,'a0c035e3-9d8d-4b1f-a86f-4f607c89b317',NULL,'PIVERT SAC VIOLET 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','PIVERT-SAC-VIOL-146',NULL,0.00),
(148,'9857e412-4f89-4e67-a61f-8b4214d821e6',NULL,'STAR ORIGINAL BASMATI 25KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','STAR-ORIGINAL-B-147',NULL,0.00),
(149,'0621cfc5-5e31-44db-88ef-d0526e5a760d',NULL,'FARM HOUSSE VERT 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','FARM-HOUSSE-VER-148',NULL,0.00),
(150,'7ad587b2-3bea-4158-8b63-fd14a69d59a6',NULL,'IBO JOLLOF GOLD 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','IBO-JOLLOF-GOLD-149',NULL,0.00),
(151,'8c30a6d5-d399-4883-886c-8457d44ee813',NULL,'LEOPARD 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LEOPARD-50KG-150',NULL,0.00),
(152,'d3c0d4ec-2129-4798-a051-9bb88d730482',NULL,'MADHU CASSE 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MADHU-CASSE-50-151',NULL,0.00),
(153,'27a10a30-b9d3-481f-9e16-e0310c457a0f',NULL,'LAIT EN POUDRE FAMILIA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-EN-POUDRE-152',NULL,0.00),
(154,'ad02cae5-1595-4208-8f63-94038349b3f0',NULL,'SPAGHETTI MAGNIFICAT',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-MAGNI-153',NULL,0.00),
(155,'040d2a1a-f6fb-48d3-8a4b-d0bece6dd877',NULL,'COQUILLETTE BELLA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','COQUILLETTE-BEL-154',NULL,0.00),
(156,'f0e42c16-e7be-466e-8ca2-582f9f0667d5',NULL,'LAIT CONCENTRE MAGUIDA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-CONCENTRE-155',NULL,0.00),
(157,'47e3f83d-f5fb-4cb6-875a-23b2d6fe1fc6',NULL,'LAIT CONCENTRE TOP SAHO',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-CONCENTRE-156',NULL,0.00),
(158,'e3a8ce96-476b-4417-b59e-8e6c43c38e6d',NULL,'LAIT CONCENTRE MY MILK',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-CONCENTRE-157',NULL,0.00),
(159,'dfcdd5b6-2d4f-415e-81f7-0ce5494745d9',NULL,'LAIT CONCENTRE UNITY',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-CONCENTRE-158',NULL,0.00),
(160,'30baf810-038a-465f-aafc-6ab8ee23b0f2',NULL,'TOMATE PSP 2200G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-PSP-2200-159',NULL,0.00),
(161,'7d43f72c-c867-442b-9cc7-48b7ebd89b1a',NULL,'ONIMA 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','ONIMA-50-KG-160',NULL,0.00),
(162,'924f2cf9-5b1d-4eb8-a2e3-eb7799b3e9e6',NULL,'CAFE BONJOURNE CARTON',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','CAFE-BONJOURNE-161',NULL,0.00),
(163,'61cd8355-20c7-4c14-9302-15f05a664bd5',NULL,'MILO FRESH CARTON',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MILO-FRESH-CART-162',NULL,0.00),
(164,'e72ea8c0-d4c4-4666-9032-7541980b192b',NULL,'BISSAP',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','BISSAP-163',NULL,0.00),
(165,'305123e2-96ad-4a82-8286-4f2d9a06adbf',NULL,'MYLY GOLD IBO 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MYLY-GOLD-IBO-5-164',NULL,0.00),
(166,'7eba5f52-a29e-452c-96e0-a7ee58cbc82c',NULL,'OPPI SUPER 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','OPPI-SUPER-50-K-165',NULL,0.00),
(167,'eee6a34d-45ea-4b9b-b262-0a453ab1cfb8',NULL,'OPPI POINTININI 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','OPPI-POINTININI-166',NULL,0.00),
(168,'5ff74525-ae06-4112-baa3-a500b271038e',NULL,'JOLIE 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','JOLIE-25-KG-167',NULL,0.00),
(169,'6c27d5ae-d12b-45f7-b523-b6a14ec4599e',NULL,'SARDINE DANU',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SARDINE-DANU-168',NULL,0.00),
(170,'7ceeb746-e46f-4541-8aa6-15541cd25e0c',NULL,'SAFARI RIZ BLANC 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SAFARI-RIZ-BLAN-169',NULL,0.00),
(171,'63de7e9f-1782-44f5-a703-87e6baf977c3',NULL,'MAIS JAUNE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MAIS-JAUNE-170',NULL,0.00),
(172,'b2516e54-d3f8-43b8-8073-e1fd2ec7d99f',NULL,'SPAGHETTI BELLA',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-BELLA-171',NULL,0.00),
(173,'1c4cab21-338d-477e-bb82-984626e501a0',NULL,'JOLIE SAC ORANGE 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','JOLIE-SAC-ORANG-172',NULL,0.00),
(174,'98a491a4-113a-4cc0-8904-dd654aead8a7',NULL,'OMO WAVE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','OMO-WAVE-173',NULL,0.00),
(175,'9ee11062-1397-433c-a9eb-27336841a9e7',NULL,'INDOMIE GRAND',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','INDOMIE-GRAND-174',NULL,0.00),
(176,'3bf0742d-28e3-45f7-a16d-5aa56699600a',NULL,'SAGONO SPECIAL 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SAGONO-SPECIAL-175',NULL,0.00),
(177,'b1149680-4850-4904-896f-feb51df3f217',NULL,'LAIT TOUS LES JOURS',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LAIT-TOUS-LES-J-176',NULL,0.00),
(178,'758db270-376b-42fe-b9c9-897a90d9f206',NULL,'PALMIDA BENIN',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','PALMIDA-BENIN-177',NULL,0.00),
(179,'32b0686e-a7f5-4690-b0d0-eae5f718b32b',NULL,'MAYONNAISE BONJOURNE GRAND',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','MAYONNAISE-BONJ-178',NULL,0.00),
(180,'5ff84842-3efe-41b9-a10c-20f67bf7ed8f',NULL,'SPAGHETTI BONJOURNE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','SPAGHETTI-BONJO-179',NULL,0.00),
(181,'5dde59d6-2afd-477c-9739-0b77c52fa83f',NULL,'TIK TOK CASSE 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TIK-TOK-CASSE-5-180',NULL,0.00),
(182,'ddcf0819-c851-4d6e-bce4-93299a232d3c',NULL,'LATIF 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LATIF-50KG-181',NULL,0.00),
(183,'eecf7898-0c16-4cb0-b019-051d14245d2c',NULL,'LEGENDE BIERE',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','LEGENDE-BIERE-182',NULL,0.00),
(184,'97e85d60-bd9b-45cb-96ea-6544d0947d32',NULL,'STAR CITRON',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','STAR-CITRON-183',NULL,0.00),
(185,'cc1d7757-f915-4639-b7f7-cbcbe544e499',NULL,'HARAKA VERT 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','HARAKA-VERT-50-184',NULL,0.00),
(186,'23bb87a7-0e06-40c7-ae05-68ad1787b533',NULL,'RIZ BLANC ROSETTE 50 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','RIZ-BLANC-ROSET-185',NULL,0.00),
(187,'8a4e6b12-98bc-4578-b35b-23063040953b',NULL,'AWONLI PETIT GRAIN',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','AWONLI-PETIT-GR-186',NULL,0.00),
(188,'160751d5-df7a-43ba-bfad-9790692aa051',NULL,'TOMATE JADU 2200G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-JADU-220-187',NULL,0.00),
(189,'a1a51d70-7d3e-4677-8442-ed13ccf1738b',NULL,'GIL GIL LONG GRAIN 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','GIL-GIL-LONG-GR-188',NULL,0.00),
(190,'bd3aab1b-ce50-474c-86f4-bfc884a287cc',NULL,'TOMATE AMINATA 2200G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-AMINATA-189',NULL,0.00),
(191,'c227cb83-88ff-4b1f-b538-47d2e075ab4c',NULL,'TOMATE SALMA 2200G',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TOMATE-SALMA-22-190',NULL,0.00),
(192,'23dacd38-7abe-4fbf-9b10-bc84b0653b21',NULL,'TULIP 25 KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','TULIP-25-KG-191',NULL,0.00),
(193,'781b1c29-3617-4a3b-b8f1-a4f811f53f52',NULL,'JOLI CLASSIC 50KG',NULL,0.00,0.00,0,0.00,5,1,'2026-08-12 20:39:29','2026-08-12 20:39:29',NULL,'pièce','JOLI-CLASSIC-50-192',NULL,0.00);
/*!40000 ALTER TABLE `produits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `recouvrements`
--

DROP TABLE IF EXISTS `recouvrements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recouvrements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `vente_id` bigint(20) unsigned NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `montant` decimal(12,2) NOT NULL,
  `date_recouvrement` date NOT NULL,
  `heure_recouvrement` time DEFAULT NULL,
  `mode_paiement` enum('especes','mobile','autre') NOT NULL DEFAULT 'especes',
  `statut` enum('paye','partiel','refus','absent','promesse') NOT NULL DEFAULT 'paye',
  `commentaire` text DEFAULT NULL,
  `synced` tinyint(1) NOT NULL DEFAULT 0,
  `sync_uuid` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `recouvrements_uuid_unique` (`uuid`),
  KEY `recouvrements_vente_id_foreign` (`vente_id`),
  KEY `recouvrements_agent_id_foreign` (`agent_id`),
  CONSTRAINT `recouvrements_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `recouvrements_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recouvrements`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `recouvrements` WRITE;
/*!40000 ALTER TABLE `recouvrements` DISABLE KEYS */;
INSERT INTO `recouvrements` VALUES
(1,'965813f4-c57e-4ae8-8cd9-d4e4432ea040',1,1,3700.00,'2026-08-17','23:14:29','especes','paye',NULL,1,NULL,'2026-08-17 21:14:29','2026-08-17 21:14:29'),
(3,'b3db80b2-5e1f-416f-b536-dc62f36d611d',1,3,3750.00,'2026-08-19','08:18:55','especes','paye',NULL,1,NULL,'2026-08-19 06:18:55','2026-08-19 06:18:55'),
(5,'64155dd6-e31a-413e-8733-b15d61274e9b',1,3,3750.00,'2026-08-20','00:37:22','especes','paye',NULL,1,NULL,'2026-08-19 22:37:22','2026-08-19 22:37:22'),
(8,'037aee07-e908-40a1-adb4-76138be2628c',2,3,6150.00,'2026-08-20','22:14:58','especes','paye',NULL,1,NULL,'2026-08-20 20:14:58','2026-08-20 20:14:58'),
(9,'23c42791-3d42-41b6-a491-f3dbe2be30f0',2,3,6150.00,'2026-08-20','23:05:16','especes','paye',NULL,1,NULL,'2026-08-20 21:05:16','2026-08-20 21:05:16'),
(10,'93a769c1-97b4-48fe-bd6d-518812d0e052',2,3,6150.00,'2026-08-20','23:21:34','especes','paye',NULL,1,NULL,'2026-08-20 21:21:34','2026-08-20 21:21:34'),
(11,'0aa1acd2-c318-4f47-a97f-4632ff9b6db9',2,3,12300.00,'2026-08-22','17:07:33','especes','paye',NULL,1,'48de30b7-8480-4f0c-a9d8-f07df45eeece','2026-08-22 15:07:33','2026-08-22 15:07:33'),
(12,'90f95ce0-0f71-4d6b-b3c8-eea61960b967',1,3,3750.00,'2026-08-22','17:07:33','especes','paye',NULL,1,'382397b1-3397-4d43-b187-966f235b7eed','2026-08-22 15:07:33','2026-08-22 15:07:33');
/*!40000 ALTER TABLE `recouvrements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `scores_solvabilite`
--

DROP TABLE IF EXISTS `scores_solvabilite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scores_solvabilite` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `score` int(11) NOT NULL DEFAULT 100,
  `nb_credits_total` int(11) NOT NULL DEFAULT 0,
  `nb_credits_termines` int(11) NOT NULL DEFAULT 0,
  `nb_retards` int(11) NOT NULL DEFAULT 0,
  `montant_total_rembourse` decimal(12,2) NOT NULL DEFAULT 0.00,
  `montant_total_du` decimal(12,2) NOT NULL DEFAULT 0.00,
  `date_calcul` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scores_solvabilite_debiteur_id_foreign` (`debiteur_id`),
  CONSTRAINT `scores_solvabilite_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scores_solvabilite`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `scores_solvabilite` WRITE;
/*!40000 ALTER TABLE `scores_solvabilite` DISABLE KEYS */;
INSERT INTO `scores_solvabilite` VALUES
(1,2,50,0,0,0,0.00,0.00,'2026-08-17 20:40:13','2026-08-17 19:51:52','2026-08-17 20:40:13'),
(2,4,50,0,0,0,0.00,0.00,'2026-08-17 20:39:34','2026-08-17 20:08:55','2026-08-17 20:39:34'),
(3,1,50,0,0,0,0.00,0.00,'2026-08-17 20:39:49','2026-08-17 20:34:21','2026-08-17 20:39:49'),
(4,3,50,0,0,0,0.00,0.00,'2026-08-17 20:40:03','2026-08-17 20:40:03','2026-08-17 20:40:03'),
(5,5,31,1,0,4,14950.00,75000.00,'2026-08-25 17:01:44','2026-08-17 20:42:08','2026-08-25 17:01:44'),
(6,6,32,1,0,3,30750.00,123000.00,'2026-08-25 17:01:13','2026-08-17 21:02:33','2026-08-25 17:01:13');
/*!40000 ALTER TABLE `scores_solvabilite` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sync_logs`
--

DROP TABLE IF EXISTS `sync_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sync_uuid` char(36) NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `status` enum('pending','success','conflict','failed') NOT NULL DEFAULT 'pending',
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sync_logs_sync_uuid_unique` (`sync_uuid`),
  KEY `sync_logs_agent_id_foreign` (`agent_id`),
  CONSTRAINT `sync_logs_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sync_logs` WRITE;
/*!40000 ALTER TABLE `sync_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `synthese_journaliere`
--

DROP TABLE IF EXISTS `synthese_journaliere`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `synthese_journaliere` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `nb_debiteurs` int(11) NOT NULL DEFAULT 0,
  `montant_attendu` decimal(12,2) NOT NULL DEFAULT 0.00,
  `montant_encaisse` decimal(12,2) NOT NULL DEFAULT 0.00,
  `montant_impaye` decimal(12,2) NOT NULL DEFAULT 0.00,
  `taux_recouvrement` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `synthese_journaliere_date_agent_id_unique` (`date`,`agent_id`),
  KEY `synthese_journaliere_agent_id_foreign` (`agent_id`),
  CONSTRAINT `synthese_journaliere_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `synthese_journaliere`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `synthese_journaliere` WRITE;
/*!40000 ALTER TABLE `synthese_journaliere` DISABLE KEYS */;
INSERT INTO `synthese_journaliere` VALUES
(1,'2026-08-11',2,0,0.00,0.00,0.00,0.00,'2026-08-10 23:24:18','2026-08-11 21:18:53'),
(2,'2026-08-11',3,0,0.00,0.00,0.00,0.00,'2026-08-10 23:24:18','2026-08-11 21:18:53'),
(3,'2026-08-11',4,0,0.00,0.00,0.00,0.00,'2026-08-10 23:24:18','2026-08-11 21:18:53'),
(4,'2026-08-12',2,0,0.00,0.00,0.00,0.00,'2026-08-11 22:50:14','2026-08-12 21:25:17'),
(5,'2026-08-12',3,0,0.00,0.00,0.00,0.00,'2026-08-11 22:50:14','2026-08-12 21:25:17'),
(6,'2026-08-12',4,0,0.00,0.00,0.00,0.00,'2026-08-11 22:50:14','2026-08-12 21:25:17'),
(7,'2026-08-13',2,0,0.00,0.00,0.00,0.00,'2026-08-12 22:03:25','2026-08-13 11:24:59'),
(8,'2026-08-13',3,0,0.00,0.00,0.00,0.00,'2026-08-12 22:03:25','2026-08-13 11:24:59'),
(9,'2026-08-13',4,0,0.00,0.00,0.00,0.00,'2026-08-12 22:03:25','2026-08-13 11:24:59'),
(10,'2026-08-14',2,0,0.00,0.00,0.00,0.00,'2026-08-14 01:44:20','2026-08-14 20:43:39'),
(11,'2026-08-14',3,0,0.00,0.00,0.00,0.00,'2026-08-14 01:44:20','2026-08-14 20:43:39'),
(12,'2026-08-14',4,0,0.00,0.00,0.00,0.00,'2026-08-14 01:44:20','2026-08-14 20:43:39'),
(13,'2026-08-15',2,0,0.00,0.00,0.00,0.00,'2026-08-15 10:30:12','2026-08-15 19:32:10'),
(14,'2026-08-15',3,0,0.00,0.00,0.00,0.00,'2026-08-15 10:30:12','2026-08-15 19:32:10'),
(15,'2026-08-15',4,0,0.00,0.00,0.00,0.00,'2026-08-15 10:30:12','2026-08-15 19:32:10'),
(16,'2026-08-16',2,0,0.00,0.00,0.00,0.00,'2026-08-16 17:59:51','2026-08-16 18:35:11'),
(17,'2026-08-16',3,0,0.00,0.00,0.00,0.00,'2026-08-16 17:59:51','2026-08-16 18:35:11'),
(18,'2026-08-16',4,0,0.00,0.00,0.00,0.00,'2026-08-16 17:59:51','2026-08-16 18:35:11'),
(19,'2026-08-17',2,0,0.00,0.00,0.00,0.00,'2026-08-17 11:53:01','2026-08-17 21:52:50'),
(20,'2026-08-17',3,0,0.00,0.00,0.00,0.00,'2026-08-17 11:53:01','2026-08-17 21:52:50'),
(21,'2026-08-17',4,0,0.00,0.00,0.00,0.00,'2026-08-17 11:53:01','2026-08-17 21:52:50'),
(22,'2026-08-18',2,0,0.00,0.00,0.00,0.00,'2026-08-17 22:07:20','2026-08-18 21:47:24'),
(23,'2026-08-18',3,2,9900.00,6150.00,3750.00,62.12,'2026-08-17 22:07:20','2026-08-18 21:47:24'),
(24,'2026-08-18',4,0,0.00,0.00,0.00,0.00,'2026-08-17 22:07:20','2026-08-18 21:47:24'),
(25,'2026-08-19',2,0,0.00,0.00,0.00,0.00,'2026-08-18 22:38:15','2026-08-18 23:23:59'),
(26,'2026-08-19',3,2,9900.00,0.00,9900.00,0.00,'2026-08-18 22:38:15','2026-08-18 23:23:59'),
(27,'2026-08-19',4,0,0.00,0.00,0.00,0.00,'2026-08-18 22:38:15','2026-08-18 23:23:59'),
(28,'2026-08-20',2,0,0.00,0.00,0.00,0.00,'2026-08-19 22:39:00','2026-08-20 21:29:12'),
(29,'2026-08-20',3,2,9900.00,22200.00,0.00,224.24,'2026-08-19 22:39:00','2026-08-20 21:29:12'),
(30,'2026-08-20',4,0,0.00,0.00,0.00,0.00,'2026-08-19 22:39:00','2026-08-20 21:29:12'),
(31,'2026-08-23',2,0,0.00,0.00,0.00,0.00,'2026-08-23 21:46:14','2026-08-23 21:56:19'),
(32,'2026-08-23',3,2,9900.00,0.00,9900.00,0.00,'2026-08-23 21:46:14','2026-08-23 21:56:19'),
(33,'2026-08-23',4,0,0.00,0.00,0.00,0.00,'2026-08-23 21:46:14','2026-08-23 21:56:19'),
(34,'2026-08-24',2,0,0.00,0.00,0.00,0.00,'2026-08-24 06:19:11','2026-08-24 21:59:34'),
(35,'2026-08-24',3,2,9900.00,0.00,9900.00,0.00,'2026-08-24 06:19:11','2026-08-24 21:59:34'),
(36,'2026-08-24',4,0,0.00,0.00,0.00,0.00,'2026-08-24 06:19:11','2026-08-24 21:59:34'),
(37,'2026-08-25',2,0,0.00,0.00,0.00,0.00,'2026-08-24 22:16:33','2026-08-25 17:00:53'),
(38,'2026-08-25',3,2,9900.00,0.00,9900.00,0.00,'2026-08-24 22:16:33','2026-08-25 17:00:53'),
(39,'2026-08-25',4,0,0.00,0.00,0.00,0.00,'2026-08-24 22:16:33','2026-08-25 17:00:53');
/*!40000 ALTER TABLE `synthese_journaliere` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tournee_demarrages`
--

DROP TABLE IF EXISTS `tournee_demarrages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tournee_demarrages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `date_tournee` date NOT NULL,
  `heure_demarrage` datetime NOT NULL,
  `heure_fin` datetime DEFAULT NULL,
  `statut` varchar(255) NOT NULL DEFAULT 'en_cours',
  `gps_depart` varchar(255) DEFAULT NULL,
  `gps_arrivee` varchar(255) DEFAULT NULL,
  `synced` tinyint(1) NOT NULL DEFAULT 1,
  `sync_uuid` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tournee_demarrages_uuid_unique` (`uuid`),
  KEY `tournee_demarrages_agent_id_foreign` (`agent_id`),
  CONSTRAINT `tournee_demarrages_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tournee_demarrages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tournee_demarrages` WRITE;
/*!40000 ALTER TABLE `tournee_demarrages` DISABLE KEYS */;
INSERT INTO `tournee_demarrages` VALUES
(1,'f9205f28-0094-40b8-ab35-502861627412',3,'2026-08-20','2026-08-20 02:17:45','2026-08-20 02:18:20','terminee',NULL,NULL,1,NULL,'2026-08-20 00:17:45','2026-08-20 00:18:20'),
(2,'b6b17556-cfd4-4871-893f-be14d8f7f4aa',3,'2026-08-20','2026-08-20 02:28:03','2026-08-20 02:28:19','terminee',NULL,NULL,1,NULL,'2026-08-20 00:28:03','2026-08-20 00:28:19'),
(3,'4c81ec40-7897-4231-ba58-8c8af31bf725',3,'2026-08-20','2026-08-20 02:31:34','2026-08-20 02:31:40','terminee',NULL,NULL,1,NULL,'2026-08-20 00:31:34','2026-08-20 00:31:40'),
(4,'1d1d6828-9a4d-41e7-b596-44cd24f98638',3,'2026-08-20','2026-08-20 12:27:20',NULL,'en_cours',NULL,NULL,1,NULL,'2026-08-20 10:27:20','2026-08-20 10:27:20'),
(5,'cf2da1d1-3034-49ec-aec8-caa006f81c06',3,'2026-08-22','2026-08-22 16:34:16',NULL,'en_cours',NULL,NULL,1,NULL,'2026-08-22 14:34:16','2026-08-22 14:34:16'),
(6,'256f1952-7bb4-4aef-8c72-0bc99ee4d3ac',3,'2026-08-25','2026-08-25 17:53:50',NULL,'en_cours',NULL,NULL,1,NULL,'2026-08-25 15:53:50','2026-08-25 15:53:50');
/*!40000 ALTER TABLE `tournee_demarrages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `role` enum('gerante','chef_agence','agent') NOT NULL DEFAULT 'agent',
  `agence_id` int(10) unsigned DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(64) DEFAULT NULL,
  `token_expires_at` timestamp NULL DEFAULT NULL,
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_token_unique` (`token`),
  KEY `users_agence_id_index` (`agence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'00000000-0000-0000-0000-000000000001','HOUNYE','Pélagie','gerante@sourougnon.com','0000000000','gerante',1,'$2y$12$vsboLY006dnM2tgxZihfU.KY7SRAqj0bnHJGNazfzHOUXzYu4yA9y','jkzlXmhVRMekdH0XhsO73Hbe1SEwLjl5cumd1BKTdoYcjbpYKzGzlIrouDFCiboG','2026-08-26 15:46:30',1,'2026-08-10 23:23:03','2026-08-25 15:46:30'),
(2,'087bb14f-5db1-479f-9a4a-f209618d52d9','TestModif','Test','test@sourougnon.com','22900000000','agent',1,'$2y$12$aEjJKSU8MdHkS4CVlBtgd.S66wnXOV3edppxV7dUqXG99pZisKYfK','wJDkATghrDjXY5zTl9QwBxUmtGPG6550pBputc58u2l5E3LtNwNpIGiHWX8URreC','2026-08-19 23:20:21',1,'2026-08-10 23:23:55','2026-08-18 23:20:21'),
(3,'9c66a3f0-b70f-4b33-b075-98485d5c16fe','Mensah','Abla','abla.mensah@sourougnon.com','22900000000','agent',1,'$2y$12$GvWYF0d5B.2lFphoQYW.ae1lEqZtqzThe7e3ARjdUXui8t3I/ZYCy','inycVZHo6s0YPVgHbkO3AxqBDip7ZItUCSv4aetYTOeBaThpsDEYnyjNK1AkpEds','2026-08-27 12:10:45',1,'2026-08-10 23:23:55','2026-08-26 12:10:45'),
(4,'e3a8e42d-8f4b-435a-90d3-103bb7db9fda','Akakpo','Kodjo','kodjo.akakpo@sourougnon.com',NULL,'agent',1,'$2y$12$CFGH8Y7y.2sAGfDxPcSGTuu2uO4ryN.J9sS4A9th8bh5qmPT.lmAW',NULL,NULL,1,'2026-08-10 23:23:56','2026-08-10 23:23:56'),
(5,'9027bc5c-cb49-4d7f-b05f-24f6546afc8d','Chef','Agence','chef@sourougnon.com',NULL,'chef_agence',1,'$2y$12$NUgDdo0zxih/tUYQdFIfye4XiNXQA0nePFig2tMK96fOSB5umK7ce','LhQ5SM28lGni7kf0x7tn87IMJRpisGzjG0tR7paks69C20CyhYc7rmGmEJdULRHp','2026-08-25 21:22:07',1,'2026-08-11 10:56:38','2026-08-24 21:22:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `vente_produits`
--

DROP TABLE IF EXISTS `vente_produits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vente_produits` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vente_id` bigint(20) unsigned NOT NULL,
  `produit_id` bigint(20) unsigned NOT NULL,
  `quantite` int(11) NOT NULL DEFAULT 1,
  `prix_unitaire` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vente_produits_vente_id_foreign` (`vente_id`),
  KEY `vente_produits_produit_id_foreign` (`produit_id`),
  CONSTRAINT `vente_produits_produit_id_foreign` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vente_produits_vente_id_foreign` FOREIGN KEY (`vente_id`) REFERENCES `ventes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vente_produits`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `vente_produits` WRITE;
/*!40000 ALTER TABLE `vente_produits` DISABLE KEYS */;
INSERT INTO `vente_produits` VALUES
(1,1,1,3,23000.00,'2026-08-17 20:59:49','2026-08-17 20:59:49'),
(2,2,1,3,23000.00,'2026-08-17 21:03:11','2026-08-17 21:03:11'),
(3,2,2,2,17000.00,'2026-08-17 21:03:11','2026-08-17 21:03:11'),
(4,2,3,2,7000.00,'2026-08-17 21:03:11','2026-08-17 21:03:11');
/*!40000 ALTER TABLE `vente_produits` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ventes`
--

DROP TABLE IF EXISTS `ventes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `debiteur_id` bigint(20) unsigned NOT NULL,
  `agent_id` bigint(20) unsigned NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `produit_id` bigint(20) unsigned DEFAULT NULL,
  `type_vente` enum('comptant','credit') NOT NULL DEFAULT 'credit',
  `montant_total` decimal(12,2) NOT NULL,
  `montant_journalier` decimal(12,2) NOT NULL,
  `nombre_jours` int(11) NOT NULL,
  `delai_avant_echeances` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `epargne` decimal(12,2) NOT NULL DEFAULT 0.00,
  `epargne_par_jour` decimal(8,2) NOT NULL DEFAULT 0.00,
  `epargne_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `penalite_par_jour` decimal(8,2) NOT NULL DEFAULT 1000.00,
  `penalite_active` tinyint(1) NOT NULL DEFAULT 1,
  `motif_penalite` text DEFAULT NULL,
  `mise_agent` decimal(8,2) NOT NULL DEFAULT 0.00,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `heure_creation` time DEFAULT NULL,
  `statut` enum('en_cours','termine','defaut','annule') NOT NULL DEFAULT 'en_cours',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ventes_uuid_unique` (`uuid`),
  KEY `ventes_debiteur_id_foreign` (`debiteur_id`),
  KEY `ventes_agent_id_foreign` (`agent_id`),
  KEY `ventes_produit_id_foreign` (`produit_id`),
  KEY `ventes_created_by_index` (`created_by`),
  CONSTRAINT `ventes_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `ventes_debiteur_id_foreign` FOREIGN KEY (`debiteur_id`) REFERENCES `debiteurs` (`id`),
  CONSTRAINT `ventes_produit_id_foreign` FOREIGN KEY (`produit_id`) REFERENCES `produits` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ventes` WRITE;
/*!40000 ALTER TABLE `ventes` DISABLE KEYS */;
INSERT INTO `ventes` VALUES
(1,'7ea546c4-2401-4851-8a25-0d7772e8d606',5,3,1,NULL,'credit',75000.00,3750.00,20,1,6000.00,300.00,6000.00,1000.00,1,NULL,300.00,'2026-08-17','2026-09-06',NULL,'en_cours','2026-08-17 20:59:49','2026-08-17 22:31:51'),
(2,'bf517af3-af8e-4b65-9589-7f2d3b186a17',6,3,1,NULL,'credit',123000.00,6150.00,20,1,6000.00,300.00,6000.00,1000.00,1,NULL,300.00,'2026-08-17','2026-09-06',NULL,'en_cours','2026-08-17 21:03:11','2026-08-17 22:31:51');
/*!40000 ALTER TABLE `ventes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'sourougnon_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-26 18:12:28
